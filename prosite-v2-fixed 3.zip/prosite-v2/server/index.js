require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const path    = require('path');
const { init } = require('./db/schema');

const app  = express();
const PORT = process.env.PORT || 5000;

app.use(cors({ origin: ['http://localhost:3000','http://localhost:3001'], credentials: true }));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.get('/api/health', (req, res) => res.json({ status: 'ProSite v2 ✅', db: 'sql.js' }));

async function start() {
  try {
    await init();                          // initialise sql.js DB first

    app.use('/api/auth',       require('./routes/auth'));
    app.use('/api/projects',   require('./routes/projects'));
    app.use('/api/logs',       require('./routes/logs'));
    app.use('/api/attendance', require('./routes/attendance'));
    app.use('/api/roster',     require('./routes/roster'));
    app.use('/api/materials',  require('./routes/materials'));
    app.use('/api/tasks',      require('./routes/tasks'));
    app.use('/api/budget',     require('./routes/budget'));
    app.use('/api/admin',      require('./routes/admin'));
    app.use('/api/reports',    require('./routes/reports'));
    app.use('/api/milestones', require('./routes/milestones'));
    app.use('/api/issues',     require('./routes/issues'));

    app.listen(PORT, () => {
      console.log(`\n🏗️  ProSite v2  →  http://localhost:${PORT}`);
      console.log(`📦  Database : sql.js (no Visual Studio needed)`);
      console.log(`🔑  Auth     : JWT\n`);
    });
  } catch (err) {
    console.error('❌ Failed to start:', err);
    process.exit(1);
  }
}

start();
