const router = require('express').Router();
const db = require('../db/schema');
const auth = require('../middleware/auth');
const bcrypt = require('bcryptjs');

const ownerOnly = (req, res, next) => {
  if (req.user.role !== 'owner') return res.status(403).json({ error: 'Owner access required' });
  next();
};

router.get('/users', auth, ownerOnly, (req, res) => {
  const users = db.prepare('SELECT id,name,email,role,phone,assigned_project_id,created_at FROM users ORDER BY created_at DESC').all();
  res.json(users);
});

router.post('/users', auth, ownerOnly, (req, res) => {
  const { name, email, password, role, phone, assigned_project_id } = req.body;
  if (db.prepare('SELECT id FROM users WHERE email=?').get(email)) return res.status(400).json({ error: 'Email exists' });
  const result = db.prepare('INSERT INTO users (name,email,password,role,phone,assigned_project_id) VALUES (?,?,?,?,?,?)').run(name, email, bcrypt.hashSync(password, 10), role, phone, assigned_project_id || null);
  res.json({ id: result.lastInsertRowid });
});

router.put('/users/:id', auth, ownerOnly, (req, res) => {
  const { name, role, phone, assigned_project_id } = req.body;
  db.prepare('UPDATE users SET name=?,role=?,phone=?,assigned_project_id=? WHERE id=?').run(name, role, phone, assigned_project_id || null, req.params.id);
  res.json({ message: 'Updated' });
});

router.put('/users/:id/reset-password', auth, ownerOnly, (req, res) => {
  db.prepare('UPDATE users SET password=? WHERE id=?').run(bcrypt.hashSync(req.body.password, 10), req.params.id);
  res.json({ message: 'Password reset' });
});

router.delete('/users/:id', auth, ownerOnly, (req, res) => {
  if (Number(req.params.id) === req.user.id) return res.status(400).json({ error: 'Cannot delete yourself' });
  db.prepare('DELETE FROM users WHERE id=?').run(req.params.id);
  res.json({ message: 'Deleted' });
});

router.get('/notifications', auth, (req, res) => {
  res.json(db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(req.user.id));
});

router.put('/notifications/:id/read', auth, (req, res) => {
  db.prepare('UPDATE notifications SET read=1 WHERE id=? AND user_id=?').run(req.params.id, req.user.id);
  res.json({ message: 'Read' });
});

router.put('/notifications/read-all', auth, (req, res) => {
  db.prepare('UPDATE notifications SET read=1 WHERE user_id=?').run(req.user.id);
  res.json({ message: 'All read' });
});

module.exports = router;
