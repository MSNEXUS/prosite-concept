const { init } = require('./schema');
const bcrypt   = require('bcryptjs');

async function seed() {
  const db = await init();
  console.log('🌱 Seeding ProSite v2 demo data...\n');

  // Clear everything
  db.exec(`
    DELETE FROM notifications; DELETE FROM expenses; DELETE FROM budget_categories;
    DELETE FROM issues; DELETE FROM milestones; DELETE FROM tasks;
    DELETE FROM material_transactions; DELETE FROM materials;
    DELETE FROM attendance; DELETE FROM worker_roster;
    DELETE FROM log_photos; DELETE FROM site_logs;
    DELETE FROM projects; DELETE FROM users;
  `);

  const hash = bcrypt.hashSync('demo1234', 10);

  // ── Users ──────────────────────────────────────────────────────────────
  const iU = db.prepare(`INSERT INTO users (name,email,password,role,phone,assigned_project_id) VALUES (?,?,?,?,?,?)`);
  iU.run('Arjun Menon',     'admin@prosite.in',      hash, 'owner',      '9876543210', null);
  iU.run('Ravi Kumar',      'engineer@prosite.in',   hash, 'engineer',   '9876543211', null);
  iU.run('Suresh Pillai',   'supervisor@prosite.in', hash, 'supervisor', '9876543212', null);
  iU.run('Deepa Nair',      'deepa@prosite.in',      hash, 'engineer',   '9876543213', null);
  iU.run('Thomas Varghese', 'client@prosite.in',     hash, 'client',     '9876543214', 1);
  console.log('✅ Users');

  // ── Projects ───────────────────────────────────────────────────────────
  const iP = db.prepare(`INSERT INTO projects (name,location,description,start_date,end_date,status,budget_total,progress,manager_id) VALUES (?,?,?,?,?,?,?,?,?)`);
  iP.run('Greenfield Residency Phase 2','Kakkanad, Kochi','120-unit residential complex','2025-12-08','2026-12-07','active',4500000,42,2);
  iP.run('TechPark Tower Block B','Infopark, Kochi','Commercial office tower 14 floors','2026-02-21','2027-07-07','active',12000000,18,2);
  iP.run('NH Bypass Road Widening','Thrissur','State highway expansion 12km','2025-09-07','2026-04-08','completed',2800000,100,1);
  console.log('✅ Projects');

  // ── Worker Roster ──────────────────────────────────────────────────────
  const iR = db.prepare(`INSERT INTO worker_roster (project_id,worker_name,role,daily_wage,phone) VALUES (?,?,?,?,?)`);
  const roster = [
    [1,'Biju Thomas','Mason',800,'9845001001'],
    [1,'Sajan George','Mason',800,'9845001002'],
    [1,'Manoj Varma','Carpenter',900,'9845001003'],
    [1,'Pradeep Nair','Electrician',1000,'9845001004'],
    [1,'Anwar Hussain','Helper',600,'9845001005'],
    [1,'Rajesh Mohan','Plumber',950,'9845001006'],
    [1,'Vineeth Kumar','Steel Binder',850,'9845001007'],
    [1,'Anil Pillai','Helper',600,'9845001008'],
    [1,'Sreekumar P','Mason',800,'9845001009'],
    [1,'Jose Mathew','Carpenter',900,'9845001010'],
    [2,'Ramesh Babu','Mason',800,'9845002001'],
    [2,'Krishnan C','Helper',600,'9845002002'],
  ];
  roster.forEach(r => iR.run(...r));
  console.log('✅ Roster');

  // ── Attendance ─────────────────────────────────────────────────────────
  const iA = db.prepare(`INSERT INTO attendance (project_id,worker_name,role,daily_wage,date,check_in,check_out,status,overtime_hours) VALUES (?,?,?,?,?,?,?,?,?)`);
  roster.filter(r=>r[0]===1).forEach((w,i)=>{
    ['2026-08-16','2026-08-15','2026-08-14'].forEach(date=>{
      const st = i===6?'absent':i===4?'half_day':'present';
      const ot = i===2&&date==='2026-08-16'?2:0;
      iA.run(1,w[1],w[2],w[3],date,st==='absent'?null:'08:15',st==='absent'?null:st==='half_day'?'13:00':'17:30',st,ot);
    });
  });
  console.log('✅ Attendance');

  // ── Site Logs ──────────────────────────────────────────────────────────
  const iL = db.prepare(`INSERT INTO site_logs (project_id,user_id,date,work_done,issues,weather,manpower,is_quick_log) VALUES (?,?,?,?,?,?,?,?)`);
  iL.run(1,2,'2026-08-16','Completed slab casting for B-block 3rd floor. Formwork removed from 2nd floor.','Concrete pump delayed by 2 hours due to traffic.','Sunny, 34°C',48,0);
  iL.run(1,2,'2026-08-15','Rebar placement completed for columns C12 to C18. Electrical conduits laid.','Minor rework needed on column C14 due to alignment.','Partly cloudy',52,0);
  iL.run(1,3,'2026-08-14','Brickwork started on 2nd floor eastern wing. 60% of target achieved.','Cement stock running low — restocked by EOD.','Humid, 36°C',45,1);
  iL.run(2,4,'2026-08-16','Pile foundation work ongoing. 24 of 80 piles completed.','Rig breakdown — 3 hours downtime.','Clear',30,0);
  console.log('✅ Site logs');

  // ── Materials ──────────────────────────────────────────────────────────
  const iM = db.prepare(`INSERT INTO materials (project_id,name,unit,qty_received,qty_used,qty_remaining,min_stock,unit_cost,supplier) VALUES (?,?,?,?,?,?,?,?,?)`);
  [
    [1,'Cement (53 Grade)','Bags',2000,1450,550,200,420,'Ramco Cements'],
    [1,'TMT Steel Bars','Tonnes',85,62,23,10,62000,'Vizag Steel'],
    [1,'River Sand','Loads',120,98,22,15,8500,'Local Supplier'],
    [1,'Aggregate 20mm','Loads',90,71,19,10,7200,'Granite Works'],
    [1,'Bricks (Red)','Nos',50000,32000,18000,5000,8,'Kerala Bricks'],
    [1,'Plywood (12mm)','Sheets',300,278,22,30,1800,'Greenply'],
    [2,'Cement (53 Grade)','Bags',800,310,490,100,420,'Ramco Cements'],
    [2,'TMT Steel Bars','Tonnes',40,12,28,8,62000,'Vizag Steel'],
  ].forEach(m => iM.run(...m));
  console.log('✅ Materials');

  // ── Milestones ─────────────────────────────────────────────────────────
  const iMs = db.prepare(`INSERT INTO milestones (project_id,title,description,target_date,status,completed_at,payment_amount,client_approved) VALUES (?,?,?,?,?,?,?,?)`);
  iMs.run(1,'Foundation & Plinth','Foundation, plinth beam, anti-termite treatment','2026-03-08','completed','2026-03-06',900000,1);
  iMs.run(1,'Ground Floor Slab','Ground floor slab + columns to 1st floor','2026-05-09','completed','2026-05-07',900000,1);
  iMs.run(1,'3rd Floor Structure','Structural work up to 3rd floor slab','2026-09-06','in_progress',null,900000,0);
  iMs.run(1,'Roof & Waterproofing','Roof slab + two-coat waterproofing','2026-11-21','pending',null,900000,0);
  iMs.run(1,'Finishing & Handover','Plastering, tiling, MEP, painting','2026-12-07','pending',null,900000,0);
  iMs.run(2,'Pile Foundation','All 80 piles + pile cap','2026-10-06','in_progress',null,2400000,0);
  console.log('✅ Milestones');

  // ── Issues ─────────────────────────────────────────────────────────────
  const iI = db.prepare(`INSERT INTO issues (project_id,title,description,raised_by,severity,status) VALUES (?,?,?,?,?,?)`);
  iI.run(1,'Concrete pump vendor delay','Vendor failed to show on time. Lost 2 hours on slab day.',2,'high','open');
  iI.run(2,'Rig breakdown — pile work halted','Piling rig hydraulic failure. 2-day repair. Work on hold.',4,'critical','open');
  iI.run(1,'Alignment issue column C14','Column C14 is 18mm off drawing. Rework needed.',2,'high','resolved');
  console.log('✅ Issues');

  // ── Tasks ──────────────────────────────────────────────────────────────
  const iT = db.prepare(`INSERT INTO tasks (project_id,title,description,assigned_to,priority,status,due_date) VALUES (?,?,?,?,?,?,?)`);
  [
    [1,'Complete 3rd floor slab casting','Coordinate with concrete pump vendor.',2,'urgent','in_progress','2026-08-21'],
    [1,'Order next batch of TMT steel','Min 20 tonnes for 4th floor.',3,'high','pending','2026-08-18'],
    [1,'Electrical conduit 2nd floor','All conduits before plastering.',2,'medium','in_progress','2026-08-26'],
    [1,'Waterproofing terrace','2 coats SBR on terrace slab.',3,'low','pending','2026-09-07'],
    [1,'Submit PWD inspection report','Prepare compliance documents.',2,'high','completed','2026-08-14'],
    [2,'Complete remaining 56 piles','8 piles/day target.',4,'urgent','in_progress','2026-08-31'],
    [2,'Soil test report submission','Submit to structural engineer.',4,'high','completed','2026-08-11'],
  ].forEach(t => iT.run(...t));
  console.log('✅ Tasks');

  // ── Budget ─────────────────────────────────────────────────────────────
  const iC = db.prepare(`INSERT INTO budget_categories (project_id,name,estimated,actual) VALUES (?,?,?,?)`);
  [
    [1,'Materials',2200000,1840000],[1,'Labour',900000,720000],
    [1,'Equipment Rental',350000,410000],[1,'Site Overheads',150000,98000],
    [1,'Contractor Fees',400000,320000],[1,'Contingency',500000,87000],
    [2,'Materials',5500000,980000],[2,'Labour',2500000,340000],
    [2,'Equipment Rental',1200000,520000],[2,'Contractor Fees',1800000,200000],
  ].forEach(c => iC.run(...c));

  const iE = db.prepare(`INSERT INTO expenses (category_id,project_id,description,amount,date,payment_status,bill_ref,added_by) VALUES (?,?,?,?,?,?,?,?)`);
  [
    [1,1,'Ramco Cement – 500 bags batch 3',210000,'2026-08-14','paid','INV-RC-2847',2],
    [1,1,'Vizag Steel – 15T TMT delivery',930000,'2026-08-12','paid','INV-VS-1042',2],
    [1,1,'River Sand – 20 loads',170000,'2026-08-09','pending','RS-045',3],
    [2,1,'Labour wages – April 2025',360000,'2026-08-07','paid','PAY-APR-25',1],
    [3,1,'Concrete pump rental – May week 1',45000,'2026-08-13','paid','PMP-012',3],
    [3,1,'Tower crane monthly rent',120000,'2026-08-07','paid','CRN-MAY25',2],
  ].forEach(e => iE.run(...e));
  console.log('✅ Budget & expenses');

  // ── Notifications ──────────────────────────────────────────────────────
  const iN = db.prepare(`INSERT INTO notifications (user_id,title,message,type) VALUES (?,?,?,?)`);
  [
    [1,'🚨 Critical Issue','Rig breakdown at TechPark Tower — pile work halted.','alert'],
    [1,'⚠️ Low Stock: Plywood (12mm)','Only 22 sheets remaining. Min is 30.','alert'],
    [1,'💸 Budget Overrun: Equipment Rental','Exceeded estimate by ₹60,000.','warning'],
    [1,'✅ Milestone Approved','Thomas Varghese approved Ground Floor Slab milestone.','info'],
    [2,'📋 Task Due Tomorrow','"Order TMT steel" is due on 2025-05-12.','reminder'],
    [5,'🏗️ Progress Update','Greenfield Residency is now 42% complete.','info'],
    [5,'✅ Milestone Done','Ground Floor Slab milestone completed.','info'],
  ].forEach(n => iN.run(...n));
  console.log('✅ Notifications');

  console.log('\n🎉 Seed complete!\n');
  console.log('   👑 Owner:      admin@prosite.in      / demo1234');
  console.log('   🔧 Engineer:   engineer@prosite.in   / demo1234');
  console.log('   👷 Supervisor: supervisor@prosite.in / demo1234');
  console.log('   🤝 Client:     client@prosite.in     / demo1234\n');
}

seed().catch(err => { console.error('❌ Seed failed:', err); process.exit(1); });
