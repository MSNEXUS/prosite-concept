const path = require('path');
const fs   = require('fs');

const DB_PATH = path.join(__dirname, '../prosite.db');
let _db = null;
let _inTx = false;

/* ── disk persistence ─────────────────────────────────────────────────── */
function save() {
  if (_inTx) return;
  fs.writeFileSync(DB_PATH, Buffer.from(_db.export()));
}

/* ── query helpers ────────────────────────────────────────────────────── */
function normaliseParams(args) {
  if (!args || args.length === 0) return [];
  if (args.length === 1 && Array.isArray(args[0])) return args[0];
  return Array.from(args);
}

function stmtRun(sql, params) {
  const s = _db.prepare(sql);
  s.bind(params.length ? params : []);
  s.step();
  s.free();
  save();
  const r = _db.exec('SELECT last_insert_rowid() as id');
  return { lastInsertRowid: r[0]?.values[0][0] || 0 };
}

function stmtGet(sql, params) {
  const s = _db.prepare(sql);
  if (params.length) s.bind(params);
  let result;
  if (s.step()) result = s.getAsObject();
  s.free();
  return result || undefined;
}

function stmtAll(sql, params) {
  const s = _db.prepare(sql);
  if (params.length) s.bind(params);
  const rows = [];
  while (s.step()) rows.push(s.getAsObject());
  s.free();
  return rows;
}

/* ── better-sqlite3-compatible Statement ──────────────────────────────── */
class Statement {
  constructor(sql) { this.sql = sql; }
  run(...a)  { return stmtRun(this.sql, normaliseParams(a)); }
  get(...a)  { return stmtGet(this.sql, normaliseParams(a)); }
  all(...a)  { return stmtAll(this.sql, normaliseParams(a)); }
}

/* ── db facade (same API as better-sqlite3) ────────────────────────────── */
const db = {
  prepare: (sql) => new Statement(sql),
  exec: (sql) => {
    _db.exec(sql);
    save();
    return db;
  },
  transaction: (fn) => (...args) => {
    _db.run('BEGIN');
    _inTx = true;
    try {
      fn(...args);
      _db.run('COMMIT');
      _inTx = false;
      save();
    } catch (e) {
      _db.run('ROLLBACK');
      _inTx = false;
      throw e;
    }
  },
};

/* ── init (call once before starting the server) ──────────────────────── */
async function init() {
  const initSqlJs = require('sql.js');
  const SQL = await initSqlJs();

  _db = fs.existsSync(DB_PATH)
    ? new SQL.Database(fs.readFileSync(DB_PATH))
    : new SQL.Database();

  /* create all tables */
  _db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'supervisor',
      phone TEXT,
      assigned_project_id INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS projects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      location TEXT,
      description TEXT,
      start_date DATE,
      end_date DATE,
      status TEXT DEFAULT 'active',
      budget_total REAL DEFAULT 0,
      progress INTEGER DEFAULT 0,
      manager_id INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS site_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER,
      user_id INTEGER,
      date DATE DEFAULT CURRENT_DATE,
      work_done TEXT,
      issues TEXT,
      weather TEXT,
      manpower INTEGER DEFAULT 0,
      is_quick_log INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS log_photos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      log_id INTEGER,
      filename TEXT NOT NULL,
      caption TEXT,
      uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS attendance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER,
      worker_name TEXT NOT NULL,
      role TEXT,
      daily_wage REAL DEFAULT 0,
      date DATE DEFAULT CURRENT_DATE,
      check_in TIME,
      check_out TIME,
      status TEXT DEFAULT 'present',
      overtime_hours REAL DEFAULT 0,
      notes TEXT
    );
    CREATE TABLE IF NOT EXISTS worker_roster (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER,
      worker_name TEXT NOT NULL,
      role TEXT,
      daily_wage REAL DEFAULT 0,
      phone TEXT,
      active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS materials (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER,
      name TEXT NOT NULL,
      unit TEXT,
      qty_received REAL DEFAULT 0,
      qty_used REAL DEFAULT 0,
      qty_remaining REAL DEFAULT 0,
      min_stock REAL DEFAULT 0,
      unit_cost REAL DEFAULT 0,
      supplier TEXT,
      last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS material_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      material_id INTEGER,
      type TEXT,
      quantity REAL,
      notes TEXT,
      date DATE DEFAULT CURRENT_DATE,
      recorded_by INTEGER
    );
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER,
      title TEXT NOT NULL,
      description TEXT,
      assigned_to INTEGER,
      priority TEXT DEFAULT 'medium',
      status TEXT DEFAULT 'pending',
      depends_on INTEGER,
      due_date DATE,
      completed_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS milestones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER,
      title TEXT NOT NULL,
      description TEXT,
      target_date DATE,
      status TEXT DEFAULT 'pending',
      completed_at DATETIME,
      payment_amount REAL DEFAULT 0,
      client_approved INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS issues (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER,
      title TEXT NOT NULL,
      description TEXT,
      raised_by INTEGER,
      severity TEXT DEFAULT 'high',
      status TEXT DEFAULT 'open',
      resolved_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS budget_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER,
      name TEXT NOT NULL,
      estimated REAL DEFAULT 0,
      actual REAL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      category_id INTEGER,
      project_id INTEGER,
      description TEXT,
      amount REAL NOT NULL,
      date DATE DEFAULT CURRENT_DATE,
      payment_status TEXT DEFAULT 'pending',
      bill_ref TEXT,
      added_by INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      title TEXT NOT NULL,
      message TEXT,
      type TEXT,
      read INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  save();
  console.log('✅ Database ready (sql.js — no compilation needed)');
  return db;
}

module.exports = db;
module.exports.init = init;
