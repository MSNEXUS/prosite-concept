# Running ProSite locally (Cursor)

## 1. Open the project
Unzip this folder and open it in Cursor (`File → Open Folder`).

## 2. Install dependencies
Open a terminal in Cursor (`` Ctrl/Cmd+` ``) at the project root and run:

```bash
npm run install:all
```

This installs the root, `server`, and `client` dependencies in one go.

## 3. Seed the database
```bash
npm run seed
```

This creates `server/prosite.db` (SQLite via sql.js) with demo data:
projects, logs, attendance, materials, tasks, budget, milestones, and issues.
Dates in the seed data are auto-shifted relative to today, so the dashboard,
overdue-task counts, and budget-burn forecasts always look current — you
don't need to re-shift anything by hand.

## 4. Run it
```bash
npm run dev
```

This starts the Express API on **http://localhost:5000** and the React
client on **http://localhost:3000** together (via `concurrently`). Open
http://localhost:3000 in your browser.

## Demo logins
| Role | Email | Password |
|------|-------|----------|
| 👑 Owner | admin@prosite.in | demo1234 |
| 🔧 Engineer | engineer@prosite.in | demo1234 |
| 👷 Supervisor | supervisor@prosite.in | demo1234 |
| 🤝 Client | client@prosite.in | demo1234 |

## What was fixed in this pass (Aug 2026 review)
- **Security**: `GET /api/admin/users` was reachable by any logged-in role
  (including Client), leaking every user's name/email/phone. Now restricted
  to Owner only.
- **Security**: `PUT /api/admin/notifications/:id/read` didn't check that
  the notification belonged to the requesting user — any authenticated
  user could mark anyone's notification as read by guessing the ID. Now
  scoped to `user_id`.
- **Data freshness**: all seed dates were hardcoded to May 2025, so running
  the app "today" made every task look overdue and burn-forecasts always
  showed 0 days remaining. Dates are now shifted by a fixed offset from a
  reference date, so re-running `npm run seed` always produces a
  present-day-relative dataset.

## Known rough edges (not fixed, worth knowing about)
- A few notification inserts hardcode `user_id = 1` as "the owner" (in
  `materials.js`, `budget.js`, `issues.js`, `milestones.js`) instead of
  looking up whoever actually holds the Owner role. Works fine with the
  seeded data (user 1 *is* the owner) but will misfire if you add a second
  owner account or change the seed order.
- No rate limiting or input validation (e.g. `express-validator`) on
  write routes yet — fine for a local demo, worth adding before any
  public deployment.
- `server/.env` ships a hardcoded `JWT_SECRET` — rotate this before
  deploying anywhere real.
- No automated tests.

## Deploying beyond localhost
This uses `sql.js` (SQLite compiled to WASM, persisted to a flat file) —
it's great for zero-setup local dev but won't survive a stateless/ephemeral
host (e.g. most serverless platforms wipe the filesystem on redeploy). For
a real deployment, swap in a hosted Postgres (Railway, Supabase, Neon) or
run this on a host with a persistent disk (a small VPS, Render's disk
add-on, Fly.io volumes). Ask me when you're ready for this step — it's a
schema/query-layer swap, not a rewrite, since the `db.prepare/.run/.get/.all`
interface is already abstracted in `server/db/schema.js`.
