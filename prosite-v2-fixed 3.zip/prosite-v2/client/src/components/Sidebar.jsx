import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { useState } from 'react';
import Phase2Modal from './Phase2Modal';

const NAV_LINKS = {
  owner: [
    { to: '/', icon: '⬡', label: 'Command Center', end: true },
    { to: '/projects', icon: '◈', label: 'Projects' },
    { to: '/logs', icon: '◉', label: 'Site Logs' },
    { to: '/attendance', icon: '◎', label: 'Attendance' },
    { to: '/materials', icon: '◫', label: 'Materials' },
    { to: '/tasks', icon: '◷', label: 'Tasks' },
    { to: '/budget', icon: '◈', label: 'Budget' },
    { to: '/admin', icon: '⬡', label: 'Admin Panel' },
  ],
  engineer: [
    { to: '/', icon: '⬡', label: 'Dashboard', end: true },
    { to: '/logs', icon: '◉', label: 'Site Logs' },
    { to: '/tasks', icon: '◷', label: 'My Tasks' },
    { to: '/materials', icon: '◫', label: 'Materials' },
    { to: '/projects', icon: '◈', label: 'Projects' },
    { to: '/budget', icon: '◈', label: 'Budget' },
  ],
  supervisor: [
    { to: '/', icon: '⬡', label: 'Dashboard', end: true },
    { to: '/attendance', icon: '◎', label: 'Attendance' },
    { to: '/logs', icon: '◉', label: 'Site Logs' },
    { to: '/materials', icon: '◫', label: 'Materials' },
    { to: '/tasks', icon: '◷', label: 'Tasks' },
  ],
  client: [
    { to: '/client', icon: '⬡', label: 'My Project', end: true },
  ],
};

const ROLE_META = {
  owner:      { label: 'Owner',      color: '#f5c842', tag: 'ADMIN' },
  engineer:   { label: 'Engineer',   color: '#4f9cf9', tag: 'SITE' },
  supervisor: { label: 'Supervisor', color: '#3ecf8e', tag: 'OPS' },
  client:     { label: 'Client',     color: '#a78bfa', tag: 'VIEW' },
};

const PHASE2 = [
  { key: 'gps',       icon: '⊕', label: 'GPS Check-In' },
  { key: 'whatsapp',  icon: '⊗', label: 'WhatsApp' },
  { key: 'ai',        icon: '⊘', label: 'AI Analytics' },
  { key: 'pdf',       icon: '⊙', label: 'PDF Reports' },
];

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [phase2Key, setPhase2Key] = useState(null);
  const meta = ROLE_META[user?.role] || ROLE_META.engineer;
  const links = NAV_LINKS[user?.role] || NAV_LINKS.engineer;
  const accentColor = meta.color;

  const handleLogout = () => { logout(); toast.success('Signed out'); navigate('/login'); };

  return (
    <>
      <aside style={{
        width: 'var(--sidebar-w)',
        position: 'fixed', top: 0, left: 0, height: '100vh',
        background: 'rgba(9,12,18,0.97)',
        backdropFilter: 'blur(20px)',
        borderRight: '1px solid rgba(255,255,255,0.07)',
        display: 'flex', flexDirection: 'column',
        zIndex: 100, overflowY: 'auto',
      }}>
        {/* Top accent line */}
        <div style={{ height: 2, background: `linear-gradient(90deg, transparent, ${accentColor}, transparent)`, flexShrink: 0 }} />

        {/* Logo */}
        <div style={{ padding: '20px 18px 16px', borderBottom: '1px solid rgba(255,255,255,0.06)', flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              width: 38, height: 38, borderRadius: 10, flexShrink: 0,
              background: `linear-gradient(135deg, ${accentColor}22, ${accentColor}44)`,
              border: `1px solid ${accentColor}55`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 18,
              boxShadow: `0 0 16px ${accentColor}33`,
            }}>🏗️</div>
            <div>
              <div style={{ color: '#e8edf5', fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 18, letterSpacing: '-0.5px', lineHeight: 1 }}>ProSite</div>
              <div style={{ marginTop: 3, display: 'flex', alignItems: 'center', gap: 5 }}>
                <span style={{ fontSize: 9, fontFamily: 'DM Mono, monospace', fontWeight: 600, letterSpacing: '1px', color: accentColor, textTransform: 'uppercase' }}>{meta.tag}</span>
                <span style={{ fontSize: 9, color: 'rgba(255,255,255,0.2)' }}>·</span>
                <span style={{ fontSize: 9, fontFamily: 'DM Mono, monospace', color: 'rgba(255,255,255,0.25)', letterSpacing: '0.5px' }}>v2.0</span>
              </div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ padding: '14px 10px', flex: 1 }}>
          <div style={{ fontSize: 9, fontFamily: 'DM Mono, monospace', color: 'rgba(255,255,255,0.2)', letterSpacing: '1.2px', textTransform: 'uppercase', padding: '0 10px', marginBottom: 8 }}>Navigation</div>
          {links.map(n => (
            <NavLink key={n.to + n.label} to={n.to} end={n.end}
              style={({ isActive }) => ({
                display: 'flex', alignItems: 'center', gap: 11,
                padding: '10px 12px', borderRadius: 9, marginBottom: 2,
                fontSize: 13, fontWeight: isActive ? 600 : 400,
                color: isActive ? accentColor : 'rgba(255,255,255,0.45)',
                background: isActive ? `${accentColor}14` : 'transparent',
                border: `1px solid ${isActive ? accentColor + '33' : 'transparent'}`,
                transition: 'all 0.2s cubic-bezier(0.4,0,0.2,1)',
                boxShadow: isActive ? `0 0 12px ${accentColor}22` : 'none',
                textDecoration: 'none',
              })}
            >
              <span style={{ fontSize: 15, width: 18, textAlign: 'center', fontFamily: 'DM Mono, monospace', opacity: 0.8 }}>{n.icon}</span>
              {n.label}
            </NavLink>
          ))}

          {/* Phase 2 section */}
          <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
            <div style={{ fontSize: 9, fontFamily: 'DM Mono, monospace', color: 'rgba(255,255,255,0.2)', letterSpacing: '1.2px', textTransform: 'uppercase', padding: '0 10px', marginBottom: 8 }}>Phase 2</div>
            {PHASE2.map(p => (
              <button key={p.key} onClick={() => setPhase2Key(p.key)} style={{
                width: '100%', display: 'flex', alignItems: 'center', gap: 11,
                padding: '9px 12px', borderRadius: 9, marginBottom: 2,
                background: 'transparent', border: '1px solid transparent',
                color: 'rgba(255,255,255,0.22)', cursor: 'pointer',
                fontSize: 13, transition: 'all 0.2s', fontFamily: 'DM Sans, sans-serif',
              }}
                onMouseEnter={e => { e.currentTarget.style.background = 'rgba(167,139,250,0.08)'; e.currentTarget.style.color = 'rgba(167,139,250,0.7)'; e.currentTarget.style.borderColor = 'rgba(167,139,250,0.2)'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'rgba(255,255,255,0.22)'; e.currentTarget.style.borderColor = 'transparent'; }}
              >
                <span style={{ fontSize: 14, width: 18, textAlign: 'center', fontFamily: 'DM Mono, monospace' }}>{p.icon}</span>
                {p.label}
                <span style={{ marginLeft: 'auto', fontSize: 9, fontFamily: 'DM Mono, monospace', background: 'rgba(167,139,250,0.15)', color: '#a78bfa', padding: '2px 6px', borderRadius: 8, fontWeight: 700, letterSpacing: '0.5px' }}>P2</span>
              </button>
            ))}
          </div>
        </nav>

        {/* User */}
        <div style={{ padding: '12px 10px', borderTop: '1px solid rgba(255,255,255,0.06)', flexShrink: 0 }}>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 10,
            padding: '10px 12px', borderRadius: 10,
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(255,255,255,0.07)',
          }}>
            <div style={{
              width: 32, height: 32, borderRadius: '50%', flexShrink: 0,
              background: `linear-gradient(135deg, ${accentColor}33, ${accentColor}66)`,
              border: `1px solid ${accentColor}55`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: accentColor, fontWeight: 700, fontSize: 13,
              boxShadow: `0 0 10px ${accentColor}22`,
            }}>{user?.name?.charAt(0)}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ color: '#e8edf5', fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{user?.name}</div>
              <div style={{ color: accentColor, fontSize: 10, fontFamily: 'DM Mono, monospace', textTransform: 'uppercase', letterSpacing: '0.5px' }}>{meta.label}</div>
            </div>
            <button onClick={handleLogout} title="Sign out" style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.25)', fontSize: 15, padding: 4, flexShrink: 0, transition: 'color 0.2s' }}
              onMouseEnter={e => e.currentTarget.style.color = 'rgba(249,123,107,0.8)'}
              onMouseLeave={e => e.currentTarget.style.color = 'rgba(255,255,255,0.25)'}
            >↩</button>
          </div>
        </div>
      </aside>
      {phase2Key && <Phase2Modal featureKey={phase2Key} onClose={() => setPhase2Key(null)} />}
    </>
  );
}
