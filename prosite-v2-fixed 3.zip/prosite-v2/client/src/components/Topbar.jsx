import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Phase2Modal from './Phase2Modal';
import api from '../api';

const PAGE_TITLES = {
  '/': 'Command Center', '/projects': 'Projects', '/logs': 'Site Logs',
  '/attendance': 'Attendance', '/materials': 'Materials',
  '/tasks': 'Tasks', '/budget': 'Budget', '/admin': 'Admin Panel', '/client': 'My Project',
};

const PHASE2_TOPBAR = [
  { key: 'gps', label: '📍 GPS' },
  { key: 'pdf', label: '📄 PDF' },
  { key: 'whatsapp', label: '💬 WhatsApp' },
  { key: 'ai', label: '🤖 AI' },
];

export default function Topbar() {
  const location = useLocation();
  const { user } = useAuth();
  const [notifs, setNotifs] = useState([]);
  const [showNotifs, setShowNotifs] = useState(false);
  const [phase2Feature, setPhase2Feature] = useState(null);

  useEffect(() => {
    api.get('/admin/notifications').then(r => setNotifs(r.data)).catch(() => {});
  }, []);

  const unread = notifs.filter(n => !n.read).length;

  const markRead = async id => {
    await api.put(`/admin/notifications/${id}/read`);
    setNotifs(prev => prev.map(n => n.id === id ? { ...n, read: 1 } : n));
  };

  const markAll = async () => {
    await api.put('/admin/notifications/read-all');
    setNotifs(prev => prev.map(n => ({ ...n, read: 1 })));
    setShowNotifs(false);
  };

  const typeIcon = { alert: '🚨', warning: '⚠️', reminder: '⏰', info: 'ℹ️' };

  return (
    <>
      <header style={{
        background: 'rgba(9,12,18,0.92)',
        backdropFilter: 'blur(20px)',
        borderBottom: '1px solid rgba(255,255,255,0.07)',
        padding: '0 32px',
        height: 60,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        position: 'sticky', top: 0, zIndex: 50,
        gap: 16,
      }}>
        {/* Left — page title + phase2 pills */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, minWidth: 0 }}>
          <h2 style={{ fontSize: 16, fontWeight: 600, color: '#e8edf5', letterSpacing: '-0.2px', flexShrink: 0 }}>
            {PAGE_TITLES[location.pathname] || 'ProSite'}
          </h2>
          {user?.role !== 'client' && (
            <div style={{ display: 'flex', gap: 5, flexWrap: 'nowrap', overflow: 'hidden' }}>
              {PHASE2_TOPBAR.map(({ key, label }) => (
                <button key={key} onClick={() => setPhase2Feature(key)} style={{
                  padding: '3px 10px', borderRadius: 20,
                  background: 'rgba(167,139,250,0.08)',
                  border: '1px solid rgba(167,139,250,0.2)',
                  color: 'rgba(167,139,250,0.6)', cursor: 'pointer',
                  fontSize: 11, fontFamily: 'DM Mono, monospace',
                  transition: 'all 0.2s', whiteSpace: 'nowrap',
                }}
                  onMouseEnter={e => { e.currentTarget.style.background = 'rgba(167,139,250,0.16)'; e.currentTarget.style.color = '#a78bfa'; }}
                  onMouseLeave={e => { e.currentTarget.style.background = 'rgba(167,139,250,0.08)'; e.currentTarget.style.color = 'rgba(167,139,250,0.6)'; }}
                >
                  {label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right — date + notifications */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0 }}>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', fontFamily: 'DM Mono, monospace', letterSpacing: '0.3px' }}>
            {new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
          </div>

          {/* Bell */}
          <div style={{ position: 'relative' }}>
            <button onClick={() => setShowNotifs(!showNotifs)} style={{
              position: 'relative', background: 'rgba(255,255,255,0.05)',
              border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8,
              width: 34, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', fontSize: 15, transition: 'all 0.2s',
            }}
              onMouseEnter={e => { e.currentTarget.style.background = 'var(--accent-glow)'; e.currentTarget.style.borderColor = 'var(--accent-border)'; }}
              onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'; }}
            >
              🔔
              {unread > 0 && (
                <span style={{
                  position: 'absolute', top: -4, right: -4,
                  background: 'var(--red)', color: '#fff',
                  borderRadius: '50%', width: 16, height: 16,
                  fontSize: 9, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontWeight: 700, fontFamily: 'DM Mono, monospace',
                  animation: 'pulse 2s infinite',
                }}>{unread > 9 ? '9+' : unread}</span>
              )}
            </button>

            {/* Dropdown */}
            {showNotifs && (
              <div style={{
                position: 'absolute', right: 0, top: 'calc(100% + 8px)',
                width: 360, background: 'rgba(20,25,38,0.98)',
                backdropFilter: 'blur(20px)',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: 16, zIndex: 200,
                boxShadow: '0 24px 64px rgba(0,0,0,0.7)',
                animation: 'slideUp 0.15s ease',
              }}>
                <div style={{ padding: '14px 16px', borderBottom: '1px solid rgba(255,255,255,0.07)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{ fontWeight: 700, fontSize: 14, fontFamily: 'Syne, sans-serif' }}>
                    Notifications
                    {unread > 0 && <span style={{ marginLeft: 8, background: 'var(--red-dim)', color: 'var(--red)', borderRadius: 20, padding: '1px 7px', fontSize: 10, fontFamily: 'DM Mono, monospace' }}>{unread}</span>}
                  </span>
                  {unread > 0 && (
                    <button onClick={markAll} style={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-strong)', borderRadius: 6, padding: '3px 10px', fontSize: 11, color: 'var(--text-secondary)', cursor: 'pointer' }}>Mark all read</button>
                  )}
                </div>
                <div style={{ maxHeight: 380, overflowY: 'auto' }}>
                  {notifs.length === 0
                    ? <div style={{ padding: 28, textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>No notifications</div>
                    : notifs.slice(0, 15).map(n => (
                      <div key={n.id} onClick={() => markRead(n.id)} style={{
                        padding: '12px 16px', borderBottom: '1px solid rgba(255,255,255,0.05)',
                        background: n.read ? 'transparent' : 'rgba(79,156,249,0.05)',
                        cursor: 'pointer', transition: 'background 0.15s',
                      }}
                        onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.04)'}
                        onMouseLeave={e => e.currentTarget.style.background = n.read ? 'transparent' : 'rgba(79,156,249,0.05)'}
                      >
                        <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                          <span style={{ fontSize: 15, flexShrink: 0, marginTop: 1 }}>{typeIcon[n.type] || 'ℹ️'}</span>
                          <div>
                            <div style={{ fontWeight: 600, fontSize: 13, color: n.read ? 'var(--text-secondary)' : 'var(--text-primary)' }}>{n.title}</div>
                            <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 3, lineHeight: 1.5 }}>{n.message}</div>
                          </div>
                          {!n.read && <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)', flexShrink: 0, marginTop: 4, boxShadow: '0 0 6px var(--accent-glow)' }} />}
                        </div>
                      </div>
                    ))
                  }
                </div>
              </div>
            )}
          </div>
        </div>
      </header>
      {phase2Feature && <Phase2Modal featureKey={phase2Feature} onClose={() => setPhase2Feature(null)} />}
    </>
  );
}
