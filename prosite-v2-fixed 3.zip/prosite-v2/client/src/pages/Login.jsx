import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const DEMO_ROLES = [
  { role: 'owner',      label: 'Owner',      email: 'admin@prosite.in',      color: '#f5c842', icon: '👑', desc: 'Command center · All projects · Budget forecasting' },
  { role: 'engineer',   label: 'Engineer',   email: 'engineer@prosite.in',   color: '#4f9cf9', icon: '🔧', desc: 'Quick logs · Issue escalation · My tasks' },
  { role: 'supervisor', label: 'Supervisor', email: 'supervisor@prosite.in', color: '#3ecf8e', icon: '👷', desc: 'Attendance roster · Wage calculator · Materials' },
  { role: 'client',     label: 'Client',     email: 'client@prosite.in',     color: '#a78bfa', icon: '🤝', desc: 'Photo timeline · Milestone approval · Budget view' },
];

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState(null);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(email, password);
      toast.success(`Welcome back, ${user.name.split(' ')[0]}`);
      navigate(user.role === 'client' ? '/client' : '/');
    } catch { toast.error('Invalid credentials'); } finally { setLoading(false); }
  };

  const fill = (d) => { setEmail(d.email); setPassword('demo1234'); setSelected(d.role); };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', background: '#090c12', position: 'relative', overflow: 'hidden' }}>
      {/* Background radial glows */}
      <div style={{ position: 'absolute', top: '-20%', left: '-10%', width: '60%', height: '60%', background: 'radial-gradient(circle, rgba(79,156,249,0.07) 0%, transparent 70%)', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', bottom: '-20%', right: '-10%', width: '50%', height: '50%', background: 'radial-gradient(circle, rgba(62,207,142,0.05) 0%, transparent 70%)', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', top: '40%', right: '30%', width: '30%', height: '30%', background: 'radial-gradient(circle, rgba(167,139,250,0.04) 0%, transparent 70%)', pointerEvents: 'none' }} />

      {/* Left — branding */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '60px 64px', position: 'relative', borderRight: '1px solid rgba(255,255,255,0.06)' }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 56 }}>
          <div style={{ width: 44, height: 44, background: 'rgba(79,156,249,0.15)', border: '1px solid rgba(79,156,249,0.4)', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, boxShadow: '0 0 20px rgba(79,156,249,0.2)' }}>🏗️</div>
          <div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 22, color: '#e8edf5', letterSpacing: '-0.5px' }}>ProSite</div>
            <div style={{ fontSize: 10, fontFamily: 'DM Mono, monospace', color: 'rgba(79,156,249,0.7)', letterSpacing: '1.5px', textTransform: 'uppercase', marginTop: 2 }}>v2.0 · Site Management</div>
          </div>
        </div>

        <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: 44, fontWeight: 800, lineHeight: 1.1, marginBottom: 20, letterSpacing: '-1px', color: '#e8edf5' }}>
          Construction<br />
          Management<br />
          <span style={{ background: 'linear-gradient(90deg, #4f9cf9, #22d3ee)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Reimagined.</span>
        </h1>

        <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: 15, lineHeight: 1.8, maxWidth: 400, marginBottom: 48 }}>
          Built for Indian construction companies. Track sites, workers, materials and budget. Designed to impress investors.
        </p>

        {/* Feature grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px 24px', maxWidth: 400 }}>
          {[
            ['#4f9cf9', '◈ Command Center'],
            ['#3ecf8e', '◉ Attendance + Wages'],
            ['#f5c842', '◫ Material Alerts'],
            ['#4f9cf9', '◷ Budget Forecasting'],
            ['#f97b6b', '⊕ Issue Escalation'],
            ['#a78bfa', '⬡ Client Portal'],
          ].map(([color, label]) => (
            <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'rgba(255,255,255,0.45)', fontSize: 13, fontFamily: 'DM Mono, monospace' }}>
              <span style={{ color, fontSize: 14 }}>{label.split(' ')[0]}</span>
              <span>{label.split(' ').slice(1).join(' ')}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Right — login form */}
      <div style={{ width: 480, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 48px', position: 'relative' }}>
        <div style={{ width: '100%', maxWidth: 380 }}>
          <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 24, fontWeight: 700, color: '#e8edf5', marginBottom: 6 }}>Sign in</h2>
          <p style={{ color: 'rgba(255,255,255,0.35)', fontSize: 13, marginBottom: 28, fontFamily: 'DM Mono, monospace' }}>Enter your credentials to continue</p>

          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: 14 }}>
              <label style={{ display: 'block', fontSize: 10, fontFamily: 'DM Mono, monospace', color: 'rgba(255,255,255,0.35)', marginBottom: 7, textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600 }}>Email Address</label>
              <input
                type="email" value={email} onChange={e => setEmail(e.target.value)} required
                placeholder="you@prosite.in"
                style={{ width: '100%', padding: '11px 14px', background: 'rgba(20,25,38,0.8)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, fontSize: 14, fontFamily: 'DM Sans, sans-serif', color: '#e8edf5', outline: 'none', transition: 'all 0.2s' }}
                onFocus={e => { e.target.style.borderColor = 'rgba(79,156,249,0.5)'; e.target.style.boxShadow = '0 0 0 3px rgba(79,156,249,0.1)'; }}
                onBlur={e => { e.target.style.borderColor = 'rgba(255,255,255,0.1)'; e.target.style.boxShadow = 'none'; }}
              />
            </div>
            <div style={{ marginBottom: 20 }}>
              <label style={{ display: 'block', fontSize: 10, fontFamily: 'DM Mono, monospace', color: 'rgba(255,255,255,0.35)', marginBottom: 7, textTransform: 'uppercase', letterSpacing: '0.8px', fontWeight: 600 }}>Password</label>
              <input
                type="password" value={password} onChange={e => setPassword(e.target.value)} required
                placeholder="••••••••"
                style={{ width: '100%', padding: '11px 14px', background: 'rgba(20,25,38,0.8)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, fontSize: 14, fontFamily: 'DM Sans, sans-serif', color: '#e8edf5', outline: 'none', transition: 'all 0.2s' }}
                onFocus={e => { e.target.style.borderColor = 'rgba(79,156,249,0.5)'; e.target.style.boxShadow = '0 0 0 3px rgba(79,156,249,0.1)'; }}
                onBlur={e => { e.target.style.borderColor = 'rgba(255,255,255,0.1)'; e.target.style.boxShadow = 'none'; }}
              />
            </div>
            <button type="submit" disabled={loading} style={{
              width: '100%', padding: '12px', borderRadius: 10,
              background: loading ? 'rgba(79,156,249,0.5)' : '#4f9cf9',
              color: '#000', border: 'none', fontWeight: 700, fontSize: 14,
              fontFamily: 'DM Sans, sans-serif', cursor: loading ? 'not-allowed' : 'pointer',
              transition: 'all 0.2s', letterSpacing: '0.2px',
              boxShadow: '0 0 20px rgba(79,156,249,0.3)',
            }}>
              {loading ? 'Signing in…' : 'Sign In →'}
            </button>
          </form>

          {/* Demo roles */}
          <div style={{ marginTop: 28, padding: 16, background: 'rgba(15,20,32,0.8)', borderRadius: 14, border: '1px solid rgba(255,255,255,0.08)' }}>
            <div style={{ fontSize: 9, fontFamily: 'DM Mono, monospace', color: 'rgba(255,255,255,0.25)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: 12 }}>Demo Access — click to fill</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
              {DEMO_ROLES.map(d => (
                <button key={d.role} onClick={() => fill(d)} style={{
                  display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px',
                  background: selected === d.role ? `${d.color}12` : 'rgba(255,255,255,0.03)',
                  border: `1px solid ${selected === d.role ? d.color + '40' : 'rgba(255,255,255,0.07)'}`,
                  borderRadius: 10, cursor: 'pointer', transition: 'all 0.2s', textAlign: 'left',
                  boxShadow: selected === d.role ? `0 0 12px ${d.color}22` : 'none',
                }}>
                  <div style={{ width: 32, height: 32, borderRadius: 8, background: `${d.color}18`, border: `1px solid ${d.color}33`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>{d.icon}</div>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: selected === d.role ? d.color : '#e8edf5', fontFamily: 'Syne, sans-serif' }}>{d.label}</div>
                    <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', fontFamily: 'DM Mono, monospace', marginTop: 1 }}>{d.desc}</div>
                  </div>
                </button>
              ))}
            </div>
            <div style={{ marginTop: 12, fontSize: 10, fontFamily: 'DM Mono, monospace', color: 'rgba(255,255,255,0.2)' }}>Password for all: <span style={{ color: 'rgba(255,255,255,0.4)' }}>demo1234</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}
