import { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import api from '../api';
import toast from 'react-hot-toast';

const PAYMENT_BADGE = { paid: 'badge-success', pending: 'badge-warning', overdue: 'badge-danger' };

export default function Budget() {
  const [projects, setProjects] = useState([]);
  const [selProject, setSelProject] = useState('');
  const [budgetData, setBudgetData] = useState({ categories: [], summary: {} });
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState('overview');
  const [showCatModal, setShowCatModal] = useState(false);
  const [showExpModal, setShowExpModal] = useState(false);
  const [catForm, setCatForm] = useState({ name: '', estimated: '' });
  const [expForm, setExpForm] = useState({ category_id: '', description: '', amount: '', date: new Date().toISOString().split('T')[0], payment_status: 'pending', bill_ref: '' });

  useEffect(() => { api.get('/projects').then(r => { setProjects(r.data); if (r.data.length) setSelProject(r.data[0].id); }); }, []);
  useEffect(() => {
    if (!selProject) return;
    setLoading(true);
    Promise.all([api.get(`/budget/project/${selProject}`), api.get(`/budget/project/${selProject}/expenses`)])
      .then(([b, e]) => { setBudgetData(b.data); setExpenses(e.data); }).finally(() => setLoading(false));
  }, [selProject]);

  const reload = () => Promise.all([api.get(`/budget/project/${selProject}`), api.get(`/budget/project/${selProject}/expenses`)]).then(([b, e]) => { setBudgetData(b.data); setExpenses(e.data); });

  const addCategory = async (e) => {
    e.preventDefault();
    try { await api.post('/budget/category', { project_id: selProject, name: catForm.name, estimated: Number(catForm.estimated) }); toast.success('Category added'); setShowCatModal(false); setCatForm({ name: '', estimated: '' }); reload(); } catch { toast.error('Failed'); }
  };

  const addExpense = async (e) => {
    e.preventDefault();
    try { await api.post('/budget/expense', { ...expForm, project_id: selProject, amount: Number(expForm.amount) }); toast.success('Expense recorded'); setShowExpModal(false); setExpForm({ category_id: '', description: '', amount: '', date: new Date().toISOString().split('T')[0], payment_status: 'pending', bill_ref: '' }); reload(); } catch { toast.error('Failed'); }
  };

  const markPaid = async (exp) => {
    try { await api.put(`/budget/expense/${exp.id}`, { ...exp, payment_status: 'paid' }); toast.success('Marked as paid'); reload(); } catch { toast.error('Failed'); }
  };

  const { categories, summary } = budgetData;
  const chartData = categories.map(c => ({ name: c.name.length > 12 ? c.name.slice(0, 12) + '…' : c.name, Estimated: Math.round(c.estimated / 1000), Actual: Math.round(c.actual / 1000) }));
  const overallPct = summary.total_estimated ? ((summary.total_actual / summary.total_estimated) * 100).toFixed(1) : 0;

  return (
    <div className="page">
      <div className="page-header">
        <div><div className="page-title">Budget Tracker</div><div className="page-subtitle">Estimated vs actual expenses with payment tracking</div></div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-secondary" onClick={() => setShowCatModal(true)}>+ Category</button>
          <button className="btn btn-primary" onClick={() => setShowExpModal(true)}>+ Expense</button>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 12, marginBottom: 24, alignItems: 'center' }}>
        <select className="form-control" style={{ width: 300 }} value={selProject} onChange={e => setSelProject(e.target.value)}>
          {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <div style={{ display: 'flex', border: '1px solid var(--border)', borderRadius: 8, overflow: 'hidden' }}>
          {['overview', 'expenses'].map(t => <button key={t} className="btn" style={{ borderRadius: 0, background: tab === t ? 'var(--brand)' : 'var(--surface)', color: tab === t ? '#fff' : 'var(--text2)' }} onClick={() => setTab(t)}>{t === 'overview' ? '📊 Overview' : '🧾 Expenses'}</button>)}
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-4" style={{ marginBottom: 24 }}>
        {[
          ['💰', 'Total Budget', `₹${((summary.total_estimated || 0) / 100000).toFixed(2)}L`, '#FFF0EA', '#C2410C'],
          ['💸', 'Amount Spent', `₹${((summary.total_actual || 0) / 100000).toFixed(2)}L`, '#FEE2E2', '#B91C1C'],
          ['✅', 'Remaining',    `₹${((summary.remaining || 0) / 100000).toFixed(2)}L`, '#DCFCE7', '#15803D'],
          ['📈', 'Utilization',  `${overallPct}%`, '#DBEAFE', '#1D4ED8'],
        ].map(([icon, label, val, bg, fg]) => (
          <div key={label} style={{ background: bg, borderRadius: 'var(--radius)', padding: '18px 20px', display: 'flex', gap: 14, alignItems: 'center' }}>
            <span style={{ fontSize: 26 }}>{icon}</span>
            <div><div style={{ fontSize: 22, fontWeight: 800, lineHeight: 1, color: fg }}>{val}</div><div style={{ fontSize: 12, color: fg, opacity: 0.75, marginTop: 3 }}>{label}</div></div>
          </div>
        ))}
      </div>

      {loading ? <div className="spinner"><div className="spin" /></div> : tab === 'overview' ? (
        <div>
          {chartData.length > 0 && (
            <div className="card" style={{ marginBottom: 24 }}>
              <div className="card-header"><span className="card-title">Budget vs Actual (₹ in Thousands)</span></div>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={chartData} barSize={20}>
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip formatter={v => `₹${v}K`} />
                  <Bar dataKey="Estimated" fill="#E4E6EF" radius={4} />
                  <Bar dataKey="Actual" radius={4}>
                    {chartData.map((c, i) => <Cell key={i} fill={c.Actual > c.Estimated ? '#EF4444' : '#FF6B2B'} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
            {categories.length === 0 ? <div className="empty-state" style={{ padding: 60 }}><div className="icon">💰</div><h3>No budget categories yet</h3></div> : (
              <div className="table-wrap">
                <table>
                  <thead><tr><th>Category</th><th>Estimated</th><th>Actual</th><th>Remaining</th><th>Utilization</th><th>Status</th></tr></thead>
                  <tbody>
                    {categories.map(c => (
                      <tr key={c.id}>
                        <td style={{ fontWeight: 600 }}>{c.name}</td>
                        <td>₹{c.estimated.toLocaleString('en-IN')}</td>
                        <td>₹{c.actual.toLocaleString('en-IN')}</td>
                        <td style={{ color: c.over_budget ? 'var(--danger)' : 'var(--success)', fontWeight: 600 }}>₹{(c.estimated - c.actual).toLocaleString('en-IN')}</td>
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                            <div className="progress-bar" style={{ width: 80 }}>
                              <div className="progress-fill" style={{ width: `${Math.min(c.utilization_pct || 0, 100)}%`, background: c.over_budget ? 'var(--danger)' : 'var(--brand)' }} />
                            </div>
                            <span style={{ fontSize: 12 }}>{c.utilization_pct || 0}%</span>
                          </div>
                        </td>
                        <td>{c.over_budget ? <span className="badge badge-danger">⚠️ Over Budget</span> : <span className="badge badge-success">✅ On Track</span>}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          {expenses.length === 0 ? <div className="empty-state" style={{ padding: 60 }}><div className="icon">🧾</div><h3>No expenses recorded yet</h3></div> : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Description</th><th>Category</th><th>Amount</th><th>Date</th><th>Bill Ref</th><th>Payment</th><th>Action</th></tr></thead>
                <tbody>
                  {expenses.map(e => (
                    <tr key={e.id}>
                      <td><div style={{ fontWeight: 600 }}>{e.description}</div><div style={{ fontSize: 12, color: 'var(--text2)' }}>by {e.added_by_name}</div></td>
                      <td><span className="badge badge-gray">{e.category_name}</span></td>
                      <td style={{ fontWeight: 700 }}>₹{e.amount.toLocaleString('en-IN')}</td>
                      <td>{e.date}</td>
                      <td style={{ fontSize: 12, color: 'var(--text2)' }}>{e.bill_ref || '—'}</td>
                      <td><span className={`badge ${PAYMENT_BADGE[e.payment_status]}`}>{e.payment_status}</span></td>
                      <td>{e.payment_status !== 'paid' && <button className="btn btn-sm btn-success" onClick={() => markPaid(e)}>Mark Paid</button>}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Category Modal */}
      {showCatModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowCatModal(false)}>
          <div className="modal" style={{ maxWidth: 420 }}>
            <div className="modal-header"><span className="modal-title">Add Budget Category</span><button className="btn btn-sm btn-secondary" onClick={() => setShowCatModal(false)}>✕</button></div>
            <form onSubmit={addCategory}>
              <div className="form-group"><label className="form-label">Category Name *</label><input className="form-control" value={catForm.name} onChange={e => setCatForm({ ...catForm, name: e.target.value })} placeholder="e.g. Materials, Labour" required /></div>
              <div className="form-group"><label className="form-label">Estimated Budget (₹)</label><input type="number" className="form-control" value={catForm.estimated} onChange={e => setCatForm({ ...catForm, estimated: e.target.value })} /></div>
              <div className="modal-footer"><button type="button" className="btn btn-secondary" onClick={() => setShowCatModal(false)}>Cancel</button><button type="submit" className="btn btn-primary">Add Category</button></div>
            </form>
          </div>
        </div>
      )}

      {/* Expense Modal */}
      {showExpModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowExpModal(false)}>
          <div className="modal">
            <div className="modal-header"><span className="modal-title">Record Expense</span><button className="btn btn-sm btn-secondary" onClick={() => setShowExpModal(false)}>✕</button></div>
            <form onSubmit={addExpense}>
              <div className="form-group"><label className="form-label">Category *</label>
                <select className="form-control" value={expForm.category_id} onChange={e => setExpForm({ ...expForm, category_id: e.target.value })} required>
                  <option value="">Select category</option>
                  {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="form-group"><label className="form-label">Description *</label><input className="form-control" value={expForm.description} onChange={e => setExpForm({ ...expForm, description: e.target.value })} required /></div>
              <div className="grid grid-2">
                <div className="form-group"><label className="form-label">Amount (₹) *</label><input type="number" className="form-control" value={expForm.amount} onChange={e => setExpForm({ ...expForm, amount: e.target.value })} required /></div>
                <div className="form-group"><label className="form-label">Date</label><input type="date" className="form-control" value={expForm.date} onChange={e => setExpForm({ ...expForm, date: e.target.value })} /></div>
              </div>
              <div className="grid grid-2">
                <div className="form-group"><label className="form-label">Payment Status</label>
                  <select className="form-control" value={expForm.payment_status} onChange={e => setExpForm({ ...expForm, payment_status: e.target.value })}>
                    <option value="pending">Pending</option><option value="paid">Paid</option><option value="overdue">Overdue</option>
                  </select>
                </div>
                <div className="form-group"><label className="form-label">Bill / Invoice Ref</label><input className="form-control" value={expForm.bill_ref} onChange={e => setExpForm({ ...expForm, bill_ref: e.target.value })} placeholder="INV-001" /></div>
              </div>
              <div className="modal-footer"><button type="button" className="btn btn-secondary" onClick={() => setShowExpModal(false)}>Cancel</button><button type="submit" className="btn btn-primary">Record Expense</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
