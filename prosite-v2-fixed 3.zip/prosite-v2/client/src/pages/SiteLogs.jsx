import { useState, useEffect, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import api from '../api';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';

function PhotoUploader({ logId, onDone }) {
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const onDrop = useCallback(accepted => setFiles(prev => [...prev, ...accepted]), []);
  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop, accept: { 'image/*': [] }, maxFiles: 10 });
  const upload = async () => {
    setUploading(true);
    const fd = new FormData();
    files.forEach(f => fd.append('photos', f));
    try { await api.post(`/logs/${logId}/photos`, fd, { headers: { 'Content-Type': 'multipart/form-data' } }); toast.success(`${files.length} photo(s) uploaded`); setFiles([]); onDone(); }
    catch { toast.error('Upload failed'); } finally { setUploading(false); }
  };
  return (
    <div>
      <div {...getRootProps()} style={{ border: '2px dashed var(--border)', borderRadius: 10, padding: 20, textAlign: 'center', cursor: 'pointer', background: isDragActive ? 'var(--brand-light)' : 'var(--bg)', transition: 'all 0.15s' }}>
        <input {...getInputProps()} />
        <div style={{ fontSize: 28 }}>📷</div>
        <div style={{ marginTop: 6, fontSize: 13, color: 'var(--text2)' }}>{isDragActive ? 'Drop photos here' : 'Drag & drop or click to browse'}</div>
      </div>
      {files.length > 0 && (
        <div style={{ marginTop: 10 }}>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 8 }}>
            {files.map((f, i) => (
              <div key={i} style={{ position: 'relative' }}>
                <img src={URL.createObjectURL(f)} alt="" style={{ width: 70, height: 70, objectFit: 'cover', borderRadius: 8 }} />
                <button onClick={() => setFiles(files.filter((_,j) => j!==i))} style={{ position:'absolute', top:-6, right:-6, background:'var(--danger)', color:'#fff', border:'none', borderRadius:'50%', width:18, height:18, cursor:'pointer', fontSize:10 }}>✕</button>
              </div>
            ))}
          </div>
          <button className="btn btn-primary btn-sm" onClick={upload} disabled={uploading}>{uploading ? 'Uploading…' : `Upload ${files.length} Photo(s)`}</button>
        </div>
      )}
    </div>
  );
}

export default function SiteLogs() {
  const { user } = useAuth();
  const [projects, setProjects] = useState([]);
  const [logs, setLogs] = useState([]);
  const [selProject, setSelProject] = useState('');
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [quickMode, setQuickMode] = useState(true);
  const [expandedLog, setExpandedLog] = useState(null);
  const [logDetail, setLogDetail] = useState(null);
  const [form, setForm] = useState({ date: new Date().toISOString().split('T')[0], work_done: '', issues: '', weather: 'Sunny', manpower: '' });
  const weatherOptions = ['Sunny','Cloudy','Partly Cloudy','Rainy','Humid','Windy'];

  useEffect(() => { api.get('/projects').then(r => { setProjects(r.data); if (r.data.length) setSelProject(r.data[0].id); }); }, []);
  useEffect(() => { if (!selProject) return; setLoading(true); api.get(`/logs/project/${selProject}`).then(r => setLogs(r.data)).finally(() => setLoading(false)); }, [selProject]);

  const openLog = async id => {
    if (expandedLog === id) { setExpandedLog(null); setLogDetail(null); return; }
    setExpandedLog(id);
    const r = await api.get(`/logs/${id}`);
    setLogDetail(r.data);
  };

  const save = async (e) => {
    e.preventDefault();
    try {
      await api.post('/logs', { ...form, project_id: selProject, is_quick_log: quickMode ? 1 : 0 });
      toast.success(quickMode ? '⚡ Quick log saved!' : '📋 Site log created!');
      setShowModal(false);
      setForm({ date: new Date().toISOString().split('T')[0], work_done: '', issues: '', weather: 'Sunny', manpower: '' });
      api.get(`/logs/project/${selProject}`).then(r => setLogs(r.data));
    } catch { toast.error('Failed to save log'); }
  };

  const deleteLog = async id => {
    if (!window.confirm('Delete this log?')) return;
    await api.delete(`/logs/${id}`);
    setLogs(logs.filter(l => l.id !== id));
    toast.success('Deleted');
  };

  return (
    <div className="page">
      <div className="page-header">
        <div><div className="page-title">Daily Site Logs</div><div className="page-subtitle">Photo-backed daily records</div></div>
        <div style={{ display:'flex', gap:8 }}>
          <button className="btn btn-secondary" onClick={() => { setQuickMode(true); setShowModal(true); }}>⚡ Quick Log</button>
          <button className="btn btn-primary" onClick={() => { setQuickMode(false); setShowModal(true); }}>+ Full Log</button>
        </div>
      </div>

      <div style={{ display:'flex', gap:12, marginBottom:24, alignItems:'center' }}>
        <label style={{ fontSize:13, fontWeight:500, color:'var(--text2)' }}>Project:</label>
        <select className="form-control" style={{ width:300 }} value={selProject} onChange={e => setSelProject(e.target.value)}>
          {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </div>

      {loading ? <div className="spinner"><div className="spin"/></div> : (
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {logs.length === 0 && <div className="empty-state"><div className="icon">📋</div><h3>No logs yet</h3><p>Tap ⚡ Quick Log for a 30-second entry</p></div>}
          {logs.map(log => (
            <div key={log.id} className="card" style={{ padding:0, overflow:'hidden' }}>
              <div style={{ padding:'14px 20px', display:'flex', alignItems:'center', justifyContent:'space-between', cursor:'pointer' }} onClick={() => openLog(log.id)}>
                <div style={{ display:'flex', gap:14, alignItems:'center' }}>
                  <div style={{ background:'var(--brand-light)', borderRadius:10, padding:'8px 14px', textAlign:'center', flexShrink:0 }}>
                    <div style={{ fontSize:18, fontWeight:800, color:'var(--brand)', lineHeight:1 }}>{new Date(log.date).getDate()}</div>
                    <div style={{ fontSize:10, color:'var(--brand)', textTransform:'uppercase' }}>{new Date(log.date).toLocaleString('en',{month:'short'})}</div>
                  </div>
                  <div>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                      <div style={{ fontWeight:600, fontSize:14 }}>{log.work_done?.slice(0,75)}{log.work_done?.length > 75 ? '…' : ''}</div>
                      {log.is_quick_log ? <span className="badge badge-brand" style={{ fontSize:10 }}>⚡ Quick</span> : null}
                    </div>
                    <div style={{ fontSize:12, color:'var(--text2)', marginTop:3 }}>by {log.logged_by} · {log.manpower} workers · {log.weather} · 📷 {log.photo_count}</div>
                  </div>
                </div>
                <div style={{ display:'flex', gap:6, alignItems:'center', flexShrink:0 }}>
                  {log.issues && log.issues !== 'None' && <span className="badge badge-warning">⚠️ Issue</span>}
                  <span style={{ color:'var(--text3)', fontSize:16 }}>{expandedLog===log.id ? '▲' : '▼'}</span>
                </div>
              </div>

              {expandedLog===log.id && logDetail?.id===log.id && (
                <div style={{ padding:'0 20px 20px', borderTop:'1px solid var(--border)' }}>
                  <div className="grid grid-2" style={{ marginTop:16, gap:20 }}>
                    <div>
                      <div style={{ fontWeight:600, fontSize:12, color:'var(--text2)', textTransform:'uppercase', marginBottom:8 }}>Work Done</div>
                      <p style={{ fontSize:14, lineHeight:1.7 }}>{logDetail.work_done}</p>
                      {logDetail.issues && (
                        <div style={{ marginTop:14, padding:12, background:'#FEF9C3', borderRadius:8, borderLeft:'3px solid #F59E0B' }}>
                          <div style={{ fontWeight:700, fontSize:11, color:'#854D0E', marginBottom:4 }}>⚠️ ISSUES</div>
                          <p style={{ fontSize:13, color:'#854D0E' }}>{logDetail.issues}</p>
                        </div>
                      )}
                      <div style={{ marginTop:12, display:'flex', gap:12, fontSize:12, color:'var(--text2)' }}>
                        <span>🌤️ {logDetail.weather}</span>
                        <span>👷 {logDetail.manpower} workers</span>
                        <span>📅 {logDetail.date}</span>
                      </div>
                    </div>
                    <div>
                      <div style={{ fontWeight:600, fontSize:12, color:'var(--text2)', textTransform:'uppercase', marginBottom:8 }}>Photos ({logDetail.photos?.length||0})</div>
                      <div style={{ display:'flex', flexWrap:'wrap', gap:8, marginBottom:12 }}>
                        {logDetail.photos?.map(p => (
                          <img key={p.id} src={`http://localhost:5000/uploads/${p.filename}`} alt="" style={{ width:85, height:85, objectFit:'cover', borderRadius:8, border:'2px solid var(--border)', cursor:'pointer' }} onClick={() => window.open(`http://localhost:5000/uploads/${p.filename}`,'_blank')} />
                        ))}
                      </div>
                      <PhotoUploader logId={log.id} onDone={() => openLog(log.id)} />
                    </div>
                  </div>
                  <div style={{ marginTop:14 }}>
                    <button className="btn btn-danger btn-sm" onClick={() => deleteLog(log.id)}>🗑️ Delete Log</button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Log Modal — quick or full */}
      {showModal && (
        <div className="modal-overlay" onClick={e => e.target===e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <div style={{ display:'flex', gap:10, alignItems:'center' }}>
                {quickMode && <div style={{ background:'var(--brand-light)', borderRadius:8, padding:'6px 10px', fontSize:18 }}>⚡</div>}
                <div>
                  <div className="modal-title">{quickMode ? 'Quick Log' : 'Full Site Log'}</div>
                  {quickMode && <div style={{ fontSize:12, color:'var(--text2)' }}>Done in 30 seconds</div>}
                </div>
              </div>
              <div style={{ display:'flex', gap:6, alignItems:'center' }}>
                <button className="btn btn-ghost btn-sm" onClick={() => setQuickMode(!quickMode)} style={{ fontSize:12 }}>{quickMode ? 'Switch to Full' : 'Switch to Quick'}</button>
                <button className="btn btn-ghost btn-icon btn-sm" onClick={() => setShowModal(false)}>✕</button>
              </div>
            </div>
            <form onSubmit={save}>
              <div className="form-group">
                <label className="form-label">Project</label>
                <select className="form-control" value={selProject} onChange={e => setSelProject(e.target.value)}>
                  {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div className={quickMode ? '' : 'grid grid-2'}>
                <div className="form-group"><label className="form-label">Date</label><input type="date" className="form-control" value={form.date} onChange={e => setForm({...form, date:e.target.value})} /></div>
                <div className="form-group"><label className="form-label">Workers on Site</label><input type="number" className="form-control" value={form.manpower} onChange={e => setForm({...form, manpower:e.target.value})} placeholder="e.g. 42" /></div>
              </div>
              {!quickMode && (
                <div className="form-group"><label className="form-label">Weather</label>
                  <select className="form-control" value={form.weather} onChange={e => setForm({...form, weather:e.target.value})}>
                    {weatherOptions.map(w => <option key={w}>{w}</option>)}
                  </select>
                </div>
              )}
              <div className="form-group">
                <label className="form-label">Work Done Today *</label>
                <textarea className="form-control" rows={quickMode ? 3 : 4} value={form.work_done} onChange={e => setForm({...form, work_done:e.target.value})} placeholder={quickMode ? "What was done today? (keep it short)" : "Describe in detail what was completed today..."} required />
              </div>
              {!quickMode && (
                <div className="form-group"><label className="form-label">Issues / Problems</label><textarea className="form-control" rows={2} value={form.issues} onChange={e => setForm({...form, issues:e.target.value})} placeholder="Any issues, delays, or blockers..." /></div>
              )}
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">{quickMode ? '⚡ Save Quick Log' : '📋 Save Full Log'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
