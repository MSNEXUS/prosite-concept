import { createContext, useContext, useState, useEffect } from 'react';
import api from '../api';

const AuthContext = createContext();

const ROLE_THEME = { owner: 'owner', engineer: 'engineer', supervisor: 'supervisor', client: 'client' };

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('prosite_user')); } catch { return null; }
  });

  useEffect(() => {
    if (user?.role) {
      document.body.setAttribute('data-role', ROLE_THEME[user.role] || 'default');
    } else {
      document.body.removeAttribute('data-role');
    }
  }, [user]);

  const login = async (email, password) => {
    const res = await api.post('/auth/login', { email, password });
    localStorage.setItem('prosite_token', res.data.token);
    localStorage.setItem('prosite_user', JSON.stringify(res.data.user));
    setUser(res.data.user);
    return res.data.user;
  };

  const logout = () => {
    localStorage.removeItem('prosite_token');
    localStorage.removeItem('prosite_user');
    document.body.removeAttribute('data-role');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
