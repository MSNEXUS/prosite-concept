import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../api';
import toast from 'react-hot-toast';

const STATUS_STYLE = {
  pending:     { bg: '#F3F4F6', color: '#6B7280', icon: '⏳' },
  in_progress: { bg: '#DBEAFE', color: '#1D4ED8', icon: '🔄' },
  completed:   { bg: '#DCFCE7', color: '#15803D', icon: '✅' },
};

export default function ClientView() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('overview');
  const [lightbox, setLightbox] = useState(null);

  useEffect(() => {
    api.get('/projects').then(async r => {
      if (!r.data.length) { setLoading(false); return; }
      const project = r.data[0];
      const summary = await api.get(`/projects/${project.id}/client-summary`);
      setData(summary.data);
    }).finally(() => setLoading(false));
  }, []);

  const approveMilestone = async (id) => {
    await api.put(`/milestones/${id}/approve`);
    toast.success('Milestone approved! Owner has been notified.');
    const summary = await api.get(`/projects/${data.project.id}/client-summary`);
    setData(summary.data);
  };

  if (loading) return <div className="spinner"><div className="spin" /></div>;
  if (!data) return (
    <div className="page"><div className="empty-state"><div className="icon">🏗️</div><h3>No project assigned</h3><p>Contact your project manager to get access.</p></div></div>
  );

  const { project, budget, milestones, photos, tasks_summary } = data;
  const completedTasks = tasks_summary.find(t => t.status === 'completed')?.count || 0;
  const totalTasks = tasks_summary.reduce((a, t) => a + t.count, 0);
  const budgetPct = budget?.estimated ? ((budget.actual / budget.estimated) * 100).toFixed(1) : 0;
  const completedMilestones = milestones.filter(m => m.status === 'completed').length;
  const totalPaymentReleased = milestones.filter(m => m.client_approved).reduce((a, m) => a + (m.payment_amount || 0), 0);

  const TABS = ['overview', 'photos', 'milestones', 'budget'];

  return (
    <div className="page">
      {/* Hero header */}
      <div style={{ background: 'linear-gradient(135deg, var(--brand), var(--brand-dark))', borderRadius: 16, padding: '28px 32px', marginBottom: 28, color: '#fff', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: -30, right: -30, width: 160, height: 160, background: 'rgba(255,255,255,0.07)', borderRadius: '50%' }} />
        <div style={{ position: 'absolute', bottom: -40, right: 80, width: 100, height: 100, background: 'rgba(255,255,255,0.05)', borderRadius: '50%' }} />
        <div style={{ fontSize: 12, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '1px', opacity: 0.8, marginBottom: 8 }}>Your Project</div>
        <h1 style={{ fontSize: 26, fontFamily: 'Syne', fontWeight: 800, marginBottom: 4 }}>{project.name}</h1>
        <div style={{ opacity: 0.8, fontSize: 14 }}>📍 {project.location} &nbsp;·&nbsp; 👷 {project.manager_name}</div>
        <div style={{ marginTop: 20, display: 'flex', gap: 24, flexWrap: 'wrap' }}>
          {[['Progress', `${project.progress}%`], ['Deadline', project.end_date || '—'], ['Status', project.status]].map(([k, v]) => (
            <div key={k}><div style={{ fontSize: 11, opacity: 0.65, textTransform: 'uppercase', letterSpacing: '0.5px' }}>{k}</div><div style={{ fontSize: 20, fontWeight: 800, fontFamily: 'Syne', marginTop: 2 }}>{v}</div></div>
          ))}
        </div>
        <div style={{ marginTop: 16 }}>
          <div style={{ height: 8, background: 'rgba(255,255,255,0.25)', borderRadius: 4, overflow: 'hidden' }}>
            <div style={{ height: '100%', width: `${project.progress}%`, background: '#fff', borderRadius: 4, transition: 'width 0.6s ease' }} />
          </div>
        </div>
      </div>

      {/* Quick stats */}
      <div className="grid grid-4" style={{ marginBottom: 24 }}>
        {[
          ['🏁', 'Milestones Done', `${completedMilestones}/${milestones.length}`, '#DCFCE7'],
          ['✅', 'Tasks Complete', `${completedTasks}/${totalTasks}`, '#DBEAFE'],
          ['💰', 'Budget Used', `${budgetPct}%`, '#FFF0EA'],
          ['💸', 'Payment Released', `₹${(totalPaymentReleased/100000).toFixed(1)}L`, '#F3E8FF'],
        ].map(([icon, label, value, bg]) => (
          <div key={label} style={{ background: bg, borderRadius: 14, padding: '18px 20px', display: 'flex', gap: 14, alignItems: 'center' }}>
            <span style={{ fontSize: 26 }}>{icon}</span>
            <div><div style={{ fontSize: 22, fontWeight: 800, fontFamily: 'Syne', lineHeight: 1 }}>{value}</div><div style={{ fontSize: 12, color: 'var(--text2)', marginTop: 4 }}>{label}</div></div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 24, background: 'var(--surface)', borderRadius: 10, padding: 4, width: 'fit-content', boxShadow: 'var(--shadow)' }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} className="btn btn-sm" style={{ borderRadius: 8, background: tab === t ? 'var(--brand)' : 'transparent', color: tab === t ? '#fff' : 'var(--text2)', textTransform: 'capitalize', fontWeight: tab === t ? 600 : 400 }}>
            {t === 'overview' ? '📊 Overview' : t === 'photos' ? `📸 Photos (${photos.length})` : t === 'milestones' ? `🏁 Milestones` : '💰 Budget'}
          </button>
        ))}
      </div>

      {/* Overview */}
      {tab === 'overview' && (
        <div className="grid grid-2">
          <div className="card">
            <div className="card-header"><span className="card-title">📊 Project Details</span></div>
            {[['Description', project.description || '—'], ['Start Date', project.start_date || '—'], ['Expected Completion', project.end_date || '—'], ['Site Manager', project.manager_name || '—'], ['Current Status', project.status]].map(([k, v]) => (
              <div key={k} style={{ display: 'flex', gap: 12, padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                <span style={{ width: 130, fontSize: 13, color: 'var(--text2)', flexShrink: 0 }}>{k}</span>
                <span style={{ fontSize: 13, fontWeight: 500, textTransform: k === 'Current Status' ? 'capitalize' : 'none' }}>{v}</span>
              </div>
            ))}
          </div>
          <div className="card">
            <div className="card-header"><span className="card-title">🏁 Milestone Summary</span></div>
            {milestones.slice(0, 5).map(m => (
              <div key={m.id} style={{ display: 'flex', gap: 12, padding: '10px 0', borderBottom: '1px solid var(--border)', alignItems: 'center' }}>
                <span style={{ fontSize: 18 }}>{STATUS_STYLE[m.status]?.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{m.title}</div>
                  <div style={{ fontSize: 11, color: 'var(--text2)' }}>{m.target_date} · ₹{((m.payment_amount||0)/100000).toFixed(1)}L</div>
                </div>
                <span className="badge" style={{ background: STATUS_STYLE[m.status]?.bg, color: STATUS_STYLE[m.status]?.color }}>{m.status.replace('_',' ')}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Photo timeline */}
      {tab === 'photos' && (
        <div className="card">
          <div className="card-header"><span className="card-title">📸 Site Photo Timeline</span><span style={{ fontSize: 13, color: 'var(--text2)' }}>{photos.length} photos</span></div>
          {photos.length === 0 ? <div className="empty-state"><div className="icon">📷</div><h3>No photos yet</h3><p>Site photos will appear here as work progresses.</p></div> : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 12 }}>
              {photos.map(p => (
                <div key={p.id} style={{ position: 'relative', cursor: 'pointer' }} onClick={() => setLightbox(p)}>
                  <img src={`http://localhost:5000/uploads/${p.filename}`} alt="" style={{ width: '100%', height: 140, objectFit: 'cover', borderRadius: 10, border: '2px solid var(--border)' }}
                    onError={e => { e.target.style.display='none'; e.target.nextSibling.style.display='flex'; }} />
                  <div style={{ display: 'none', width: '100%', height: 140, borderRadius: 10, background: 'var(--surface2)', alignItems: 'center', justifyContent: 'center', fontSize: 32 }}>📷</div>
                  <div style={{ position: 'absolute', bottom: 6, left: 6, background: 'rgba(0,0,0,0.6)', color: '#fff', borderRadius: 6, padding: '2px 8px', fontSize: 11 }}>{p.date}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Milestones */}
      {tab === 'milestones' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {milestones.map((m, idx) => (
            <div key={m.id} className="card" style={{ display: 'flex', gap: 20, alignItems: 'flex-start', borderLeft: `4px solid ${m.status === 'completed' ? 'var(--success)' : m.status === 'in_progress' ? 'var(--brand)' : 'var(--border)'}` }}>
              <div style={{ width: 40, height: 40, borderRadius: '50%', background: STATUS_STYLE[m.status]?.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>{STATUS_STYLE[m.status]?.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15 }}>{m.title}</div>
                    <div style={{ fontSize: 13, color: 'var(--text2)', marginTop: 3 }}>{m.description}</div>
                    <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 6 }}>Target: {m.target_date} · Payment: ₹{((m.payment_amount||0)/100000).toFixed(1)}L</div>
                  </div>
                  <div style={{ textAlign: 'right', flexShrink: 0 }}>
                    <span className="badge" style={{ background: STATUS_STYLE[m.status]?.bg, color: STATUS_STYLE[m.status]?.color }}>{m.status.replace('_',' ')}</span>
                    {m.status === 'completed' && !m.client_approved && (
                      <div style={{ marginTop: 8 }}>
                        <button className="btn btn-success btn-sm" onClick={() => approveMilestone(m.id)}>✅ Approve & Release Payment</button>
                      </div>
                    )}
                    {m.client_approved && <div style={{ marginTop: 6, fontSize: 12, color: 'var(--success)', fontWeight: 600 }}>✅ Payment Released</div>}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Budget */}
      {tab === 'budget' && (
        <div className="grid grid-2">
          <div className="card">
            <div className="card-header"><span className="card-title">💰 Budget Overview</span></div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {[['Total Budget', `₹${((budget?.estimated||0)/100000).toFixed(2)}L`, 'var(--text)'],
                ['Amount Spent', `₹${((budget?.actual||0)/100000).toFixed(2)}L`, 'var(--brand)'],
                ['Remaining', `₹${(((budget?.estimated||0)-(budget?.actual||0))/100000).toFixed(2)}L`, 'var(--success)'],
              ].map(([label, val, color]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
                  <span style={{ fontSize: 14, color: 'var(--text2)' }}>{label}</span>
                  <span style={{ fontSize: 18, fontWeight: 800, fontFamily: 'Syne', color }}>{val}</span>
                </div>
              ))}
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontSize: 13 }}><span>Budget used</span><span style={{ fontWeight: 700 }}>{budgetPct}%</span></div>
                <div className="progress-bar" style={{ height: 12 }}>
                  <div className="progress-fill" style={{ width: `${Math.min(budgetPct, 100)}%`, background: budgetPct > 90 ? 'var(--danger)' : 'var(--brand)' }} />
                </div>
              </div>
            </div>
          </div>
          <div className="card">
            <div className="card-header"><span className="card-title">💸 Payment Schedule</span></div>
            {milestones.map(m => (
              <div key={m.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border)', alignItems: 'center' }}>
                <div><div style={{ fontWeight: 600, fontSize: 13 }}>{m.title}</div><div style={{ fontSize: 11, color: 'var(--text2)' }}>{m.target_date}</div></div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontWeight: 700 }}>₹{((m.payment_amount||0)/100000).toFixed(1)}L</div>
                  <span className="badge" style={{ fontSize: 10, background: m.client_approved ? '#DCFCE7' : m.status === 'completed' ? '#FEF9C3' : '#F3F4F6', color: m.client_approved ? '#15803D' : m.status === 'completed' ? '#854D0E' : '#6B7280' }}>
                    {m.client_approved ? '✅ Released' : m.status === 'completed' ? '⏳ Awaiting Approval' : '🔒 Locked'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Phase 2 features teaser */}
      <div className="card" style={{ marginTop: 24, background: 'var(--surface2)', border: '1px dashed var(--border)' }}>
        <div style={{ fontWeight: 600, marginBottom: 12, color: 'var(--text2)', fontSize: 13 }}>🚀 Coming Soon for You</div>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          {[['📄', 'Download Project Report'], ['💬', 'Message Site Manager'], ['📐', 'View Approved Drawings'], ['🔔', 'WhatsApp Updates']].map(([icon, label]) => (
            <button key={label} className="btn btn-secondary btn-sm" onClick={() => toast('This feature is coming in Phase 2! 🚀', { icon: '🚧' })} style={{ opacity: 0.7 }}>{icon} {label}</button>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div className="modal-overlay" onClick={() => setLightbox(null)}>
          <div style={{ maxWidth: '90vw', maxHeight: '90vh' }}>
            <img src={`http://localhost:5000/uploads/${lightbox.filename}`} alt="" style={{ maxWidth: '90vw', maxHeight: '85vh', borderRadius: 12, objectFit: 'contain' }} />
            <div style={{ color: '#fff', textAlign: 'center', marginTop: 8, fontSize: 13 }}>{lightbox.date}</div>
          </div>
        </div>
      )}
    </div>
  );
}
