import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import api from '../api';
import toast from 'react-hot-toast';

const ROLE_BADGE = { owner: 'badge-danger', engineer: 'badge-info', supervisor: 'badge-warning', worker: 'badge-gray' };

export default function Admin() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editUser, setEditUser] = useState(null);
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'supervisor', phone: '' });

  useEffect(() => {
    if (user?.role !== 'owner') { navigate('/'); return; }
    api.get('/admin/users').then(r => setUsers(r.data)).finally(() => setLoading(false));
  }, [user, navigate]);

  const openNew = () => { setEditUser(null); setForm({ name: '', email: '', password: '', role: 'supervisor', phone: '' }); setShowModal(true); };
  const openEdit = (u) => { setEditUser(u); setForm({ name: u.name, email: u.email, password: '', role: u.role, phone: u.phone || '' }); setShowModal(true); };

  const save = async (e) => {
    e.preventDefault();
    try {
      if (editUser) {
        await api.put(`/admin/users/${editUser.id}`, { name: form.name, role: form.role, phone: form.phone });
        if (form.password) await api.put(`/admin/users/${editUser.id}/reset-password`, { password: form.password });
        toast.success('User updated');
      } else {
        await api.post('/admin/users', form);
        toast.success('User created');
      }
      setShowModal(false);
      api.get('/admin/users').then(r => setUsers(r.data));
    } catch (err) { toast.error(err.response?.data?.error || 'Failed'); }
  };

  const deleteUser = async (id) => {
    if (!window.confirm('Delete this user?')) return;
    try { await api.delete(`/admin/users/${id}`); setUsers(users.filter(u => u.id !== id)); toast.success('User deleted'); } catch (err) { toast.error(err.response?.data?.error || 'Failed'); }
  };

  if (user?.role !== 'owner') return null;
  if (loading) return <div className="spinner"><div className="spin" /></div>;

  const roleCount = (role) => users.filter(u => u.role === role).length;

  return (
    <div className="page">
      <div className="page-header">
        <div><div className="page-title">Admin Panel</div><div className="page-subtitle">User management and access control</div></div>
        <button className="btn btn-primary" onClick={openNew}>+ Add User</button>
      </div>

      {/* Stats */}
      <div className="grid grid-4" style={{ marginBottom: 28 }}>
        {[['👥', 'Total Users', users.length, '#E0E7FF'],
          ['👑', 'Owners', roleCount('owner'), '#FFF0EA'],
          ['🔧', 'Engineers', roleCount('engineer'), '#DBEAFE'],
          ['👷', 'Supervisors', roleCount('supervisor'), '#DCFCE7']].map(([icon, label, val, bg]) => (
          <div key={label} style={{ background: bg, borderRadius: 'var(--radius)', padding: '18px 20px', display: 'flex', gap: 14, alignItems: 'center' }}>
            <span style={{ fontSize: 26 }}>{icon}</span>
            <div><div style={{ fontSize: 26, fontWeight: 800, lineHeight: 1 }}>{val}</div><div style={{ fontSize: 12, color: 'var(--text2)', marginTop: 3 }}>{label}</div></div>
          </div>
        ))}
      </div>

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)', fontWeight: 600 }}>All Users</div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Phone</th><th>Joined</th><th>Actions</th></tr></thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'var(--brand)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 14, flexShrink: 0 }}>{u.name.charAt(0)}</div>
                      <div style={{ fontWeight: 600 }}>{u.name}{u.id === user.id && <span style={{ fontSize: 11, color: 'var(--brand)', marginLeft: 6 }}>(You)</span>}</div>
                    </div>
                  </td>
                  <td style={{ color: 'var(--text2)' }}>{u.email}</td>
                  <td><span className={`badge ${ROLE_BADGE[u.role]}`} style={{ textTransform: 'capitalize' }}>{u.role}</span></td>
                  <td>{u.phone || '—'}</td>
                  <td style={{ color: 'var(--text2)', fontSize: 13 }}>{new Date(u.created_at).toLocaleDateString('en-IN')}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button className="btn btn-sm btn-secondary" onClick={() => openEdit(u)}>✏️ Edit</button>
                      {u.id !== user.id && <button className="btn btn-sm btn-danger" onClick={() => deleteUser(u.id)}>🗑️</button>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* System info */}
      <div className="card" style={{ marginTop: 24, background: 'var(--text)', color: '#fff' }}>
        <div style={{ fontWeight: 600, marginBottom: 16 }}>🖥️ System Info</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {[['Database', 'SQLite (prosite.db)'], ['Backend', 'Node.js + Express'], ['Frontend', 'React 18'], ['Auth', 'JWT (7 days)'], ['Photos', 'Local filesystem'], ['Environment', 'Development / Localhost']].map(([k, v]) => (
            <div key={k} style={{ background: 'rgba(255,255,255,0.07)', borderRadius: 8, padding: '10px 14px' }}>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginBottom: 4 }}>{k}</div>
              <div style={{ fontSize: 13, fontWeight: 600 }}>{v}</div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 16, padding: '12px 14px', background: 'rgba(255,107,43,0.2)', borderRadius: 8, fontSize: 13, color: 'rgba(255,255,255,0.8)', borderLeft: '3px solid var(--brand)' }}>
          ⚡ Phase 2 ready: AWS S3, PostgreSQL, WhatsApp API, and AI analytics can be plugged in without rewriting the codebase.
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <div className="modal-header"><span className="modal-title">{editUser ? 'Edit User' : 'Add New User'}</span><button className="btn btn-sm btn-secondary" onClick={() => setShowModal(false)}>✕</button></div>
            <form onSubmit={save}>
              <div className="form-group"><label className="form-label">Full Name *</label><input className="form-control" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required /></div>
              {!editUser && <div className="form-group"><label className="form-label">Email *</label><input type="email" className="form-control" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required /></div>}
              <div className="grid grid-2">
                <div className="form-group"><label className="form-label">Role</label>
                  <select className="form-control" value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}>
                    <option value="owner">Owner</option><option value="engineer">Engineer</option><option value="supervisor">Supervisor</option><option value="worker">Worker</option>
                  </select>
                </div>
                <div className="form-group"><label className="form-label">Phone</label><input className="form-control" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="9876543210" /></div>
              </div>
              <div className="form-group"><label className="form-label">{editUser ? 'New Password (leave blank to keep)' : 'Password *'}</label><input type="password" className="form-control" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required={!editUser} placeholder={editUser ? 'Leave blank to keep current' : ''} /></div>
              <div className="modal-footer"><button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button><button type="submit" className="btn btn-primary">{editUser ? 'Save Changes' : 'Create User'}</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
