import { useState, useEffect } from 'react';
import api from '../api';
import toast from 'react-hot-toast';

export default function Materials() {
  const [projects, setProjects] = useState([]);
  const [selProject, setSelProject] = useState('');
  const [materials, setMaterials] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [showTxn, setShowTxn] = useState(null);
  const [txns, setTxns] = useState([]);
  const [form, setForm] = useState({ name: '', unit: 'Bags', qty_received: '', min_stock: '', unit_cost: '', supplier: '' });
  const [txnForm, setTxnForm] = useState({ type: 'received', quantity: '', notes: '', date: new Date().toISOString().split('T')[0] });
  const UNITS = ['Bags', 'Tonnes', 'Loads', 'Nos', 'Sheets', 'Litres', 'Sq.ft', 'Cu.m', 'Kg', 'Sets'];

  useEffect(() => { api.get('/projects').then(r => { setProjects(r.data); if (r.data.length) setSelProject(r.data[0].id); }); }, []);
  useEffect(() => { if (!selProject) return; setLoading(true); api.get(`/materials/project/${selProject}`).then(r => setMaterials(r.data)).finally(() => setLoading(false)); }, [selProject]);

  const openTxn = async (mat) => {
    setShowTxn(mat);
    const r = await api.get(`/materials/${mat.id}/transactions`);
    setTxns(r.data);
  };

  const addMaterial = async (e) => {
    e.preventDefault();
    try {
      await api.post('/materials', { ...form, project_id: selProject, qty_received: Number(form.qty_received), min_stock: Number(form.min_stock), unit_cost: Number(form.unit_cost) });
      toast.success('Material added');
      setShowAdd(false);
      setForm({ name: '', unit: 'Bags', qty_received: '', min_stock: '', unit_cost: '', supplier: '' });
      api.get(`/materials/project/${selProject}`).then(r => setMaterials(r.data));
    } catch { toast.error('Failed to add material'); }
  };

  const recordTxn = async (e) => {
    e.preventDefault();
    try {
      const r = await api.post(`/materials/${showTxn.id}/transaction`, { ...txnForm, quantity: Number(txnForm.quantity) });
      toast.success(`Transaction recorded. Remaining: ${r.data.remaining} ${showTxn.unit}`);
      setTxnForm({ type: 'received', quantity: '', notes: '', date: new Date().toISOString().split('T')[0] });
      const [mats, txnsRes] = await Promise.all([api.get(`/materials/project/${selProject}`), api.get(`/materials/${showTxn.id}/transactions`)]);
      setMaterials(mats.data);
      setTxns(txnsRes.data);
      const updated = mats.data.find(m => m.id === showTxn.id);
      if (updated) setShowTxn(updated);
    } catch { toast.error('Failed to record transaction'); }
  };

  return (
    <div className="page">
      <div className="page-header">
        <div><div className="page-title">Material Tracking</div><div className="page-subtitle">Stock levels, usage, and alerts</div></div>
        <button className="btn btn-primary" onClick={() => setShowAdd(true)}>+ Add Material</button>
      </div>

      <div style={{ display: 'flex', gap: 12, marginBottom: 24, alignItems: 'center' }}>
        <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--text2)' }}>Project:</label>
        <select className="form-control" style={{ width: 300 }} value={selProject} onChange={e => setSelProject(e.target.value)}>
          {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        {materials.filter(m => m.low_stock).length > 0 && (
          <span className="badge badge-danger">🚨 {materials.filter(m => m.low_stock).length} Low Stock Alert(s)</span>
        )}
      </div>

      {loading ? <div className="spinner"><div className="spin" /></div> : (
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          {materials.length === 0 ? <div className="empty-state" style={{ padding: 60 }}><div className="icon">📦</div><h3>No materials tracked yet</h3></div> : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>Material</th><th>Unit</th><th>Received</th><th>Used</th><th>Remaining</th><th>Min Stock</th><th>Unit Cost</th><th>Total Value</th><th>Status</th><th>Action</th></tr>
                </thead>
                <tbody>
                  {materials.map(m => (
                    <tr key={m.id}>
                      <td>
                        <div style={{ fontWeight: 600 }}>{m.name}</div>
                        {m.supplier && <div style={{ fontSize: 11, color: 'var(--text2)' }}>{m.supplier}</div>}
                      </td>
                      <td>{m.unit}</td>
                      <td>{m.qty_received}</td>
                      <td>{m.qty_used}</td>
                      <td style={{ fontWeight: 700, color: m.low_stock ? 'var(--danger)' : 'var(--success)' }}>{m.qty_remaining}</td>
                      <td>{m.min_stock}</td>
                      <td>{m.unit_cost > 0 ? `₹${m.unit_cost.toLocaleString('en-IN')}` : '—'}</td>
                      <td>{m.unit_cost > 0 ? `₹${(m.qty_remaining * m.unit_cost).toLocaleString('en-IN')}` : '—'}</td>
                      <td>
                        {m.low_stock
                          ? <span className="badge badge-danger">🚨 Low Stock</span>
                          : <span className="badge badge-success">✅ OK</span>}
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: 6 }}>
                          <button className="btn btn-sm btn-secondary" onClick={() => openTxn(m)}>📝 Record</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Add Material Modal */}
      {showAdd && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowAdd(false)}>
          <div className="modal">
            <div className="modal-header"><span className="modal-title">Add Material</span><button className="btn btn-sm btn-secondary" onClick={() => setShowAdd(false)}>✕</button></div>
            <form onSubmit={addMaterial}>
              <div className="form-group"><label className="form-label">Material Name *</label><input className="form-control" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Cement (53 Grade)" required /></div>
              <div className="grid grid-2">
                <div className="form-group"><label className="form-label">Unit</label><select className="form-control" value={form.unit} onChange={e => setForm({ ...form, unit: e.target.value })}>{UNITS.map(u => <option key={u}>{u}</option>)}</select></div>
                <div className="form-group"><label className="form-label">Opening Stock</label><input type="number" className="form-control" value={form.qty_received} onChange={e => setForm({ ...form, qty_received: e.target.value })} placeholder="0" /></div>
              </div>
              <div className="grid grid-2">
                <div className="form-group"><label className="form-label">Min Stock Level</label><input type="number" className="form-control" value={form.min_stock} onChange={e => setForm({ ...form, min_stock: e.target.value })} placeholder="Alert below this" /></div>
                <div className="form-group"><label className="form-label">Unit Cost (₹)</label><input type="number" className="form-control" value={form.unit_cost} onChange={e => setForm({ ...form, unit_cost: e.target.value })} placeholder="0" /></div>
              </div>
              <div className="form-group"><label className="form-label">Supplier</label><input className="form-control" value={form.supplier} onChange={e => setForm({ ...form, supplier: e.target.value })} /></div>
              <div className="modal-footer"><button type="button" className="btn btn-secondary" onClick={() => setShowAdd(false)}>Cancel</button><button type="submit" className="btn btn-primary">Add Material</button></div>
            </form>
          </div>
        </div>
      )}

      {/* Transaction Modal */}
      {showTxn && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowTxn(null)}>
          <div className="modal" style={{ maxWidth: 600 }}>
            <div className="modal-header">
              <div><div className="modal-title">{showTxn.name}</div><div style={{ fontSize: 13, color: 'var(--text2)' }}>Remaining: <strong style={{ color: showTxn.low_stock ? 'var(--danger)' : 'var(--success)' }}>{showTxn.qty_remaining} {showTxn.unit}</strong></div></div>
              <button className="btn btn-sm btn-secondary" onClick={() => setShowTxn(null)}>✕</button>
            </div>
            <form onSubmit={recordTxn} style={{ marginBottom: 24 }}>
              <div style={{ fontWeight: 600, marginBottom: 12 }}>Record Transaction</div>
              <div className="grid grid-2">
                <div className="form-group"><label className="form-label">Type</label>
                  <select className="form-control" value={txnForm.type} onChange={e => setTxnForm({ ...txnForm, type: e.target.value })}>
                    <option value="received">📥 Received</option><option value="used">📤 Used</option>
                  </select>
                </div>
                <div className="form-group"><label className="form-label">Quantity ({showTxn.unit})</label><input type="number" className="form-control" value={txnForm.quantity} onChange={e => setTxnForm({ ...txnForm, quantity: e.target.value })} required /></div>
              </div>
              <div className="grid grid-2">
                <div className="form-group"><label className="form-label">Date</label><input type="date" className="form-control" value={txnForm.date} onChange={e => setTxnForm({ ...txnForm, date: e.target.value })} /></div>
                <div className="form-group"><label className="form-label">Notes</label><input className="form-control" value={txnForm.notes} onChange={e => setTxnForm({ ...txnForm, notes: e.target.value })} placeholder="Optional" /></div>
              </div>
              <button type="submit" className="btn btn-primary">Record</button>
            </form>
            <div>
              <div style={{ fontWeight: 600, marginBottom: 10 }}>Transaction History</div>
              {txns.length === 0 ? <div style={{ color: 'var(--text2)', fontSize: 13 }}>No transactions yet</div> : (
                <div style={{ maxHeight: 220, overflowY: 'auto' }}>
                  {txns.map(t => (
                    <div key={t.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: 13 }}>
                      <div>
                        <span className={`badge ${t.type === 'received' ? 'badge-success' : 'badge-warning'}`} style={{ marginRight: 8 }}>{t.type === 'received' ? '📥' : '📤'} {t.type}</span>
                        {t.notes && <span style={{ color: 'var(--text2)' }}>{t.notes}</span>}
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <strong>{t.quantity} {showTxn.unit}</strong>
                        <div style={{ fontSize: 11, color: 'var(--text2)' }}>{t.date} · {t.recorded_by_name}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
