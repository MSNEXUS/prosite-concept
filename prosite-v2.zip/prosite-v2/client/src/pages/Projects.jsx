import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';
import toast from 'react-hot-toast';

const STATUS_BADGE = { active: 'badge-success', completed: 'badge-info', on_hold: 'badge-warning' };

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [users, setUsers] = useState([]);
  const [filter, setFilter] = useState('all');
  const [form, setForm] = useState({ name: '', location: '', description: '', start_date: '', end_date: '', budget_total: '', manager_id: '' });
  const navigate = useNavigate();

  const load = () => {
    Promise.all([api.get('/projects'), api.get('/admin/users')]).then(([p, u]) => {
      setProjects(p.data); setUsers(u.data);
    }).catch(() => api.get('/projects').then(r => setProjects(r.data)))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const save = async (e) => {
    e.preventDefault();
    try {
      await api.post('/projects', { ...form, budget_total: Number(form.budget_total) });
      toast.success('Project created!');
      setShowModal(false);
      setForm({ name: '', location: '', description: '', start_date: '', end_date: '', budget_total: '', manager_id: '' });
      load();
    } catch { toast.error('Failed to create project'); }
  };

  const filtered = projects.filter(p => filter === 'all' || p.status === filter);

  if (loading) return <div className="spinner"><div className="spin" /></div>;

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <div className="page-title">Projects</div>
          <div className="page-subtitle">{projects.length} total projects</div>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ New Project</button>
      </div>

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
        {[['all', 'All'], ['active', 'Active'], ['on_hold', 'On Hold'], ['completed', 'Completed']].map(([val, label]) => (
          <button key={val} onClick={() => setFilter(val)} className="btn btn-sm" style={{ background: filter === val ? 'var(--brand)' : 'var(--surface)', color: filter === val ? '#fff' : 'var(--text2)', boxShadow: 'var(--shadow)' }}>
            {label}
          </button>
        ))}
      </div>

      <div className="grid grid-3">
        {filtered.map(p => (
          <div key={p.id} className="card" style={{ cursor: 'pointer', transition: 'transform 0.15s, box-shadow 0.15s' }}
            onClick={() => navigate(`/projects/${p.id}`)}
            onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.boxShadow = 'var(--shadow-md)'; }}
            onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = ''; }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 12 }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 4 }}>{p.name}</div>
                <div style={{ fontSize: 12, color: 'var(--text2)' }}>📍 {p.location}</div>
              </div>
              <span className={`badge ${STATUS_BADGE[p.status]}`} style={{ marginLeft: 8 }}>{p.status}</span>
            </div>

            <div style={{ marginBottom: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontSize: 13 }}>
                <span style={{ color: 'var(--text2)' }}>Progress</span>
                <span style={{ fontWeight: 600, color: 'var(--brand)' }}>{p.progress}%</span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${p.progress}%`, background: p.progress >= 100 ? 'var(--success)' : 'var(--brand)' }} />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
              <div style={{ background: 'var(--bg)', borderRadius: 8, padding: '10px 12px' }}>
                <div style={{ fontSize: 11, color: 'var(--text2)', marginBottom: 2 }}>Budget</div>
                <div style={{ fontWeight: 700, fontSize: 14 }}>₹{((p.budget_total || 0) / 100000).toFixed(1)}L</div>
              </div>
              <div style={{ background: 'var(--bg)', borderRadius: 8, padding: '10px 12px' }}>
                <div style={{ fontSize: 11, color: 'var(--text2)', marginBottom: 2 }}>Spent</div>
                <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--brand)' }}>₹{((p.spent || 0) / 100000).toFixed(1)}L</div>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--text2)' }}>
              <span>✅ {p.completed_tasks || 0} done · 🔄 {p.open_tasks || 0} open</span>
              <span>{p.manager_name}</span>
            </div>

            {p.end_date && (
              <div style={{ marginTop: 12, fontSize: 12, color: 'var(--text3)', borderTop: '1px solid var(--border)', paddingTop: 10 }}>
                📅 Deadline: {new Date(p.end_date).toLocaleDateString('en-IN')}
              </div>
            )}
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="empty-state"><div className="icon">🏗️</div><h3>No projects found</h3><p>Create your first project to get started</p></div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">New Project</span>
              <button className="btn btn-sm btn-secondary" onClick={() => setShowModal(false)}>✕</button>
            </div>
            <form onSubmit={save}>
              <div className="form-group"><label className="form-label">Project Name *</label><input className="form-control" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required /></div>
              <div className="form-group"><label className="form-label">Location</label><input className="form-control" value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} /></div>
              <div className="form-group"><label className="form-label">Description</label><textarea className="form-control" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
              <div className="grid grid-2">
                <div className="form-group"><label className="form-label">Start Date</label><input type="date" className="form-control" value={form.start_date} onChange={e => setForm({ ...form, start_date: e.target.value })} /></div>
                <div className="form-group"><label className="form-label">End Date</label><input type="date" className="form-control" value={form.end_date} onChange={e => setForm({ ...form, end_date: e.target.value })} /></div>
              </div>
              <div className="form-group"><label className="form-label">Total Budget (₹)</label><input type="number" className="form-control" value={form.budget_total} onChange={e => setForm({ ...form, budget_total: e.target.value })} placeholder="e.g. 4500000" /></div>
              {users.length > 0 && (
                <div className="form-group">
                  <label className="form-label">Site Manager</label>
                  <select className="form-control" value={form.manager_id} onChange={e => setForm({ ...form, manager_id: e.target.value })}>
                    <option value="">Select manager</option>
                    {users.map(u => <option key={u.id} value={u.id}>{u.name} ({u.role})</option>)}
                  </select>
                </div>
              )}
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Create Project</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
