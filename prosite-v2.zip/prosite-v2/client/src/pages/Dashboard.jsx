import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { useAuth } from '../context/AuthContext';
import api from '../api';

function StatCard({ icon, label, value, sub, danger, warning }) {
  return (
    <div className="stat-card">
      <div className="stat-icon">{icon}</div>
      <div>
        <div className="stat-value" style={{ color: danger ? 'var(--danger)' : warning ? 'var(--warning)' : undefined }}>{value}</div>
        <div className="stat-label">{label}</div>
        {sub && <div className="stat-sub">{sub}</div>}
      </div>
    </div>
  );
}

// ── OWNER dashboard ────────────────────────────────────────────────────────
function OwnerDashboard() {
  const [data, setData] = useState(null);
  const [projects, setProjects] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([api.get('/projects/meta/dashboard'), api.get('/projects')]).then(([d, p]) => { setData(d.data); setProjects(p.data); });
  }, []);

  if (!data) return <div className="spinner"><div className="spin" /></div>;
  const { stats, burnForecasts, recent_logs, urgent_tasks, open_issues } = data;

  return (
    <div className="page">
      <div className="page-header">
        <div><div className="page-title">Command Center 📊</div><div className="page-subtitle">Live overview across all your sites</div></div>
        <button className="btn btn-primary" onClick={() => navigate('/projects')}>+ New Project</button>
      </div>

      {/* Critical alerts */}
      {(stats.critical_issues > 0 || stats.low_stock_alerts > 0) && (
        <div style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap' }}>
          {stats.critical_issues > 0 && (
            <div style={{ flex: 1, minWidth: 280, background: '#FEE2E2', border: '1px solid #FCA5A5', borderRadius: 10, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 22 }}>🚨</span>
              <div><div style={{ fontWeight: 700, color: 'var(--danger)', fontSize: 14 }}>{stats.critical_issues} Critical Issue{stats.critical_issues > 1 ? 's' : ''} Open</div>
              <div style={{ fontSize: 12, color: '#B91C1C' }}>Immediate attention required</div></div>
            </div>
          )}
          {stats.low_stock_alerts > 0 && (
            <div style={{ flex: 1, minWidth: 280, background: '#FEF9C3', border: '1px solid #FDE047', borderRadius: 10, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 22 }}>⚠️</span>
              <div><div style={{ fontWeight: 700, color: '#854D0E', fontSize: 14 }}>{stats.low_stock_alerts} Low Stock Alert{stats.low_stock_alerts > 1 ? 's' : ''}</div>
              <div style={{ fontSize: 12, color: '#854D0E' }}>Materials below minimum level</div></div>
            </div>
          )}
          {stats.pending_milestones > 0 && (
            <div style={{ flex: 1, minWidth: 280, background: 'var(--brand-light)', border: '1px solid var(--brand)', borderRadius: 10, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 22 }}>🏁</span>
              <div><div style={{ fontWeight: 700, color: 'var(--brand-dark)', fontSize: 14 }}>{stats.pending_milestones} Milestone{stats.pending_milestones > 1 ? 's' : ''} Awaiting Client Approval</div>
              <div style={{ fontSize: 12, color: 'var(--brand-dark)' }}>Payment pending</div></div>
            </div>
          )}
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-4" style={{ marginBottom: 24 }}>
        <StatCard icon="🏗️" label="Active Projects" value={stats.active_projects} sub={`${stats.total_projects} total`} />
        <StatCard icon="✅" label="Open Tasks" value={stats.open_tasks} warning={stats.overdue_tasks > 0} sub={stats.overdue_tasks > 0 ? `${stats.overdue_tasks} overdue ⚠️` : 'On track'} />
        <StatCard icon="👷" label="Workers Today" value={stats.total_workers_today} sub="Present across sites" />
        <StatCard icon="🚨" label="Open Issues" value={stats.open_issues} danger={stats.critical_issues > 0} sub={stats.critical_issues > 0 ? `${stats.critical_issues} critical` : 'No critical issues'} />
      </div>

      {/* Project cards + burn forecast */}
      <div className="grid grid-2" style={{ marginBottom: 24 }}>
        <div className="card">
          <div className="card-header"><span className="card-title">🏗️ Active Projects</span></div>
          {projects.filter(p => p.status === 'active').map(p => (
            <div key={p.id} style={{ padding: '12px 0', borderBottom: '1px solid var(--border)', cursor: 'pointer' }} onClick={() => navigate(`/projects/${p.id}`)}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{p.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text2)' }}>📍 {p.location} · {p.manager_name}</div>
                </div>
                <span style={{ fontWeight: 800, color: 'var(--brand)', fontSize: 18 }}>{p.progress}%</span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${p.progress}%`, background: p.progress >= 80 ? 'var(--success)' : 'var(--brand)' }} />
              </div>
              <div style={{ display: 'flex', gap: 12, marginTop: 8, fontSize: 12, color: 'var(--text2)' }}>
                <span>💰 ₹{((p.budget_total||0)/100000).toFixed(1)}L budget</span>
                <span>💸 ₹{((p.spent||0)/100000).toFixed(1)}L spent</span>
                <span>✅ {p.open_tasks} open tasks</span>
              </div>
            </div>
          ))}
        </div>

        <div className="card">
          <div className="card-header"><span className="card-title">📈 Budget Burn Forecast</span><span style={{ fontSize: 12, color: 'var(--text2)' }}>At current rate</span></div>
          {burnForecasts.map(f => (
            <div key={f.id} style={{ padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <div style={{ fontWeight: 600, fontSize: 13 }}>{f.name.length > 28 ? f.name.slice(0,28)+'…' : f.name}</div>
                <span className={`badge ${f.overrun > 0 ? 'badge-danger' : 'badge-success'}`}>
                  {f.overrun > 0 ? `⚠️ +₹${(f.overrun/100000).toFixed(1)}L overrun` : '✅ Within budget'}
                </span>
              </div>
              <div style={{ fontSize: 12, color: 'var(--text2)', display: 'flex', gap: 16 }}>
                <span>🔥 ₹{(f.burnRate).toLocaleString('en-IN')}/day burn rate</span>
                <span>📅 {f.remaining_days} days left</span>
              </div>
              <div style={{ marginTop: 8 }}>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: `${Math.min((f.spent/f.budget_total)*100,100)}%`, background: f.overrun > 0 ? 'var(--danger)' : 'var(--brand)' }} />
                </div>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 4 }}>₹{(f.spent/100000).toFixed(1)}L of ₹{(f.budget_total/100000).toFixed(1)}L used · Forecast: ₹{(f.forecastTotal/100000).toFixed(1)}L</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Issues + Tasks */}
      <div className="grid grid-2" style={{ marginBottom: 24 }}>
        <div className="card">
          <div className="card-header"><span className="card-title">🚨 Open Issues</span></div>
          {open_issues.length === 0 ? <div className="empty-state" style={{ padding: 32 }}><div>No open issues 🎉</div></div> : open_issues.map(issue => (
            <div key={issue.id} style={{ padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{issue.title}</div>
                  <div style={{ fontSize: 12, color: 'var(--text2)', marginTop: 2 }}>{issue.project_name} · {issue.raised_by_name}</div>
                </div>
                <span className={`badge ${issue.severity === 'critical' ? 'badge-danger' : 'badge-warning'}`}>{issue.severity}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="card">
          <div className="card-header"><span className="card-title">🔥 Urgent Tasks</span><button className="btn btn-sm btn-secondary" onClick={() => navigate('/tasks')}>View All</button></div>
          {urgent_tasks.length === 0 ? <div className="empty-state" style={{ padding: 32 }}><div>No urgent tasks 🎉</div></div> : urgent_tasks.map(t => (
            <div key={t.id} style={{ padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                <div><div style={{ fontWeight: 600, fontSize: 13 }}>{t.title}</div><div style={{ fontSize: 12, color: 'var(--text2)' }}>{t.project_name} · {t.assigned_name || 'Unassigned'}</div></div>
                <div style={{ textAlign: 'right', flexShrink: 0 }}>
                  <span className={`badge ${t.priority === 'urgent' ? 'badge-danger' : 'badge-warning'}`}>{t.priority}</span>
                  {t.due_date && <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 3 }}>{t.due_date}</div>}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent logs */}
      <div className="card">
        <div className="card-header"><span className="card-title">📋 Recent Site Logs</span><button className="btn btn-sm btn-secondary" onClick={() => navigate('/logs')}>View All</button></div>
        <div className="grid grid-3">
          {recent_logs.map(log => (
            <div key={log.id} style={{ background: 'var(--bg)', borderRadius: 10, padding: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontWeight: 600, fontSize: 13 }}>{log.project_name}</span>
                <span style={{ fontSize: 12, color: 'var(--text2)' }}>{log.date}</span>
              </div>
              <div style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 1.5 }}>{log.work_done?.slice(0,80)}{log.work_done?.length > 80 ? '…' : ''}</div>
              <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 6 }}>by {log.logged_by} · 👷 {log.manpower}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── ENGINEER / SUPERVISOR dashboard ────────────────────────────────────────
function EngineerDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [myTasks, setMyTasks] = useState([]);
  const [issues, setIssues] = useState([]);
  const [showIssueModal, setShowIssueModal] = useState(false);
  const [issueForm, setIssueForm] = useState({ project_id: '', title: '', description: '', severity: 'high' });

  useEffect(() => {
    api.get('/projects').then(r => setProjects(r.data));
    api.get('/tasks/all').then(r => setMyTasks(r.data.filter(t => t.assigned_to === user.id).slice(0,5)));
    api.get('/issues/open').then(r => setIssues(r.data.filter(i => i.raised_by === user.id)));
  }, [user.id]);

  const raiseIssue = async (e) => {
    e.preventDefault();
    await api.post('/issues', issueForm);
    setShowIssueModal(false);
    setIssueForm({ project_id: '', title: '', description: '', severity: 'high' });
    api.get('/issues/open').then(r => setIssues(r.data.filter(i => i.raised_by === user.id)));
    import('react-hot-toast').then(m => m.default.success('Issue raised — owner notified 🚨'));
  };

  const priorityColor = { urgent: 'var(--danger)', high: 'var(--warning)', medium: 'var(--info)', low: 'var(--success)' };

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <div className="page-title">Good {new Date().getHours() < 12 ? 'Morning' : 'Afternoon'}, {user.name.split(' ')[0]} 👋</div>
          <div className="page-subtitle">{new Date().toLocaleDateString('en-IN', { weekday:'long', day:'numeric', month:'long' })}</div>
        </div>
        <button className="btn btn-danger" onClick={() => setShowIssueModal(true)} style={{ background: 'var(--danger)', color: '#fff' }}>🚨 Raise Issue</button>
      </div>

      <div className="grid grid-3" style={{ marginBottom: 24 }}>
        <div className="stat-card">
          <div className="stat-icon">🏗️</div>
          <div><div className="stat-value">{projects.filter(p => p.status === 'active').length}</div><div className="stat-label">Active Projects</div></div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">✅</div>
          <div><div className="stat-value">{myTasks.length}</div><div className="stat-label">My Open Tasks</div></div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">🚨</div>
          <div><div className="stat-value" style={{ color: issues.length > 0 ? 'var(--danger)' : undefined }}>{issues.length}</div><div className="stat-label">My Open Issues</div></div>
        </div>
      </div>

      <div className="grid grid-2">
        <div className="card">
          <div className="card-header"><span className="card-title">📋 My Tasks</span><button className="btn btn-sm btn-secondary" onClick={() => navigate('/tasks')}>View All</button></div>
          {myTasks.length === 0 ? <div className="empty-state" style={{ padding: 32 }}><div>No tasks assigned 🎉</div></div> : myTasks.map(t => (
            <div key={t.id} style={{ padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                <div><div style={{ fontWeight: 600, fontSize: 13 }}>{t.title}</div><div style={{ fontSize: 12, color: 'var(--text2)' }}>{t.project_name}</div></div>
                <span style={{ fontSize: 11, color: priorityColor[t.priority], fontWeight: 700, textTransform: 'uppercase' }}>{t.priority}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="card">
          <div className="card-header"><span className="card-title">🏗️ Projects</span></div>
          {projects.filter(p => p.status === 'active').map(p => (
            <div key={p.id} style={{ padding: '10px 0', borderBottom: '1px solid var(--border)', cursor: 'pointer' }} onClick={() => navigate(`/projects/${p.id}`)}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                <div style={{ fontWeight: 600, fontSize: 13 }}>{p.name}</div>
                <span style={{ fontWeight: 700, color: 'var(--brand)' }}>{p.progress}%</span>
              </div>
              <div className="progress-bar"><div className="progress-fill" style={{ width: `${p.progress}%` }} /></div>
            </div>
          ))}
        </div>
      </div>

      {showIssueModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowIssueModal(false)}>
          <div className="modal" style={{ maxWidth: 460 }}>
            <div className="modal-header">
              <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                <div style={{ width: 40, height: 40, background: '#FEE2E2', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>🚨</div>
                <span className="modal-title">Raise an Issue</span>
              </div>
              <button className="btn btn-ghost btn-icon btn-sm" onClick={() => setShowIssueModal(false)}>✕</button>
            </div>
            <div style={{ padding: '8px 12px', background: '#FEE2E2', borderRadius: 8, marginBottom: 20, fontSize: 13, color: '#B91C1C' }}>⚡ Owner will be notified immediately</div>
            <form onSubmit={raiseIssue}>
              <div className="form-group"><label className="form-label">Project</label>
                <select className="form-control" value={issueForm.project_id} onChange={e => setIssueForm({...issueForm, project_id: e.target.value})} required>
                  <option value="">Select project</option>
                  {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div className="form-group"><label className="form-label">Issue Title *</label><input className="form-control" value={issueForm.title} onChange={e => setIssueForm({...issueForm, title: e.target.value})} placeholder="e.g. Rig breakdown, Safety hazard" required /></div>
              <div className="form-group"><label className="form-label">Description</label><textarea className="form-control" rows={3} value={issueForm.description} onChange={e => setIssueForm({...issueForm, description: e.target.value})} placeholder="Describe the issue in detail..." /></div>
              <div className="form-group"><label className="form-label">Severity</label>
                <select className="form-control" value={issueForm.severity} onChange={e => setIssueForm({...issueForm, severity: e.target.value})}>
                  <option value="high">🟠 High</option><option value="critical">🔴 Critical</option>
                </select>
              </div>
              <div className="modal-footer"><button type="button" className="btn btn-secondary" onClick={() => setShowIssueModal(false)}>Cancel</button><button type="submit" className="btn btn-danger">🚨 Send Alert to Owner</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  if (user?.role === 'owner') return <OwnerDashboard />;
  return <EngineerDashboard />;
}
