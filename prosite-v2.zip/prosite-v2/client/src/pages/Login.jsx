import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const DEMO_ROLES = [
  { role: 'owner',      label: '👑 Owner',      email: 'admin@prosite.in',      desc: 'Full access — command center, all sites' },
  { role: 'engineer',   label: '🔧 Engineer',   email: 'engineer@prosite.in',   desc: 'Site logs, tasks, materials, escalations' },
  { role: 'supervisor', label: '👷 Supervisor', email: 'supervisor@prosite.in', desc: 'Attendance with roster + wage calculator' },
  { role: 'client',     label: '🤝 Client',     email: 'client@prosite.in',     desc: 'Read-only project view, milestone approval' },
];

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(email, password);
      toast.success(`Welcome, ${user.name.split(' ')[0]}!`);
      navigate(user.role === 'client' ? '/client' : '/');
    } catch { toast.error('Invalid email or password'); } finally { setLoading(false); }
  };

  const demoLogin = (d) => { setEmail(d.email); setPassword('demo1234'); toast(`${d.label} credentials filled — click Sign In`, { icon: '👆' }); };

  return (
    <div style={{ minHeight:'100vh', display:'flex', background:'var(--bg)' }}>
      {/* Left panel */}
      <div style={{ flex:1, background:'var(--sidebar-bg)', display:'flex', flexDirection:'column', justifyContent:'center', padding:'60px 64px', color:'#fff', minWidth:0 }}>
        <div style={{ maxWidth:440 }}>
          <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:52 }}>
            <div style={{ width:44, height:44, background:'#FF6B2B', borderRadius:12, display:'flex', alignItems:'center', justifyContent:'center', fontSize:22 }}>🏗️</div>
            <div>
              <div style={{ fontFamily:'Syne', fontWeight:800, fontSize:22 }}>ProSite</div>
              <div style={{ fontSize:11, color:'rgba(255,255,255,0.4)', letterSpacing:'1px', textTransform:'uppercase' }}>v2.0</div>
            </div>
          </div>

          <h1 style={{ fontSize:40, fontFamily:'Syne', fontWeight:800, lineHeight:1.15, marginBottom:16 }}>
            Construction<br />Management<br /><span style={{ color:'#FF6B2B' }}>Reimagined.</span>
          </h1>
          <p style={{ color:'rgba(255,255,255,0.5)', fontSize:15, lineHeight:1.8, marginBottom:40 }}>
            Built for Indian construction — track sites, workers, materials, and budget. Built to impress investors.
          </p>

          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            {[['📊','Command Center'],['👷','Attendance + Wages'],['📦','Material Alerts'],['💰','Budget Forecasting'],['🚨','Issue Escalation'],['🤝','Client Portal']].map(([icon,label]) => (
              <div key={label} style={{ display:'flex', alignItems:'center', gap:8, color:'rgba(255,255,255,0.6)', fontSize:13 }}>
                <span style={{ fontSize:16 }}>{icon}</span>{label}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel */}
      <div style={{ width:500, display:'flex', alignItems:'center', justifyContent:'center', padding:'40px 48px', background:'var(--surface)' }}>
        <div style={{ width:'100%', maxWidth:380 }}>
          <h2 style={{ fontSize:26, fontWeight:700, marginBottom:4 }}>Sign in</h2>
          <p style={{ color:'var(--text2)', marginBottom:28, fontSize:14 }}>Enter your credentials to continue</p>

          <form onSubmit={handleSubmit}>
            <div className="form-group"><label className="form-label">Email Address</label><input className="form-control" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@prosite.in" required /></div>
            <div className="form-group"><label className="form-label">Password</label><input className="form-control" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required /></div>
            <button type="submit" className="btn btn-primary btn-lg" style={{ width:'100%', justifyContent:'center', marginTop:8 }} disabled={loading}>
              {loading ? 'Signing in…' : 'Sign In →'}
            </button>
          </form>

          <div style={{ marginTop:28, padding:18, background:'var(--bg)', borderRadius:12, border:'1px solid var(--border)' }}>
            <div style={{ fontSize:11, fontWeight:700, color:'var(--text2)', textTransform:'uppercase', letterSpacing:'0.6px', marginBottom:12 }}>🎯 Demo Access — Click to fill credentials</div>
            <div style={{ display:'flex', flexDirection:'column', gap:7 }}>
              {DEMO_ROLES.map(d => (
                <button key={d.role} onClick={() => demoLogin(d)} className="btn btn-secondary" style={{ justifyContent:'flex-start', textAlign:'left', fontSize:13, padding:'10px 14px' }}>
                  <div>
                    <div style={{ fontWeight:600 }}>{d.label}</div>
                    <div style={{ fontSize:11, color:'var(--text2)', marginTop:1 }}>{d.desc}</div>
                  </div>
                </button>
              ))}
            </div>
            <div style={{ fontSize:11, color:'var(--text3)', marginTop:10 }}>Password for all: <strong>demo1234</strong></div>
          </div>
        </div>
      </div>
    </div>
  );
}
