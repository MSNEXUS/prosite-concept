import { useState, useEffect } from 'react';
import api from '../api';
import toast from 'react-hot-toast';

const ROLES = ['Mason','Carpenter','Electrician','Plumber','Steel Binder','Helper','Supervisor','Driver','Welder','Painter'];
const STATUS_STYLE = {
  present:  { bg: '#DCFCE7', color: '#15803D', label: 'Present' },
  absent:   { bg: '#FEE2E2', color: '#B91C1C', label: 'Absent' },
  half_day: { bg: '#FEF9C3', color: '#854D0E', label: 'Half Day' },
};

export default function Attendance() {
  const [projects, setProjects] = useState([]);
  const [selProject, setSelProject] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [records, setRecords] = useState([]);
  const [roster, setRoster] = useState([]);
  const [summary, setSummary] = useState({ present:0, absent:0, half_day:0, total:0 });
  const [wageData, setWageData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [tab, setTab] = useState('attendance'); // attendance | roster
  const [newWorker, setNewWorker] = useState({ worker_name:'', role:'Mason', daily_wage:'' });
  const [rosterForm, setRosterForm] = useState({ worker_name:'', role:'Mason', daily_wage:'', phone:'' });
  const [showRosterAdd, setShowRosterAdd] = useState(false);

  useEffect(() => { api.get('/projects').then(r => { setProjects(r.data); if (r.data.length) setSelProject(r.data[0].id); }); }, []);

  useEffect(() => {
    if (!selProject) return;
    setLoading(true);
    Promise.all([
      api.get(`/attendance/project/${selProject}?date=${date}`),
      api.get(`/attendance/project/${selProject}/summary?date=${date}`),
      api.get(`/roster/project/${selProject}`),
    ]).then(([rec, sum, ros]) => {
      setRecords(rec.data);
      setSummary(sum.data);
      setRoster(ros.data);
    }).finally(() => setLoading(false));
  }, [selProject, date]);

  const loadRoster = () => {
    if (!roster.length) { toast.error('No workers in roster. Add workers first.'); return; }
    const rosterRecords = roster.map(w => ({ worker_name: w.worker_name, role: w.role, daily_wage: w.daily_wage, status: 'present', check_in: '08:00', check_out: '17:30', overtime_hours: 0, notes: '' }));
    setRecords(rosterRecords);
    toast.success(`Loaded ${rosterRecords.length} workers from roster`);
  };

  const calcWages = async () => {
    try {
      const r = await api.get(`/roster/project/${selProject}/wages/${date}`);
      setWageData(r.data);
    } catch { toast.error('Save attendance first, then calculate wages'); }
  };

  const updateRecord = (idx, field, val) => setRecords(prev => prev.map((r, i) => i === idx ? { ...r, [field]: val } : r));

  const addWorkerManual = () => {
    if (!newWorker.worker_name.trim()) return;
    setRecords(prev => [...prev, { ...newWorker, status: 'present', check_in: '08:00', check_out: '17:30', overtime_hours: 0, notes: '' }]);
    setNewWorker({ worker_name: '', role: 'Mason', daily_wage: '' });
  };

  const saveAll = async () => {
    setSaving(true);
    try {
      await api.post('/attendance/bulk', { project_id: selProject, date, records });
      toast.success('Attendance saved!');
      const [sum] = await Promise.all([api.get(`/attendance/project/${selProject}/summary?date=${date}`)]);
      setSummary(sum.data);
    } catch { toast.error('Failed to save'); } finally { setSaving(false); }
  };

  const addToRoster = async (e) => {
    e.preventDefault();
    try {
      await api.post('/roster', { ...rosterForm, project_id: selProject, daily_wage: Number(rosterForm.daily_wage) });
      toast.success('Worker added to roster');
      setShowRosterAdd(false);
      setRosterForm({ worker_name:'', role:'Mason', daily_wage:'', phone:'' });
      api.get(`/roster/project/${selProject}`).then(r => setRoster(r.data));
    } catch (err) { toast.error(err.response?.data?.error || 'Failed'); }
  };

  const removeFromRoster = async (id) => {
    await api.delete(`/roster/${id}`);
    setRoster(roster.filter(w => w.id !== id));
    toast.success('Removed from roster');
  };

  const totalWage = records.reduce((sum, r) => {
    const wage = Number(r.daily_wage) || 0;
    const earned = r.status === 'present' ? wage + (Number(r.overtime_hours||0) * wage / 8)
                 : r.status === 'half_day' ? wage / 2 : 0;
    return sum + earned;
  }, 0);

  return (
    <div className="page">
      <div className="page-header">
        <div><div className="page-title">Worker Attendance</div><div className="page-subtitle">Daily tracking with wage calculator</div></div>
        <div style={{ display:'flex', gap:8 }}>
          {tab === 'attendance' && <button className="btn btn-secondary" onClick={loadRoster}>📋 Load Roster</button>}
          <button className="btn btn-primary" onClick={saveAll} disabled={saving}>{saving ? 'Saving…' : '💾 Save'}</button>
        </div>
      </div>

      {/* Tab switcher */}
      <div style={{ display:'flex', gap:4, marginBottom:20, background:'var(--surface)', borderRadius:10, padding:4, width:'fit-content', boxShadow:'var(--shadow)' }}>
        {[['attendance','👷 Attendance'],['roster','📋 Worker Roster']].map(([key,label]) => (
          <button key={key} onClick={() => setTab(key)} className="btn btn-sm" style={{ borderRadius:8, background: tab===key ? 'var(--brand)' : 'transparent', color: tab===key ? '#fff' : 'var(--text2)', fontWeight: tab===key ? 600 : 400 }}>{label}</button>
        ))}
      </div>

      {/* Controls */}
      <div style={{ display:'flex', gap:16, marginBottom:20, flexWrap:'wrap', alignItems:'center' }}>
        <select className="form-control" style={{ width:280 }} value={selProject} onChange={e => setSelProject(e.target.value)}>
          {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        {tab === 'attendance' && <input type="date" className="form-control" style={{ width:160 }} value={date} onChange={e => setDate(e.target.value)} />}
      </div>

      {tab === 'attendance' && (
        <>
          {/* Summary cards */}
          <div className="grid grid-4" style={{ marginBottom:20 }}>
            {[['👥','Total',summary.total,'#E0E7FF'],['✅','Present',summary.present,'#DCFCE7'],['❌','Absent',summary.absent,'#FEE2E2'],['🕐','Half Day',summary.half_day,'#FEF9C3']].map(([icon,label,val,bg]) => (
              <div key={label} style={{ background:bg, borderRadius:12, padding:'16px 18px', display:'flex', alignItems:'center', gap:12 }}>
                <span style={{ fontSize:24 }}>{icon}</span>
                <div><div style={{ fontSize:24, fontWeight:800, lineHeight:1 }}>{val}</div><div style={{ fontSize:12, color:'var(--text2)' }}>{label}</div></div>
              </div>
            ))}
          </div>

          {/* Wage summary banner */}
          {records.length > 0 && (
            <div style={{ background:'linear-gradient(135deg, var(--brand), var(--brand-dark))', borderRadius:12, padding:'16px 20px', marginBottom:20, display:'flex', justifyContent:'space-between', alignItems:'center', color:'#fff' }}>
              <div>
                <div style={{ fontSize:12, opacity:0.8, textTransform:'uppercase', letterSpacing:'0.5px' }}>Estimated Labour Cost — {date}</div>
                <div style={{ fontSize:28, fontWeight:800, fontFamily:'Syne', marginTop:2 }}>₹{totalWage.toLocaleString('en-IN')}</div>
              </div>
              <button className="btn" style={{ background:'rgba(255,255,255,0.2)', color:'#fff', border:'1px solid rgba(255,255,255,0.3)' }} onClick={calcWages}>📊 Detailed Breakdown</button>
            </div>
          )}

          {/* Add worker manually */}
          <div className="card" style={{ marginBottom:16 }}>
            <div style={{ fontWeight:600, marginBottom:10, fontSize:14 }}>➕ Add Worker Manually</div>
            <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
              <input className="form-control" style={{ flex:1, minWidth:180 }} placeholder="Worker name" value={newWorker.worker_name} onChange={e => setNewWorker({...newWorker, worker_name:e.target.value})} onKeyDown={e => e.key==='Enter' && addWorkerManual()} />
              <select className="form-control" style={{ width:140 }} value={newWorker.role} onChange={e => setNewWorker({...newWorker, role:e.target.value})}>
                {ROLES.map(r => <option key={r}>{r}</option>)}
              </select>
              <input type="number" className="form-control" style={{ width:120 }} placeholder="Daily wage ₹" value={newWorker.daily_wage} onChange={e => setNewWorker({...newWorker, daily_wage:e.target.value})} />
              <button className="btn btn-primary" onClick={addWorkerManual}>Add</button>
            </div>
          </div>

          {/* Attendance table */}
          {loading ? <div className="spinner"><div className="spin"/></div> : (
            <div className="card" style={{ padding:0, overflow:'hidden' }}>
              {records.length === 0 ? (
                <div className="empty-state" style={{ padding:48 }}>
                  <div className="icon">👷</div><h3>No workers yet</h3>
                  <p>Load from roster or add workers manually above</p>
                  <button className="btn btn-primary" style={{ marginTop:16 }} onClick={loadRoster}>📋 Load from Roster</button>
                </div>
              ) : (
                <div className="table-wrap">
                  <table>
                    <thead><tr><th>Worker</th><th>Role</th><th>Status</th><th>Check In</th><th>Check Out</th><th>OT Hrs</th><th>Day Wage</th><th>Earned</th><th></th></tr></thead>
                    <tbody>
                      {records.map((r, idx) => {
                        const wage = Number(r.daily_wage)||0;
                        const earned = r.status==='present' ? wage+(Number(r.overtime_hours||0)*wage/8) : r.status==='half_day' ? wage/2 : 0;
                        return (
                          <tr key={idx}>
                            <td style={{ fontWeight:600 }}>{r.worker_name}</td>
                            <td><span className="badge badge-gray">{r.role}</span></td>
                            <td>
                              <div style={{ display:'flex', gap:4 }}>
                                {Object.entries(STATUS_STYLE).map(([s,style]) => (
                                  <button key={s} onClick={() => updateRecord(idx,'status',s)} className="btn btn-sm"
                                    style={{ background: r.status===s ? style.bg : 'var(--surface2)', color: r.status===s ? style.color : 'var(--text3)', border: r.status===s ? `1.5px solid ${style.color}` : '1.5px solid transparent', fontSize:11, padding:'3px 8px', fontWeight: r.status===s ? 700 : 400 }}>
                                    {style.label}
                                  </button>
                                ))}
                              </div>
                            </td>
                            <td><input type="time" style={{ border:'1.5px solid var(--border)', borderRadius:6, padding:'4px 8px', fontSize:12 }} value={r.check_in||''} onChange={e => updateRecord(idx,'check_in',e.target.value)} disabled={r.status==='absent'} /></td>
                            <td><input type="time" style={{ border:'1.5px solid var(--border)', borderRadius:6, padding:'4px 8px', fontSize:12 }} value={r.check_out||''} onChange={e => updateRecord(idx,'check_out',e.target.value)} disabled={r.status==='absent'} /></td>
                            <td><input type="number" min="0" max="12" step="0.5" style={{ border:'1.5px solid var(--border)', borderRadius:6, padding:'4px 8px', fontSize:12, width:60 }} value={r.overtime_hours||0} onChange={e => updateRecord(idx,'overtime_hours',e.target.value)} /></td>
                            <td style={{ fontSize:13 }}>{wage > 0 ? `₹${wage}` : '—'}</td>
                            <td style={{ fontWeight:700, color: earned>0 ? 'var(--success)' : 'var(--text2)' }}>{earned > 0 ? `₹${Math.round(earned)}` : '—'}</td>
                            <td><button className="btn btn-danger btn-icon btn-sm" onClick={() => setRecords(prev => prev.filter((_,i) => i!==idx))}>🗑️</button></td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Wage breakdown modal */}
          {wageData && (
            <div className="modal-overlay" onClick={() => setWageData(null)}>
              <div className="modal" style={{ maxWidth:560 }}>
                <div className="modal-header"><span className="modal-title">💰 Wage Breakdown — {wageData.date}</span><button className="btn btn-ghost btn-icon btn-sm" onClick={() => setWageData(null)}>✕</button></div>
                <div className="table-wrap" style={{ maxHeight:360, overflowY:'auto' }}>
                  <table>
                    <thead><tr><th>Worker</th><th>Status</th><th>OT</th><th>Earned</th></tr></thead>
                    <tbody>
                      {wageData.breakdown.map((w,i) => (
                        <tr key={i}><td style={{ fontWeight:600 }}>{w.worker_name}</td><td>{w.status}</td><td>{w.overtime_hours||0}h</td><td style={{ fontWeight:700, color:'var(--success)' }}>₹{Math.round(w.earned).toLocaleString('en-IN')}</td></tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div style={{ padding:'16px 0 0', borderTop:'1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:12 }}>
                  <span style={{ fontWeight:600 }}>Total Labour Cost</span>
                  <span style={{ fontSize:22, fontWeight:800, fontFamily:'Syne', color:'var(--brand)' }}>₹{Math.round(wageData.total).toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {tab === 'roster' && (
        <div className="card" style={{ padding:0, overflow:'hidden' }}>
          <div style={{ padding:'16px 20px', borderBottom:'1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <span style={{ fontWeight:600 }}>Saved Worker Roster ({roster.length} workers)</span>
            <button className="btn btn-primary btn-sm" onClick={() => setShowRosterAdd(true)}>+ Add Worker</button>
          </div>
          {roster.length === 0 ? (
            <div className="empty-state" style={{ padding:48 }}><div className="icon">👷</div><h3>No workers in roster</h3><p>Add workers to load them into attendance quickly</p><button className="btn btn-primary" style={{ marginTop:16 }} onClick={() => setShowRosterAdd(true)}>+ Add First Worker</button></div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Worker</th><th>Role</th><th>Daily Wage</th><th>Phone</th><th>Action</th></tr></thead>
                <tbody>
                  {roster.map(w => (
                    <tr key={w.id}>
                      <td style={{ fontWeight:600 }}>{w.worker_name}</td>
                      <td><span className="badge badge-gray">{w.role}</span></td>
                      <td style={{ fontWeight:700, color:'var(--brand)' }}>₹{w.daily_wage}/day</td>
                      <td style={{ color:'var(--text2)', fontSize:13 }}>{w.phone || '—'}</td>
                      <td><button className="btn btn-danger btn-sm" onClick={() => removeFromRoster(w.id)}>Remove</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {showRosterAdd && (
        <div className="modal-overlay" onClick={e => e.target===e.currentTarget && setShowRosterAdd(false)}>
          <div className="modal" style={{ maxWidth:420 }}>
            <div className="modal-header"><span className="modal-title">Add to Roster</span><button className="btn btn-ghost btn-icon btn-sm" onClick={() => setShowRosterAdd(false)}>✕</button></div>
            <form onSubmit={addToRoster}>
              <div className="form-group"><label className="form-label">Worker Name *</label><input className="form-control" value={rosterForm.worker_name} onChange={e => setRosterForm({...rosterForm, worker_name:e.target.value})} required /></div>
              <div className="grid grid-2">
                <div className="form-group"><label className="form-label">Role</label><select className="form-control" value={rosterForm.role} onChange={e => setRosterForm({...rosterForm, role:e.target.value})}>{ROLES.map(r => <option key={r}>{r}</option>)}</select></div>
                <div className="form-group"><label className="form-label">Daily Wage (₹)</label><input type="number" className="form-control" value={rosterForm.daily_wage} onChange={e => setRosterForm({...rosterForm, daily_wage:e.target.value})} placeholder="e.g. 800" /></div>
              </div>
              <div className="form-group"><label className="form-label">Phone</label><input className="form-control" value={rosterForm.phone} onChange={e => setRosterForm({...rosterForm, phone:e.target.value})} placeholder="9876543210" /></div>
              <div className="modal-footer"><button type="button" className="btn btn-secondary" onClick={() => setShowRosterAdd(false)}>Cancel</button><button type="submit" className="btn btn-primary">Add to Roster</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
