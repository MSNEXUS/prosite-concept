import { useState, useEffect } from 'react';
import api from '../api';
import toast from 'react-hot-toast';

const PRIORITY_STYLE = {
  urgent: { bg: '#FEE2E2', color: '#B91C1C', dot: '#EF4444' },
  high:   { bg: '#FEF9C3', color: '#854D0E', dot: '#F59E0B' },
  medium: { bg: '#DBEAFE', color: '#1D4ED8', dot: '#3B82F6' },
  low:    { bg: '#DCFCE7', color: '#15803D', dot: '#22C55E' },
};
const STATUS_COLS = [
  { key: 'pending',     label: '📋 Pending',     color: 'var(--text2)' },
  { key: 'in_progress', label: '🔄 In Progress',  color: 'var(--brand)' },
  { key: 'blocked',     label: '🚫 Blocked',      color: 'var(--danger)' },
  { key: 'completed',   label: '✅ Completed',    color: 'var(--success)' },
];

export default function Tasks() {
  const [projects, setProjects] = useState([]);
  const [users, setUsers] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [selProject, setSelProject] = useState('');
  const [view, setView] = useState('kanban');
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editTask, setEditTask] = useState(null);
  const [form, setForm] = useState({ title: '', description: '', assigned_to: '', priority: 'medium', status: 'pending', due_date: '' });

  useEffect(() => {
    Promise.all([api.get('/projects'), api.get('/admin/users').catch(() => ({ data: [] }))]).then(([p, u]) => {
      setProjects(p.data); setUsers(u.data);
      if (p.data.length) setSelProject(p.data[0].id);
    });
  }, []);

  useEffect(() => {
    if (!selProject) return;
    setLoading(true);
    api.get(`/tasks/project/${selProject}`).then(r => setTasks(r.data)).finally(() => setLoading(false));
  }, [selProject]);

  const openNew = () => { setEditTask(null); setForm({ title: '', description: '', assigned_to: '', priority: 'medium', status: 'pending', due_date: '' }); setShowModal(true); };
  const openEdit = (t) => { setEditTask(t); setForm({ title: t.title, description: t.description || '', assigned_to: t.assigned_to || '', priority: t.priority, status: t.status, due_date: t.due_date || '' }); setShowModal(true); };

  const save = async (e) => {
    e.preventDefault();
    try {
      if (editTask) {
        await api.put(`/tasks/${editTask.id}`, { ...form, project_id: selProject });
        toast.success('Task updated');
      } else {
        await api.post('/tasks', { ...form, project_id: selProject });
        toast.success('Task created');
      }
      setShowModal(false);
      api.get(`/tasks/project/${selProject}`).then(r => setTasks(r.data));
    } catch { toast.error('Failed to save task'); }
  };

  const changeStatus = async (id, status) => {
    await api.put(`/tasks/${id}/status`, { status });
    setTasks(prev => prev.map(t => t.id === id ? { ...t, status } : t));
  };

  const deleteTask = async (id) => {
    if (!window.confirm('Delete this task?')) return;
    await api.delete(`/tasks/${id}`);
    setTasks(prev => prev.filter(t => t.id !== id));
    toast.success('Task deleted');
  };

  const tasksByStatus = (status) => tasks.filter(t => t.status === status);
  const isOverdue = (t) => t.due_date && t.status !== 'completed' && new Date(t.due_date) < new Date();

  const TaskCard = ({ t }) => (
    <div style={{ background: 'var(--surface)', borderRadius: 10, padding: '14px 16px', marginBottom: 10, boxShadow: 'var(--shadow)', border: isOverdue(t) ? '1.5px solid var(--danger)' : '1.5px solid var(--border)', cursor: 'pointer' }} onClick={() => openEdit(t)}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8, marginBottom: 8 }}>
        <span style={{ fontWeight: 600, fontSize: 13, lineHeight: 1.4 }}>{t.title}</span>
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: PRIORITY_STYLE[t.priority]?.dot, flexShrink: 0, marginTop: 3 }} title={t.priority} />
      </div>
      {t.description && <div style={{ fontSize: 12, color: 'var(--text2)', marginBottom: 8, lineHeight: 1.5 }}>{t.description.slice(0, 80)}{t.description.length > 80 ? '…' : ''}</div>}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <span className="badge" style={{ background: PRIORITY_STYLE[t.priority]?.bg, color: PRIORITY_STYLE[t.priority]?.color, fontSize: 11 }}>{t.priority}</span>
          {isOverdue(t) && <span className="badge badge-danger" style={{ fontSize: 11 }}>Overdue</span>}
        </div>
        <div style={{ fontSize: 11, color: 'var(--text2)' }}>
          {t.assigned_name && <span>👤 {t.assigned_name.split(' ')[0]}</span>}
          {t.due_date && <span style={{ marginLeft: 6 }}>📅 {t.due_date}</span>}
        </div>
      </div>
      <div style={{ display: 'flex', gap: 4, marginTop: 10 }} onClick={e => e.stopPropagation()}>
        {STATUS_COLS.filter(s => s.key !== t.status).slice(0, 2).map(s => (
          <button key={s.key} className="btn btn-sm" style={{ fontSize: 11, padding: '3px 8px', background: 'var(--bg)', color: 'var(--text2)' }} onClick={() => changeStatus(t.id, s.key)}>→ {s.label.split(' ')[1]}</button>
        ))}
        <button className="btn btn-sm btn-danger" style={{ fontSize: 11, padding: '3px 8px', marginLeft: 'auto' }} onClick={() => deleteTask(t.id)}>🗑️</button>
      </div>
    </div>
  );

  return (
    <div className="page">
      <div className="page-header">
        <div><div className="page-title">Task Management</div><div className="page-subtitle">{tasks.filter(t => t.status !== 'completed').length} open tasks</div></div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-secondary" onClick={() => setView(view === 'kanban' ? 'list' : 'kanban')}>{view === 'kanban' ? '☰ List' : '⊞ Kanban'}</button>
          <button className="btn btn-primary" onClick={openNew}>+ New Task</button>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 16, marginBottom: 24, flexWrap: 'wrap' }}>
        <select className="form-control" style={{ width: 280 }} value={selProject} onChange={e => setSelProject(e.target.value)}>
          {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </div>

      {loading ? <div className="spinner"><div className="spin" /></div> : view === 'kanban' ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, alignItems: 'start' }}>
          {STATUS_COLS.map(col => (
            <div key={col.key} style={{ background: 'var(--bg)', borderRadius: 12, padding: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
                <span style={{ fontWeight: 700, fontSize: 13, color: col.color }}>{col.label}</span>
                <span style={{ background: 'var(--border)', borderRadius: 20, padding: '2px 8px', fontSize: 12, fontWeight: 600 }}>{tasksByStatus(col.key).length}</span>
              </div>
              {tasksByStatus(col.key).map(t => <TaskCard key={t.id} t={t} />)}
              {tasksByStatus(col.key).length === 0 && <div style={{ textAlign: 'center', padding: '20px 0', color: 'var(--text3)', fontSize: 13 }}>No tasks</div>}
            </div>
          ))}
        </div>
      ) : (
        <div className="card" style={{ padding: 0 }}>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Title</th><th>Priority</th><th>Status</th><th>Assigned To</th><th>Due Date</th><th>Action</th></tr></thead>
              <tbody>
                {tasks.map(t => (
                  <tr key={t.id} style={{ background: isOverdue(t) ? '#FFF5F5' : 'transparent' }}>
                    <td><div style={{ fontWeight: 600 }}>{t.title}</div>{t.description && <div style={{ fontSize: 12, color: 'var(--text2)' }}>{t.description.slice(0, 60)}…</div>}</td>
                    <td><span className="badge" style={{ background: PRIORITY_STYLE[t.priority]?.bg, color: PRIORITY_STYLE[t.priority]?.color }}>{t.priority}</span></td>
                    <td><span className="badge badge-gray">{t.status.replace('_', ' ')}</span></td>
                    <td>{t.assigned_name || '—'}</td>
                    <td style={{ color: isOverdue(t) ? 'var(--danger)' : 'var(--text)' }}>{t.due_date || '—'}{isOverdue(t) && ' ⚠️'}</td>
                    <td><div style={{ display: 'flex', gap: 6 }}><button className="btn btn-sm btn-secondary" onClick={() => openEdit(t)}>✏️</button><button className="btn btn-sm btn-danger" onClick={() => deleteTask(t.id)}>🗑️</button></div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <div className="modal-header"><span className="modal-title">{editTask ? 'Edit Task' : 'New Task'}</span><button className="btn btn-sm btn-secondary" onClick={() => setShowModal(false)}>✕</button></div>
            <form onSubmit={save}>
              <div className="form-group"><label className="form-label">Title *</label><input className="form-control" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} required /></div>
              <div className="form-group"><label className="form-label">Description</label><textarea className="form-control" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
              <div className="grid grid-2">
                <div className="form-group"><label className="form-label">Priority</label>
                  <select className="form-control" value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })}>
                    <option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="urgent">Urgent</option>
                  </select>
                </div>
                <div className="form-group"><label className="form-label">Status</label>
                  <select className="form-control" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                    <option value="pending">Pending</option><option value="in_progress">In Progress</option><option value="blocked">Blocked</option><option value="completed">Completed</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-2">
                <div className="form-group"><label className="form-label">Assign To</label>
                  <select className="form-control" value={form.assigned_to} onChange={e => setForm({ ...form, assigned_to: e.target.value })}>
                    <option value="">Unassigned</option>
                    {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                  </select>
                </div>
                <div className="form-group"><label className="form-label">Due Date</label><input type="date" className="form-control" value={form.due_date} onChange={e => setForm({ ...form, due_date: e.target.value })} /></div>
              </div>
              <div className="modal-footer"><button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button><button type="submit" className="btn btn-primary">{editTask ? 'Save Changes' : 'Create Task'}</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
