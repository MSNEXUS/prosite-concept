import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api';
import toast from 'react-hot-toast';

export default function ProjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({});

  useEffect(() => {
    api.get(`/projects/${id}`).then(r => { setProject(r.data); setForm(r.data); }).finally(() => setLoading(false));
  }, [id]);

  const save = async (e) => {
    e.preventDefault();
    try {
      await api.put(`/projects/${id}`, form);
      setProject(form);
      setEditing(false);
      toast.success('Project updated');
    } catch { toast.error('Failed to update'); }
  };

  const deleteProject = async () => {
    if (!window.confirm('Delete this project and all its data? This cannot be undone.')) return;
    await api.delete(`/projects/${id}`);
    toast.success('Project deleted');
    navigate('/projects');
  };

  if (loading) return <div className="spinner"><div className="spin" /></div>;
  if (!project) return <div className="page"><div className="empty-state"><h3>Project not found</h3></div></div>;

  const statusColor = { active: 'var(--success)', completed: 'var(--info)', on_hold: 'var(--warning)' };

  return (
    <div className="page">
      <div className="page-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button className="btn btn-secondary btn-sm" onClick={() => navigate('/projects')}>← Back</button>
          <div>
            <div className="page-title">{project.name}</div>
            <div className="page-subtitle">📍 {project.location}</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-secondary" onClick={() => setEditing(!editing)}>✏️ Edit</button>
          <button className="btn btn-danger" onClick={deleteProject}>🗑️ Delete</button>
        </div>
      </div>

      {editing ? (
        <div className="card" style={{ maxWidth: 600 }}>
          <div className="card-header"><span className="card-title">Edit Project</span></div>
          <form onSubmit={save}>
            <div className="form-group"><label className="form-label">Name</label><input className="form-control" value={form.name || ''} onChange={e => setForm({ ...form, name: e.target.value })} required /></div>
            <div className="form-group"><label className="form-label">Location</label><input className="form-control" value={form.location || ''} onChange={e => setForm({ ...form, location: e.target.value })} /></div>
            <div className="form-group"><label className="form-label">Description</label><textarea className="form-control" value={form.description || ''} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
            <div className="grid grid-2">
              <div className="form-group"><label className="form-label">Start Date</label><input type="date" className="form-control" value={form.start_date || ''} onChange={e => setForm({ ...form, start_date: e.target.value })} /></div>
              <div className="form-group"><label className="form-label">End Date</label><input type="date" className="form-control" value={form.end_date || ''} onChange={e => setForm({ ...form, end_date: e.target.value })} /></div>
            </div>
            <div className="grid grid-2">
              <div className="form-group"><label className="form-label">Status</label>
                <select className="form-control" value={form.status || 'active'} onChange={e => setForm({ ...form, status: e.target.value })}>
                  <option value="active">Active</option><option value="on_hold">On Hold</option><option value="completed">Completed</option>
                </select>
              </div>
              <div className="form-group"><label className="form-label">Progress (%)</label><input type="number" min="0" max="100" className="form-control" value={form.progress || 0} onChange={e => setForm({ ...form, progress: e.target.value })} /></div>
            </div>
            <div className="form-group"><label className="form-label">Total Budget (₹)</label><input type="number" className="form-control" value={form.budget_total || ''} onChange={e => setForm({ ...form, budget_total: e.target.value })} /></div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button type="submit" className="btn btn-primary">Save Changes</button>
              <button type="button" className="btn btn-secondary" onClick={() => setEditing(false)}>Cancel</button>
            </div>
          </form>
        </div>
      ) : (
        <div className="grid grid-2">
          <div className="card">
            <div className="card-header"><span className="card-title">Project Info</span>
              <span className="badge" style={{ background: statusColor[project.status] + '22', color: statusColor[project.status] }}>{project.status}</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {[
                ['Description', project.description || '—'],
                ['Manager', project.manager_name || '—'],
                ['Start Date', project.start_date || '—'],
                ['End Date', project.end_date || '—'],
                ['Total Budget', project.budget_total ? `₹${project.budget_total.toLocaleString('en-IN')}` : '—'],
              ].map(([label, val]) => (
                <div key={label} style={{ display: 'flex', gap: 12 }}>
                  <span style={{ width: 110, fontSize: 13, color: 'var(--text2)', flexShrink: 0 }}>{label}</span>
                  <span style={{ fontSize: 14, fontWeight: 500 }}>{val}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <div className="card-header"><span className="card-title">Progress</span><span style={{ fontWeight: 700, color: 'var(--brand)', fontSize: 20 }}>{project.progress}%</span></div>
            <div className="progress-bar" style={{ height: 16, marginBottom: 16 }}>
              <div className="progress-fill" style={{ width: `${project.progress}%`, background: project.progress >= 100 ? 'var(--success)' : 'var(--brand)' }} />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
              {[['🗓️', 'Start', project.start_date], ['🏁', 'Deadline', project.end_date], ['📍', 'Location', project.location]].map(([icon, l, v]) => (
                <div key={l} style={{ background: 'var(--bg)', borderRadius: 8, padding: 12, textAlign: 'center' }}>
                  <div style={{ fontSize: 20 }}>{icon}</div>
                  <div style={{ fontSize: 11, color: 'var(--text2)', marginTop: 4 }}>{l}</div>
                  <div style={{ fontSize: 13, fontWeight: 600, marginTop: 2 }}>{v || '—'}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Quick links */}
      <div className="grid grid-4" style={{ marginTop: 24 }}>
        {[
          { icon: '📋', label: 'Site Logs', path: '/logs', color: '#DBEAFE' },
          { icon: '👷', label: 'Attendance', path: '/attendance', color: '#DCFCE7' },
          { icon: '📦', label: 'Materials', path: '/materials', color: '#FEF9C3' },
          { icon: '💰', label: 'Budget', path: '/budget', color: '#FFF0EA' },
        ].map(q => (
          <div key={q.label} className="card" style={{ cursor: 'pointer', textAlign: 'center', padding: 20, background: q.color, boxShadow: 'none', border: '1px solid var(--border)' }}
            onClick={() => navigate(q.path)}>
            <div style={{ fontSize: 32 }}>{q.icon}</div>
            <div style={{ fontWeight: 600, marginTop: 8 }}>{q.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
