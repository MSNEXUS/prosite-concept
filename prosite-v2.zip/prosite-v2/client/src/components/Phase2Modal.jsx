import toast from 'react-hot-toast';

const FEATURES = {
  gps: {
    title: 'GPS Check-In',
    icon: '📍',
    desc: 'Workers can only check in from within the site boundary. Prevents fake attendance.',
    preview: (
      <div style={{ background: '#1a1d2e', borderRadius: 10, padding: 16, margin: '16px 0' }}>
        <div style={{ background: '#2d3148', borderRadius: 8, height: 140, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', inset: 0, backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(59,130,246,0.15) 0%, transparent 70%)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 36 }}>🗺️</div>
              <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 12, marginTop: 8 }}>Site boundary map</div>
              <div style={{ marginTop: 12, background: '#3B82F6', color: '#fff', padding: '8px 20px', borderRadius: 20, fontSize: 13, fontWeight: 600, opacity: 0.5 }}>Check In from Site</div>
            </div>
          </div>
        </div>
        <div style={{ marginTop: 12, display: 'flex', gap: 8 }}>
          {['Biju Thomas — ✅ On site','Ravi Kumar — ❌ 2km away'].map(t => (
            <div key={t} style={{ flex: 1, background: '#2d3148', borderRadius: 6, padding: '8px 10px', fontSize: 11, color: 'rgba(255,255,255,0.6)' }}>{t}</div>
          ))}
        </div>
      </div>
    ),
    phase: 'Phase 2',
    reason: 'Requires device GPS access + geofencing backend'
  },
  whatsapp: {
    title: 'WhatsApp Integration',
    icon: '💬',
    desc: 'Auto-send daily site summaries, payment approvals, and alerts via WhatsApp to stakeholders.',
    preview: (
      <div style={{ background: '#0d1117', borderRadius: 10, padding: 16, margin: '16px 0' }}>
        <div style={{ background: '#128C7E', borderRadius: '8px 8px 0 0', padding: '10px 14px', fontSize: 13, color: '#fff', fontWeight: 600 }}>📱 ProSite Bot</div>
        {[
          { msg: '🏗️ Greenfield Site Update — 10 May\n👷 Present: 48/52\n✅ Work: Slab casting complete\n⚠️ Issue: Pump delay 2hrs', from: 'bot' },
          { msg: 'Approve payment of ₹2,10,000 to Ramco Cements?\n[✅ Approve] [❌ Reject]', from: 'bot' },
          { msg: '✅ Approved', from: 'user' },
        ].map((m, i) => (
          <div key={i} style={{ background: m.from === 'bot' ? '#1e2a1e' : '#2a4a2a', padding: '10px 12px', margin: '4px 0', borderRadius: 8, fontSize: 12, color: 'rgba(255,255,255,0.75)', whiteSpace: 'pre-line', textAlign: m.from === 'user' ? 'right' : 'left' }}>{m.msg}</div>
        ))}
      </div>
    ),
    phase: 'Phase 2',
    reason: 'Requires WhatsApp Business API key (₹ per message)'
  },
  ai: {
    title: 'AI Analytics & Insights',
    icon: '🤖',
    desc: 'AI analyses your project data and gives predictions — budget overrun risk, delay forecasts, worker productivity trends.',
    preview: (
      <div style={{ background: '#1a1d2e', borderRadius: 10, padding: 16, margin: '16px 0' }}>
        <div style={{ fontSize: 12, color: '#8B5CF6', fontWeight: 600, marginBottom: 10 }}>🤖 AI INSIGHTS — Greenfield Residency</div>
        {[
          { label: '⚠️ Budget Risk', value: 'High — Equipment costs trending 18% over estimate. Recommend getting 2 more crane quotes.', color: '#F59E0B' },
          { label: '📅 Delay Forecast', value: 'Current pace suggests 12-day delay. Critical path: 3rd floor slab must start by May 18.', color: '#EF4444' },
          { label: '👷 Top Performer', value: 'Biju Thomas — 98% attendance, zero rework. Recommend for next project.', color: '#22C55E' },
        ].map(a => (
          <div key={a.label} style={{ background: '#2d3148', borderRadius: 8, padding: '10px 12px', marginBottom: 8 }}>
            <div style={{ fontSize: 11, color: a.color, fontWeight: 600 }}>{a.label}</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.65)', marginTop: 4 }}>{a.value}</div>
          </div>
        ))}
      </div>
    ),
    phase: 'Phase 2',
    reason: 'Requires AI API integration + sufficient data history'
  },
  aws: {
    title: 'AWS S3 Cloud Storage',
    icon: '☁️',
    desc: 'All photos, drawings, permits, and documents stored securely on AWS S3. No data loss risk, accessible from anywhere.',
    preview: (
      <div style={{ background: '#1a1d2e', borderRadius: 10, padding: 16, margin: '16px 0' }}>
        <div style={{ fontSize: 12, color: '#F59E0B', fontWeight: 600, marginBottom: 10 }}>☁️ AWS S3 — Project Storage</div>
        {[['📁 Site Photos', '1,247 files', '2.3 GB'],['📐 Drawings', '48 files', '340 MB'],['📄 Permits', '12 files', '18 MB'],['🧾 Bills', '89 files', '124 MB']].map(([name,files,size]) => (
          <div key={name} style={{ display: 'flex', justifyContent: 'space-between', background: '#2d3148', borderRadius: 8, padding: '8px 12px', marginBottom: 6, fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>
            <span>{name}</span><span>{files} · {size}</span>
          </div>
        ))}
        <div style={{ marginTop: 10, fontSize: 11, color: 'rgba(255,255,255,0.35)' }}>✅ 99.99% durability · Auto-backup · Encrypted</div>
      </div>
    ),
    phase: 'Phase 2',
    reason: 'Requires AWS account + S3 bucket setup'
  },
  pdf: {
    title: 'PDF Report Export',
    icon: '📄',
    desc: 'Auto-generate branded weekly/monthly site reports with ProSite branding — ready to email to clients or investors.',
    preview: (
      <div style={{ background: '#f8f9fa', borderRadius: 10, padding: 16, margin: '16px 0', border: '1px solid #e4e6ef' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2px solid #FF6B2B', paddingBottom: 10, marginBottom: 12 }}>
          <div><div style={{ fontWeight: 800, fontSize: 16, color: '#1a1d2e' }}>🏗️ ProSite</div><div style={{ fontSize: 11, color: '#6b7090' }}>Weekly Site Report</div></div>
          <div style={{ fontSize: 11, color: '#6b7090', textAlign: 'right' }}>Greenfield Residency<br/>May 5–10, 2025</div>
        </div>
        {[['Progress','42%'],['Budget Used','₹32.75L / ₹45L'],['Workers this week','48 avg'],['Tasks Completed','3 of 7']].map(([k,v]) => (
          <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', fontSize: 12, borderBottom: '1px solid #e4e6ef', color: '#1a1d2e' }}>
            <span style={{ color: '#6b7090' }}>{k}</span><strong>{v}</strong>
          </div>
        ))}
        <div style={{ marginTop: 10, background: '#FF6B2B', color: '#fff', borderRadius: 6, padding: '6px 12px', fontSize: 12, textAlign: 'center', opacity: 0.5 }}>📥 Download PDF</div>
      </div>
    ),
    phase: 'Phase 2',
    reason: 'PDF generation library — coming soon'
  },
  biometric: {
    title: 'Biometric Integration',
    icon: '👆',
    desc: 'Connect fingerprint scanners at site gates. Attendance auto-syncs to ProSite — zero proxy entries.',
    preview: (
      <div style={{ background: '#1a1d2e', borderRadius: 10, padding: 24, margin: '16px 0', textAlign: 'center' }}>
        <div style={{ fontSize: 52 }}>👆</div>
        <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: 14, marginTop: 12 }}>Place finger on scanner</div>
        <div style={{ background: '#22C55E', color: '#fff', borderRadius: 8, padding: '8px 20px', marginTop: 16, display: 'inline-block', fontSize: 13, opacity: 0.5 }}>✅ Biju Thomas — 08:14 AM</div>
      </div>
    ),
    phase: 'Phase 2',
    reason: 'Requires physical biometric device + SDK integration'
  },
};

export default function Phase2Modal({ featureKey, onClose }) {
  const feature = FEATURES[featureKey];
  if (!feature) return null;

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 520 }}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 44, height: 44, background: 'var(--brand-light)', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>{feature.icon}</div>
            <div>
              <div className="modal-title">{feature.title}</div>
              <span className="phase2-badge">🚧 {feature.phase} — Under Development</span>
            </div>
          </div>
          <button className="btn btn-ghost btn-icon btn-sm" onClick={onClose}>✕</button>
        </div>

        <p style={{ color: 'var(--text2)', fontSize: 14, lineHeight: 1.7 }}>{feature.desc}</p>

        <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 8, padding: '8px 12px', background: 'var(--surface2)', borderRadius: 8 }}>
          ⚙️ <strong>Why not yet:</strong> {feature.reason}
        </div>

        {feature.preview}

        <div className="modal-footer" style={{ flexDirection: 'column', gap: 12 }}>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
            <button className="btn btn-secondary" onClick={onClose}>Close</button>
            <button className="btn btn-primary" onClick={() => { toast.success("We'll notify you when this feature launches! 🚀"); onClose(); }}>
              🔔 Notify Me When Ready
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export { FEATURES };
