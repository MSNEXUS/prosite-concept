import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const NAV_BY_ROLE = {
  owner:      [['/','/dashboard','📊','Command Center'],['','','',''],['🏗️','/projects','🏗️','Projects'],['📋','/logs','📋','Site Logs'],['👷','/attendance','👷','Attendance'],['📦','/materials','📦','Materials'],['✅','/tasks','✅','Tasks'],['💰','/budget','💰','Budget'],['⚙️','/admin','⚙️','Admin Panel']],
  engineer:   [['📋','/logs','📋','Site Logs'],['✅','/tasks','✅','My Tasks'],['📦','/materials','📦','Materials'],['🏗️','/projects','🏗️','Projects'],['💰','/budget','💰','Budget']],
  supervisor: [['👷','/attendance','👷','Attendance'],['📋','/logs','📋','Site Logs'],['📦','/materials','📦','Materials'],['✅','/tasks','✅','Tasks']],
  client:     [['🏠','/client','🏠','My Project'],['📸','/client','📸','Photo Timeline'],['💰','/client','💰','Budget Overview'],['✅','/client','✅','Milestones']],
};

const ROLE_COLOR = { owner: '#F59E0B', engineer: '#3B82F6', supervisor: '#22C55E', client: '#8B5CF6' };
const ROLE_LABEL = { owner: '👑 Owner', engineer: '🔧 Engineer', supervisor: '👷 Supervisor', client: '🤝 Client' };

const NAV_LINKS = {
  owner: [
    { to: '/', icon: '📊', label: 'Command Center', end: true },
    { to: '/projects', icon: '🏗️', label: 'Projects' },
    { to: '/logs', icon: '📋', label: 'Site Logs' },
    { to: '/attendance', icon: '👷', label: 'Attendance' },
    { to: '/materials', icon: '📦', label: 'Materials' },
    { to: '/tasks', icon: '✅', label: 'Tasks' },
    { to: '/budget', icon: '💰', label: 'Budget' },
    { to: '/admin', icon: '⚙️', label: 'Admin Panel' },
  ],
  engineer: [
    { to: '/', icon: '📊', label: 'Dashboard', end: true },
    { to: '/logs', icon: '📋', label: 'Site Logs' },
    { to: '/tasks', icon: '✅', label: 'My Tasks' },
    { to: '/materials', icon: '📦', label: 'Materials' },
    { to: '/projects', icon: '🏗️', label: 'Projects' },
    { to: '/budget', icon: '💰', label: 'Budget' },
  ],
  supervisor: [
    { to: '/', icon: '📊', label: 'Dashboard', end: true },
    { to: '/attendance', icon: '👷', label: 'Attendance' },
    { to: '/logs', icon: '📋', label: 'Site Logs' },
    { to: '/materials', icon: '📦', label: 'Materials' },
    { to: '/tasks', icon: '✅', label: 'Tasks' },
  ],
  client: [
    { to: '/client', icon: '🏠', label: 'My Project', end: true },
  ],
};

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const brandColor = ROLE_COLOR[user?.role] || '#FF6B2B';
  const links = NAV_LINKS[user?.role] || NAV_LINKS.engineer;

  const handleLogout = () => { logout(); toast.success('Logged out'); navigate('/login'); };

  return (
    <aside style={{ width: 'var(--sidebar-w)', position: 'fixed', top: 0, left: 0, height: '100vh', background: 'var(--sidebar-bg)', display: 'flex', flexDirection: 'column', zIndex: 100, overflowY: 'auto' }}>
      {/* Logo */}
      <div style={{ padding: '22px 18px 18px', borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 38, height: 38, background: brandColor, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>🏗️</div>
          <div>
            <div style={{ color: '#fff', fontFamily: 'Syne', fontWeight: 800, fontSize: 19, letterSpacing: '-0.5px' }}>ProSite</div>
            <div style={{ color: brandColor, fontSize: 10, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '1px' }}>{ROLE_LABEL[user?.role]}</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ padding: '14px 10px', flex: 1 }}>
        {links.map(n => (
          <NavLink key={n.to + n.label} to={n.to} end={n.end}
            style={({ isActive }) => ({
              display: 'flex', alignItems: 'center', gap: 11, padding: '10px 12px',
              borderRadius: 10, marginBottom: 2, fontSize: 13, fontWeight: 500,
              color: isActive ? '#fff' : 'rgba(255,255,255,0.5)',
              background: isActive ? brandColor : 'transparent',
              transition: 'all 0.15s',
            })}
          >
            <span style={{ fontSize: 17, width: 20, textAlign: 'center' }}>{n.icon}</span>
            {n.label}
          </NavLink>
        ))}

        {/* Phase 2 section */}
        <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid rgba(255,255,255,0.07)' }}>
          <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.25)', textTransform: 'uppercase', letterSpacing: '1px', padding: '0 12px', marginBottom: 8 }}>Coming Soon</div>
          {[['📍','GPS Check-in'],['💬','WhatsApp'],['🤖','AI Analytics'],['📄','PDF Reports']].map(([icon, label]) => (
            <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '9px 12px', borderRadius: 10, marginBottom: 2, fontSize: 13, color: 'rgba(255,255,255,0.25)', cursor: 'not-allowed', position: 'relative' }}>
              <span style={{ fontSize: 17, width: 20, textAlign: 'center' }}>{icon}</span>
              {label}
              <span style={{ marginLeft: 'auto', fontSize: 9, background: 'rgba(139,92,246,0.3)', color: '#a78bfa', padding: '2px 6px', borderRadius: 10, fontWeight: 600 }}>P2</span>
            </div>
          ))}
        </div>
      </nav>

      {/* User */}
      <div style={{ padding: '12px 10px', borderTop: '1px solid rgba(255,255,255,0.07)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.05)' }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: brandColor, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 13, flexShrink: 0 }}>{user?.name?.charAt(0)}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ color: '#fff', fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{user?.name}</div>
            <div style={{ color: 'rgba(255,255,255,0.35)', fontSize: 11 }}>{user?.email}</div>
          </div>
          <button onClick={handleLogout} title="Logout" style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.3)', fontSize: 16, padding: 4, flexShrink: 0 }}>↩</button>
        </div>
      </div>
    </aside>
  );
}
