import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Phase2Modal from './Phase2Modal';
import api from '../api';

const PAGE_TITLES = { '/':' Dashboard', '/projects':'Projects', '/logs':'Site Logs', '/attendance':'Attendance', '/materials':'Materials', '/tasks':'Tasks', '/budget':'Budget', '/admin':'Admin Panel', '/client':'My Project' };

export default function Topbar() {
  const location = useLocation();
  const { user } = useAuth();
  const [notifs, setNotifs] = useState([]);
  const [showNotifs, setShowNotifs] = useState(false);
  const [phase2Feature, setPhase2Feature] = useState(null);

  useEffect(() => { api.get('/admin/notifications').then(r => setNotifs(r.data)).catch(() => {}); }, []);

  const unread = notifs.filter(n => !n.read).length;
  const markRead = async id => { await api.put(`/admin/notifications/${id}/read`); setNotifs(prev => prev.map(n => n.id===id ? {...n,read:1} : n)); };
  const markAll = async () => { await api.put('/admin/notifications/read-all'); setNotifs(prev => prev.map(n => ({...n,read:1}))); setShowNotifs(false); };
  const typeIcon = { alert:'🚨', warning:'⚠️', reminder:'⏰', info:'ℹ️' };

  return (
    <>
      <header style={{ background:'var(--surface)', borderBottom:'1px solid var(--border)', padding:'0 32px', height:62, display:'flex', alignItems:'center', justifyContent:'space-between', position:'sticky', top:0, zIndex:50, gap:16 }}>
        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          <h2 style={{ fontSize:18, fontWeight:700 }}>{PAGE_TITLES[location.pathname] || 'ProSite'}</h2>
          {user?.role !== 'client' && (
            <div style={{ display:'flex', gap:6' }}>
              {[['gps','📍 GPS'],['pdf','📄 PDF'],['whatsapp','💬 WhatsApp'],['ai','🤖 AI']].map(([key,label]) => (
                <button key={key} onClick={() => setPhase2Feature(key)} className="btn btn-secondary btn-sm" style={{ fontSize:11, padding:'4px 10px', opacity:0.75 }}>
                  {label} <span style={{ fontSize:9, background:'rgba(139,92,246,0.2)', color:'#7C3AED', padding:'1px 5px', borderRadius:8, marginLeft:3, fontWeight:700 }}>P2</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ fontSize:12, color:'var(--text2)' }}>
            {new Date().toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short',year:'numeric'})}
          </div>
          {/* Bell */}
          <div style={{ position:'relative' }}>
            <button onClick={() => setShowNotifs(!showNotifs)} className="btn btn-secondary btn-icon" style={{ fontSize:16, position:'relative' }}>
              🔔
              {unread > 0 && <span style={{ position:'absolute', top:-4, right:-4, background:'var(--danger)', color:'#fff', borderRadius:'50%', width:17, height:17, fontSize:10, display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700 }}>{unread > 9 ? '9+' : unread}</span>}
            </button>
            {showNotifs && (
              <div style={{ position:'absolute', right:0, top:'110%', width:360, background:'var(--surface)', borderRadius:12, boxShadow:'var(--shadow-lg)', border:'1px solid var(--border)', zIndex:200 }}>
                <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                  <span style={{ fontWeight:700 }}>Notifications {unread > 0 && <span style={{ background:'var(--danger)', color:'#fff', borderRadius:20, padding:'1px 7px', fontSize:11, marginLeft:6 }}>{unread}</span>}</span>
                  {unread > 0 && <button onClick={markAll} className="btn btn-sm btn-secondary">Mark all read</button>}
                </div>
                <div style={{ maxHeight:380, overflowY:'auto' }}>
                  {notifs.length===0 ? <div style={{ padding:24, textAlign:'center', color:'var(--text2)' }}>No notifications</div>
                  : notifs.slice(0,15).map(n => (
                    <div key={n.id} onClick={() => markRead(n.id)} style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', background:n.read ? 'transparent' : 'var(--brand-light)', cursor:'pointer' }}>
                      <div style={{ display:'flex', gap:10, alignItems:'flex-start' }}>
                        <span style={{ fontSize:16 }}>{typeIcon[n.type]||'ℹ️'}</span>
                        <div>
                          <div style={{ fontWeight:600, fontSize:13 }}>{n.title}</div>
                          <div style={{ fontSize:12, color:'var(--text2)', marginTop:2, lineHeight:1.5 }}>{n.message}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </header>
      {phase2Feature && <Phase2Modal featureKey={phase2Feature} onClose={() => setPhase2Feature(null)} />}
    </>
  );
}
