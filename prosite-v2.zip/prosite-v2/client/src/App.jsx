import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Projects from './pages/Projects';
import ProjectDetail from './pages/ProjectDetail';
import SiteLogs from './pages/SiteLogs';
import Attendance from './pages/Attendance';
import Materials from './pages/Materials';
import Tasks from './pages/Tasks';
import Budget from './pages/Budget';
import Admin from './pages/Admin';
import ClientView from './pages/ClientView';

function PrivateLayout({ children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  return (
    <div className="app-layout">
      <Sidebar />
      <div className="main-content">
        <Topbar />
        {children}
      </div>
    </div>
  );
}

function AppRoutes() {
  const { user } = useAuth();
  if (!user) return <Routes><Route path="*" element={<Login />} /></Routes>;

  // Client gets their own view
  if (user.role === 'client') {
    return (
      <Routes>
        <Route path="/client" element={<PrivateLayout><ClientView /></PrivateLayout>} />
        <Route path="*" element={<Navigate to="/client" />} />
      </Routes>
    );
  }

  return (
    <Routes>
      <Route path="/login" element={<Navigate to="/" />} />
      <Route path="/" element={<PrivateLayout><Dashboard /></PrivateLayout>} />
      <Route path="/projects" element={<PrivateLayout><Projects /></PrivateLayout>} />
      <Route path="/projects/:id" element={<PrivateLayout><ProjectDetail /></PrivateLayout>} />
      <Route path="/logs" element={<PrivateLayout><SiteLogs /></PrivateLayout>} />
      <Route path="/attendance" element={<PrivateLayout><Attendance /></PrivateLayout>} />
      <Route path="/materials" element={<PrivateLayout><Materials /></PrivateLayout>} />
      <Route path="/tasks" element={<PrivateLayout><Tasks /></PrivateLayout>} />
      <Route path="/budget" element={<PrivateLayout><Budget /></PrivateLayout>} />
      <Route path="/admin" element={<PrivateLayout><Admin /></PrivateLayout>} />
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
        <Toaster position="top-right" toastOptions={{ style: { fontFamily: 'DM Sans,sans-serif', fontSize: '14px', borderRadius: '10px' } }} />
      </BrowserRouter>
    </AuthProvider>
  );
}
