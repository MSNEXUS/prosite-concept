const router = require('express').Router();
const db = require('../db/schema');
const auth = require('../middleware/auth');

router.get('/project/:projectId', auth, (req, res) => {
  res.json(db.prepare('SELECT * FROM worker_roster WHERE project_id = ? AND active = 1 ORDER BY role, worker_name').all(req.params.projectId));
});

router.post('/', auth, (req, res) => {
  const { project_id, worker_name, role, daily_wage, phone } = req.body;
  const existing = db.prepare('SELECT id FROM worker_roster WHERE project_id = ? AND worker_name = ?').get(project_id, worker_name);
  if (existing) return res.status(400).json({ error: 'Worker already in roster' });
  const result = db.prepare('INSERT INTO worker_roster (project_id, worker_name, role, daily_wage, phone) VALUES (?,?,?,?,?)').run(project_id, worker_name, role, daily_wage || 0, phone || '');
  res.json({ id: result.lastInsertRowid });
});

router.put('/:id', auth, (req, res) => {
  const { worker_name, role, daily_wage, phone, active } = req.body;
  db.prepare('UPDATE worker_roster SET worker_name=?, role=?, daily_wage=?, phone=?, active=? WHERE id=?').run(worker_name, role, daily_wage, phone, active ?? 1, req.params.id);
  res.json({ message: 'Updated' });
});

router.delete('/:id', auth, (req, res) => {
  db.prepare('DELETE FROM worker_roster WHERE id = ?').run(req.params.id);
  res.json({ message: 'Removed from roster' });
});

// Wage summary for a date
router.get('/project/:projectId/wages/:date', auth, (req, res) => {
  const att = db.prepare(`
    SELECT a.*, wr.daily_wage as roster_wage
    FROM attendance a
    LEFT JOIN worker_roster wr ON wr.project_id = a.project_id AND wr.worker_name = a.worker_name
    WHERE a.project_id = ? AND a.date = ?
  `).all(req.params.projectId, req.params.date);

  let total = 0;
  const breakdown = att.map(a => {
    const wage = a.daily_wage || a.roster_wage || 0;
    const earned = a.status === 'present' ? wage + (a.overtime_hours * wage / 8)
                 : a.status === 'half_day' ? wage / 2 : 0;
    total += earned;
    return { ...a, earned };
  });
  res.json({ breakdown, total, date: req.params.date });
});

module.exports = router;
