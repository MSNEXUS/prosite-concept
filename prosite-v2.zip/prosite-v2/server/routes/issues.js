const router = require('express').Router();
const db = require('../db/schema');
const auth = require('../middleware/auth');

router.get('/project/:projectId', auth, (req, res) => {
  const issues = db.prepare(`
    SELECT i.*, u.name as raised_by_name
    FROM issues i LEFT JOIN users u ON i.raised_by = u.id
    WHERE i.project_id = ? ORDER BY i.created_at DESC
  `).all(req.params.projectId);
  res.json(issues);
});

router.get('/open', auth, (req, res) => {
  const issues = db.prepare(`
    SELECT i.*, u.name as raised_by_name, p.name as project_name
    FROM issues i
    LEFT JOIN users u ON i.raised_by = u.id
    JOIN projects p ON i.project_id = p.id
    WHERE i.status = 'open' ORDER BY CASE i.severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 ELSE 3 END, i.created_at DESC
  `).all();
  res.json(issues);
});

router.post('/', auth, (req, res) => {
  const { project_id, title, description, severity } = req.body;
  const result = db.prepare('INSERT INTO issues (project_id, title, description, raised_by, severity) VALUES (?,?,?,?,?)').run(project_id, title, description, req.user.id, severity || 'high');
  // Notify all owners
  const owners = db.prepare("SELECT id FROM users WHERE role='owner'").all();
  const notifInsert = db.prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,'alert')");
  const project = db.prepare('SELECT name FROM projects WHERE id=?').get(project_id);
  owners.forEach(o => notifInsert.run(o.id, `🚨 Issue Raised: ${title}`, `${req.user.name} raised a ${severity} issue at ${project?.name}: ${description?.slice(0,100)}`));
  res.json({ id: result.lastInsertRowid });
});

router.put('/:id/resolve', auth, (req, res) => {
  db.prepare("UPDATE issues SET status='resolved', resolved_at=CURRENT_TIMESTAMP WHERE id=?").run(req.params.id);
  res.json({ message: 'Resolved' });
});

module.exports = router;
