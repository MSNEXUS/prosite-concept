const router = require('express').Router();
const db = require('../db/schema');
const auth = require('../middleware/auth');

router.get('/project/:projectId', auth, (req, res) => {
  const materials = db.prepare(`
    SELECT *, CASE WHEN qty_remaining <= min_stock THEN 1 ELSE 0 END as low_stock
    FROM materials WHERE project_id = ? ORDER BY name
  `).all(req.params.projectId);
  res.json(materials);
});

router.get('/alerts', auth, (req, res) => {
  const alerts = db.prepare(`
    SELECT m.*, p.name as project_name
    FROM materials m JOIN projects p ON m.project_id = p.id
    WHERE m.qty_remaining <= m.min_stock
    ORDER BY (m.qty_remaining - m.min_stock) ASC
  `).all();
  res.json(alerts);
});

router.post('/', auth, (req, res) => {
  const { project_id, name, unit, qty_received, min_stock, unit_cost, supplier } = req.body;
  const result = db.prepare(`
    INSERT INTO materials (project_id, name, unit, qty_received, qty_remaining, min_stock, unit_cost, supplier)
    VALUES (?,?,?,?,?,?,?,?)
  `).run(project_id, name, unit, qty_received || 0, qty_received || 0, min_stock || 0, unit_cost || 0, supplier || '');
  res.json({ id: result.lastInsertRowid });
});

// Record a transaction (receive / use)
router.post('/:id/transaction', auth, (req, res) => {
  const { type, quantity, notes, date } = req.body;
  const mat = db.prepare('SELECT * FROM materials WHERE id = ?').get(req.params.id);
  if (!mat) return res.status(404).json({ error: 'Material not found' });

  let new_received = mat.qty_received;
  let new_used = mat.qty_used;
  if (type === 'received') new_received += Number(quantity);
  if (type === 'used') new_used += Number(quantity);
  const new_remaining = new_received - new_used;

  db.prepare('UPDATE materials SET qty_received=?, qty_used=?, qty_remaining=?, last_updated=CURRENT_TIMESTAMP WHERE id=?')
    .run(new_received, new_used, new_remaining, req.params.id);
  db.prepare('INSERT INTO material_transactions (material_id, type, quantity, notes, date, recorded_by) VALUES (?,?,?,?,?,?)')
    .run(req.params.id, type, quantity, notes || '', date || new Date().toISOString().split('T')[0], req.user.id);

  // Check for low stock alert
  const updated = db.prepare('SELECT * FROM materials WHERE id = ?').get(req.params.id);
  if (updated.qty_remaining <= updated.min_stock) {
    db.prepare(`INSERT INTO notifications (user_id, title, message, type) VALUES (1, ?, ?, 'alert')`)
      .run(`Low Stock: ${updated.name}`, `${updated.name} has only ${updated.qty_remaining} ${updated.unit} remaining (min: ${updated.min_stock}).`);
  }
  res.json({ message: 'Transaction recorded', remaining: new_remaining });
});

router.get('/:id/transactions', auth, (req, res) => {
  const txns = db.prepare(`
    SELECT mt.*, u.name as recorded_by_name
    FROM material_transactions mt LEFT JOIN users u ON mt.recorded_by = u.id
    WHERE mt.material_id = ? ORDER BY mt.date DESC
  `).all(req.params.id);
  res.json(txns);
});

router.put('/:id', auth, (req, res) => {
  const { name, unit, min_stock, unit_cost, supplier } = req.body;
  db.prepare('UPDATE materials SET name=?, unit=?, min_stock=?, unit_cost=?, supplier=?, last_updated=CURRENT_TIMESTAMP WHERE id=?')
    .run(name, unit, min_stock, unit_cost, supplier, req.params.id);
  res.json({ message: 'Updated' });
});

router.delete('/:id', auth, (req, res) => {
  db.prepare('DELETE FROM materials WHERE id = ?').run(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
