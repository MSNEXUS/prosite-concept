const router = require('express').Router();
const db = require('../db/schema');
const auth = require('../middleware/auth');

router.get('/project/:projectId', auth, (req, res) => {
  const { status, priority } = req.query;
  let query = `
    SELECT t.*, u.name as assigned_name, p.name as project_name
    FROM tasks t JOIN projects p ON t.project_id = p.id LEFT JOIN users u ON t.assigned_to = u.id
    WHERE t.project_id = ?
  `;
  const params = [req.params.projectId];
  if (status) { query += ' AND t.status = ?'; params.push(status); }
  if (priority) { query += ' AND t.priority = ?'; params.push(priority); }
  query += ' ORDER BY CASE t.priority WHEN "urgent" THEN 1 WHEN "high" THEN 2 WHEN "medium" THEN 3 ELSE 4 END, t.due_date ASC';
  res.json(db.prepare(query).all(...params));
});

router.get('/all', auth, (req, res) => {
  const tasks = db.prepare(`
    SELECT t.*, u.name as assigned_name, p.name as project_name
    FROM tasks t JOIN projects p ON t.project_id = p.id LEFT JOIN users u ON t.assigned_to = u.id
    WHERE t.status != 'completed'
    ORDER BY CASE t.priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END
  `).all();
  res.json(tasks);
});

router.post('/', auth, (req, res) => {
  const { project_id, title, description, assigned_to, priority, due_date } = req.body;
  const result = db.prepare(`
    INSERT INTO tasks (project_id, title, description, assigned_to, priority, due_date)
    VALUES (?,?,?,?,?,?)
  `).run(project_id, title, description, assigned_to, priority || 'medium', due_date);
  res.json({ id: result.lastInsertRowid });
});

router.put('/:id/status', auth, (req, res) => {
  const { status } = req.body;
  const completed_at = status === 'completed' ? new Date().toISOString() : null;
  db.prepare('UPDATE tasks SET status=?, completed_at=? WHERE id=?').run(status, completed_at, req.params.id);
  res.json({ message: 'Status updated' });
});

router.put('/:id', auth, (req, res) => {
  const { title, description, assigned_to, priority, status, due_date } = req.body;
  const completed_at = status === 'completed' ? new Date().toISOString() : null;
  db.prepare(`UPDATE tasks SET title=?, description=?, assigned_to=?, priority=?, status=?, due_date=?, completed_at=? WHERE id=?`)
    .run(title, description, assigned_to, priority, status, due_date, completed_at, req.params.id);
  res.json({ message: 'Task updated' });
});

router.delete('/:id', auth, (req, res) => {
  db.prepare('DELETE FROM tasks WHERE id = ?').run(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
