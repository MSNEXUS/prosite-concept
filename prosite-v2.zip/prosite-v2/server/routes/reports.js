const router = require('express').Router();
const db = require('../db/schema');
const auth = require('../middleware/auth');

// Summary report data for a project (used by frontend to generate PDF)
router.get('/project/:projectId/summary', auth, (req, res) => {
  const project = db.prepare(`SELECT p.*, u.name as manager_name FROM projects p LEFT JOIN users u ON p.manager_id = u.id WHERE p.id = ?`).get(req.params.projectId);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const budget = db.prepare(`SELECT SUM(estimated) as estimated, SUM(actual) as actual FROM budget_categories WHERE project_id = ?`).get(req.params.projectId);
  const tasks_summary = db.prepare(`SELECT status, COUNT(*) as count FROM tasks WHERE project_id = ? GROUP BY status`).all(req.params.projectId);
  const attendance_7d = db.prepare(`
    SELECT date, COUNT(*) as total, SUM(CASE WHEN status='present' THEN 1 ELSE 0 END) as present
    FROM attendance WHERE project_id = ? AND date >= date('now', '-7 days') GROUP BY date ORDER BY date
  `).all(req.params.projectId);
  const low_stock = db.prepare(`SELECT * FROM materials WHERE project_id = ? AND qty_remaining <= min_stock`).all(req.params.projectId);
  const recent_logs = db.prepare(`
    SELECT sl.*, u.name as logged_by FROM site_logs sl JOIN users u ON sl.user_id = u.id
    WHERE sl.project_id = ? ORDER BY sl.date DESC LIMIT 7
  `).all(req.params.projectId);
  const expenses = db.prepare(`
    SELECT e.*, bc.name as category FROM expenses e JOIN budget_categories bc ON e.category_id = bc.id
    WHERE e.project_id = ? ORDER BY e.date DESC LIMIT 20
  `).all(req.params.projectId);

  res.json({ project, budget, tasks_summary, attendance_7d, low_stock, recent_logs, expenses, generated_at: new Date().toISOString() });
});

module.exports = router;
