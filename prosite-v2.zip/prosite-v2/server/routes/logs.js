const router = require('express').Router();
const db = require('../db/schema');
const auth = require('../middleware/auth');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const uploadDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: uploadDir,
  filename: (req, file, cb) => {
    cb(null, `log_${Date.now()}_${Math.random().toString(36).slice(2)}${path.extname(file.originalname)}`);
  }
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 }, fileFilter: (req, file, cb) => {
  cb(null, /image\/(jpeg|jpg|png|webp)/.test(file.mimetype));
}});

// Get logs for a project
router.get('/project/:projectId', auth, (req, res) => {
  const logs = db.prepare(`
    SELECT sl.*, u.name as logged_by,
      (SELECT COUNT(*) FROM log_photos WHERE log_id = sl.id) as photo_count
    FROM site_logs sl JOIN users u ON sl.user_id = u.id
    WHERE sl.project_id = ? ORDER BY sl.date DESC, sl.created_at DESC
  `).all(req.params.projectId);
  res.json(logs);
});

// Get single log with photos
router.get('/:id', auth, (req, res) => {
  const log = db.prepare(`
    SELECT sl.*, u.name as logged_by, p.name as project_name
    FROM site_logs sl JOIN users u ON sl.user_id = u.id JOIN projects p ON sl.project_id = p.id
    WHERE sl.id = ?
  `).get(req.params.id);
  if (!log) return res.status(404).json({ error: 'Log not found' });
  log.photos = db.prepare('SELECT * FROM log_photos WHERE log_id = ?').all(req.params.id);
  res.json(log);
});

// Create log
router.post('/', auth, (req, res) => {
  const { project_id, date, work_done, issues, weather, manpower } = req.body;
  const result = db.prepare(`
    INSERT INTO site_logs (project_id, user_id, date, work_done, issues, weather, manpower)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(project_id, req.user.id, date || new Date().toISOString().split('T')[0], work_done, issues, weather, manpower || 0);
  res.json({ id: result.lastInsertRowid, message: 'Log created' });
});

// Upload photos to a log
router.post('/:id/photos', auth, upload.array('photos', 10), (req, res) => {
  const logId = req.params.id;
  const captions = req.body.captions ? JSON.parse(req.body.captions) : [];
  const insertPhoto = db.prepare('INSERT INTO log_photos (log_id, filename, caption) VALUES (?,?,?)');
  req.files.forEach((file, i) => insertPhoto.run(logId, file.filename, captions[i] || ''));
  res.json({ message: `${req.files.length} photo(s) uploaded`, count: req.files.length });
});

// Update log
router.put('/:id', auth, (req, res) => {
  const { work_done, issues, weather, manpower } = req.body;
  db.prepare('UPDATE site_logs SET work_done=?, issues=?, weather=?, manpower=? WHERE id=?')
    .run(work_done, issues, weather, manpower, req.params.id);
  res.json({ message: 'Log updated' });
});

// Delete log
router.delete('/:id', auth, (req, res) => {
  const photos = db.prepare('SELECT filename FROM log_photos WHERE log_id = ?').all(req.params.id);
  photos.forEach(p => {
    const fp = path.join(uploadDir, p.filename);
    if (fs.existsSync(fp)) fs.unlinkSync(fp);
  });
  db.prepare('DELETE FROM site_logs WHERE id = ?').run(req.params.id);
  res.json({ message: 'Log deleted' });
});

module.exports = router;
