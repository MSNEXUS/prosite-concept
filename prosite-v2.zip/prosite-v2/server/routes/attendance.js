const router = require('express').Router();
const db = require('../db/schema');
const auth = require('../middleware/auth');

router.get('/project/:projectId', auth, (req, res) => {
  const { date } = req.query;
  let query = 'SELECT * FROM attendance WHERE project_id=?';
  const params = [req.params.projectId];
  if (date) { query += ' AND date=?'; params.push(date); }
  query += ' ORDER BY date DESC, worker_name ASC';
  res.json(db.prepare(query).all(...params));
});

router.get('/project/:projectId/summary', auth, (req, res) => {
  const d = req.query.date || new Date().toISOString().split('T')[0];
  const rows = db.prepare("SELECT status, COUNT(*) as count FROM attendance WHERE project_id=? AND date=? GROUP BY status").all(req.params.projectId, d);
  const summary = { present: 0, absent: 0, half_day: 0, total: 0 };
  rows.forEach(r => { summary[r.status] = r.count; summary.total += r.count; });
  res.json(summary);
});

router.post('/bulk', auth, (req, res) => {
  const { project_id, date, records } = req.body;
  const insert = db.prepare('INSERT INTO attendance (project_id,worker_name,role,daily_wage,date,check_in,check_out,status,overtime_hours,notes) VALUES (?,?,?,?,?,?,?,?,?,?)');
  db.transaction(() => {
    db.prepare('DELETE FROM attendance WHERE project_id=? AND date=?').run(project_id, date);
    records.forEach(r => insert.run(project_id, r.worker_name, r.role, r.daily_wage||0, date, r.check_in, r.check_out, r.status||'present', r.overtime_hours||0, r.notes||''));
  })();
  res.json({ message: `${records.length} records saved` });
});

router.post('/', auth, (req, res) => {
  const { project_id, worker_name, role, daily_wage, date, check_in, check_out, status, overtime_hours, notes } = req.body;
  const result = db.prepare('INSERT INTO attendance (project_id,worker_name,role,daily_wage,date,check_in,check_out,status,overtime_hours,notes) VALUES (?,?,?,?,?,?,?,?,?,?)').run(project_id, worker_name, role, daily_wage||0, date, check_in, check_out, status||'present', overtime_hours||0, notes||'');
  res.json({ id: result.lastInsertRowid });
});

router.put('/:id', auth, (req, res) => {
  const { check_in, check_out, status, overtime_hours, notes } = req.body;
  db.prepare('UPDATE attendance SET check_in=?,check_out=?,status=?,overtime_hours=?,notes=? WHERE id=?').run(check_in, check_out, status, overtime_hours||0, notes, req.params.id);
  res.json({ message: 'Updated' });
});

router.get('/project/:projectId/trend', auth, (req, res) => {
  const trend = db.prepare(`
    SELECT date, COUNT(*) as total,
      SUM(CASE WHEN status='present' THEN 1 ELSE 0 END) as present,
      SUM(CASE WHEN status='absent' THEN 1 ELSE 0 END) as absent
    FROM attendance WHERE project_id=? GROUP BY date ORDER BY date DESC LIMIT 30
  `).all(req.params.projectId);
  res.json(trend.reverse());
});

module.exports = router;
