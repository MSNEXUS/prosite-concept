const router = require('express').Router();
const db = require('../db/schema');
const auth = require('../middleware/auth');

router.get('/project/:projectId', auth, (req, res) => {
  res.json(db.prepare('SELECT * FROM milestones WHERE project_id = ? ORDER BY target_date').all(req.params.projectId));
});

router.post('/', auth, (req, res) => {
  const { project_id, title, description, target_date, payment_amount } = req.body;
  const result = db.prepare('INSERT INTO milestones (project_id, title, description, target_date, payment_amount) VALUES (?,?,?,?,?)').run(project_id, title, description, target_date, payment_amount || 0);
  res.json({ id: result.lastInsertRowid });
});

router.put('/:id/complete', auth, (req, res) => {
  db.prepare("UPDATE milestones SET status='completed', completed_at=CURRENT_TIMESTAMP WHERE id=?").run(req.params.id);
  const m = db.prepare('SELECT * FROM milestones WHERE id=?').get(req.params.id);
  db.prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (1,?,?,'info')").run(
    `Milestone Completed: ${m.title}`, `Milestone "${m.title}" has been marked complete. Awaiting client approval.`
  );
  res.json({ message: 'Marked complete' });
});

router.put('/:id/approve', auth, (req, res) => {
  if (req.user.role !== 'client' && req.user.role !== 'owner') return res.status(403).json({ error: 'Not allowed' });
  db.prepare('UPDATE milestones SET client_approved=1 WHERE id=?').run(req.params.id);
  const m = db.prepare('SELECT * FROM milestones WHERE id=?').get(req.params.id);
  db.prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (1,?,?,'info')").run(
    `✅ Milestone Approved by Client`, `"${m.title}" approved. Payment of ₹${m.payment_amount?.toLocaleString('en-IN')} is now due.`
  );
  res.json({ message: 'Approved' });
});

router.put('/:id', auth, (req, res) => {
  const { title, description, target_date, payment_amount, status } = req.body;
  db.prepare('UPDATE milestones SET title=?, description=?, target_date=?, payment_amount=?, status=? WHERE id=?').run(title, description, target_date, payment_amount, status, req.params.id);
  res.json({ message: 'Updated' });
});

router.delete('/:id', auth, (req, res) => {
  db.prepare('DELETE FROM milestones WHERE id=?').run(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
