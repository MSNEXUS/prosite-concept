const router = require('express').Router();
const db = require('../db/schema');
const auth = require('../middleware/auth');

router.get('/project/:projectId', auth, (req, res) => {
  const categories = db.prepare(`
    SELECT bc.*, 
      ROUND((bc.actual / NULLIF(bc.estimated, 0)) * 100, 1) as utilization_pct,
      CASE WHEN bc.actual > bc.estimated THEN 1 ELSE 0 END as over_budget
    FROM budget_categories bc WHERE bc.project_id = ?
  `).all(req.params.projectId);
  const summary = db.prepare(`
    SELECT SUM(estimated) as total_estimated, SUM(actual) as total_actual,
      SUM(estimated) - SUM(actual) as remaining
    FROM budget_categories WHERE project_id = ?
  `).get(req.params.projectId);
  res.json({ categories, summary });
});

router.get('/project/:projectId/expenses', auth, (req, res) => {
  const expenses = db.prepare(`
    SELECT e.*, bc.name as category_name, u.name as added_by_name
    FROM expenses e
    JOIN budget_categories bc ON e.category_id = bc.id
    LEFT JOIN users u ON e.added_by = u.id
    WHERE e.project_id = ? ORDER BY e.date DESC
  `).all(req.params.projectId);
  res.json(expenses);
});

router.post('/category', auth, (req, res) => {
  const { project_id, name, estimated } = req.body;
  const result = db.prepare('INSERT INTO budget_categories (project_id, name, estimated) VALUES (?,?,?)').run(project_id, name, estimated || 0);
  res.json({ id: result.lastInsertRowid });
});

router.post('/expense', auth, (req, res) => {
  const { category_id, project_id, description, amount, date, payment_status, bill_ref } = req.body;
  const result = db.prepare(`
    INSERT INTO expenses (category_id, project_id, description, amount, date, payment_status, bill_ref, added_by)
    VALUES (?,?,?,?,?,?,?,?)
  `).run(category_id, project_id, description, amount, date, payment_status || 'pending', bill_ref || '', req.user.id);
  // Update category actual
  db.prepare('UPDATE budget_categories SET actual = (SELECT COALESCE(SUM(amount),0) FROM expenses WHERE category_id = ?) WHERE id = ?')
    .run(category_id, category_id);
  // Over-budget notification
  const cat = db.prepare('SELECT * FROM budget_categories WHERE id = ?').get(category_id);
  if (cat.actual > cat.estimated) {
    db.prepare(`INSERT INTO notifications (user_id, title, message, type) VALUES (1,?,?,'warning')`)
      .run(`Budget Overrun: ${cat.name}`, `${cat.name} has exceeded its budget. Estimated: ₹${cat.estimated.toLocaleString()}, Actual: ₹${cat.actual.toLocaleString()}`);
  }
  res.json({ id: result.lastInsertRowid });
});

router.put('/expense/:id', auth, (req, res) => {
  const { description, amount, date, payment_status, bill_ref } = req.body;
  const expense = db.prepare('SELECT * FROM expenses WHERE id = ?').get(req.params.id);
  db.prepare('UPDATE expenses SET description=?, amount=?, date=?, payment_status=?, bill_ref=? WHERE id=?')
    .run(description, amount, date, payment_status, bill_ref, req.params.id);
  db.prepare('UPDATE budget_categories SET actual = (SELECT COALESCE(SUM(amount),0) FROM expenses WHERE category_id = ?) WHERE id = ?')
    .run(expense.category_id, expense.category_id);
  res.json({ message: 'Updated' });
});

router.delete('/expense/:id', auth, (req, res) => {
  const expense = db.prepare('SELECT * FROM expenses WHERE id = ?').get(req.params.id);
  db.prepare('DELETE FROM expenses WHERE id = ?').run(req.params.id);
  db.prepare('UPDATE budget_categories SET actual = (SELECT COALESCE(SUM(amount),0) FROM expenses WHERE category_id = ?) WHERE id = ?')
    .run(expense.category_id, expense.category_id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
