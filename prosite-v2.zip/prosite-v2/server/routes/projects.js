const router = require('express').Router();
const db = require('../db/schema');
const auth = require('../middleware/auth');

router.get('/', auth, (req, res) => {
  // Client only sees their assigned project
  if (req.user.role === 'client') {
    const user = db.prepare('SELECT assigned_project_id FROM users WHERE id=?').get(req.user.id);
    if (!user?.assigned_project_id) return res.json([]);
    const p = db.prepare(`SELECT p.*, u.name as manager_name,
      (SELECT COUNT(*) FROM tasks WHERE project_id=p.id AND status!='completed') as open_tasks,
      (SELECT COUNT(*) FROM tasks WHERE project_id=p.id AND status='completed') as completed_tasks,
      (SELECT SUM(actual) FROM budget_categories WHERE project_id=p.id) as spent
      FROM projects p LEFT JOIN users u ON p.manager_id=u.id WHERE p.id=?`).get(user.assigned_project_id);
    return res.json(p ? [p] : []);
  }
  const projects = db.prepare(`
    SELECT p.*, u.name as manager_name,
      (SELECT COUNT(*) FROM tasks WHERE project_id=p.id AND status!='completed') as open_tasks,
      (SELECT COUNT(*) FROM tasks WHERE project_id=p.id AND status='completed') as completed_tasks,
      (SELECT SUM(actual) FROM budget_categories WHERE project_id=p.id) as spent
    FROM projects p LEFT JOIN users u ON p.manager_id=u.id
    ORDER BY p.created_at DESC
  `).all();
  res.json(projects);
});

router.get('/:id', auth, (req, res) => {
  const project = db.prepare(`SELECT p.*, u.name as manager_name FROM projects p LEFT JOIN users u ON p.manager_id=u.id WHERE p.id=?`).get(req.params.id);
  if (!project) return res.status(404).json({ error: 'Not found' });
  res.json(project);
});

router.post('/', auth, (req, res) => {
  const { name, location, description, start_date, end_date, budget_total, manager_id } = req.body;
  const result = db.prepare('INSERT INTO projects (name,location,description,start_date,end_date,budget_total,manager_id) VALUES (?,?,?,?,?,?,?)').run(name, location, description, start_date, end_date, budget_total || 0, manager_id || req.user.id);
  res.json({ id: result.lastInsertRowid });
});

router.put('/:id', auth, (req, res) => {
  const { name, location, description, start_date, end_date, budget_total, status, progress, manager_id } = req.body;
  db.prepare('UPDATE projects SET name=?,location=?,description=?,start_date=?,end_date=?,budget_total=?,status=?,progress=?,manager_id=? WHERE id=?').run(name, location, description, start_date, end_date, budget_total, status, progress, manager_id, req.params.id);
  res.json({ message: 'Updated' });
});

router.delete('/:id', auth, (req, res) => {
  db.prepare('DELETE FROM projects WHERE id=?').run(req.params.id);
  res.json({ message: 'Deleted' });
});

// Owner command center — full cross-project summary
router.get('/meta/dashboard', auth, (req, res) => {
  const stats = {
    total_projects:     db.prepare("SELECT COUNT(*) as c FROM projects").get().c,
    active_projects:    db.prepare("SELECT COUNT(*) as c FROM projects WHERE status='active'").get().c,
    completed_projects: db.prepare("SELECT COUNT(*) as c FROM projects WHERE status='completed'").get().c,
    open_tasks:         db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status!='completed'").get().c,
    overdue_tasks:      db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status!='completed' AND due_date<date('now')").get().c,
    total_workers_today:db.prepare("SELECT COUNT(*) as c FROM attendance WHERE date=date('now') AND status='present'").get().c,
    low_stock_alerts:   db.prepare("SELECT COUNT(*) as c FROM materials WHERE qty_remaining<=min_stock").get().c,
    open_issues:        db.prepare("SELECT COUNT(*) as c FROM issues WHERE status='open'").get().c,
    critical_issues:    db.prepare("SELECT COUNT(*) as c FROM issues WHERE status='open' AND severity='critical'").get().c,
    total_budget:       db.prepare("SELECT SUM(budget_total) as s FROM projects WHERE status='active'").get().s || 0,
    total_spent:        db.prepare("SELECT SUM(actual) as s FROM budget_categories").get().s || 0,
    pending_milestones: db.prepare("SELECT COUNT(*) as c FROM milestones WHERE status='completed' AND client_approved=0").get().c,
  };

  // Burn rate forecast per active project
  const burnForecasts = db.prepare(`
    SELECT p.id, p.name, p.budget_total, p.end_date, p.start_date, p.progress,
      COALESCE((SELECT SUM(actual) FROM budget_categories WHERE project_id=p.id),0) as spent
    FROM projects p WHERE p.status='active'
  `).all().map(p => {
    const today = new Date();
    const start = new Date(p.start_date);
    const end = new Date(p.end_date);
    const totalDays = Math.max((end - start) / 86400000, 1);
    const elapsed = Math.max((today - start) / 86400000, 1);
    const remaining = Math.max((end - today) / 86400000, 0);
    const burnRate = p.spent / elapsed; // per day
    const forecastTotal = p.spent + (burnRate * remaining);
    const overrun = forecastTotal - p.budget_total;
    return { ...p, burnRate: Math.round(burnRate), forecastTotal: Math.round(forecastTotal), overrun: Math.round(overrun), remaining_days: Math.round(remaining) };
  });

  const recent_logs = db.prepare(`
    SELECT sl.*, p.name as project_name, u.name as logged_by
    FROM site_logs sl JOIN projects p ON sl.project_id=p.id JOIN users u ON sl.user_id=u.id
    ORDER BY sl.created_at DESC LIMIT 5
  `).all();

  const urgent_tasks = db.prepare(`
    SELECT t.*, p.name as project_name, u.name as assigned_name
    FROM tasks t JOIN projects p ON t.project_id=p.id LEFT JOIN users u ON t.assigned_to=u.id
    WHERE t.status!='completed' AND t.priority IN ('urgent','high')
    ORDER BY CASE t.priority WHEN 'urgent' THEN 1 ELSE 2 END, t.due_date ASC LIMIT 6
  `).all();

  const open_issues = db.prepare(`
    SELECT i.*, u.name as raised_by_name, p.name as project_name
    FROM issues i LEFT JOIN users u ON i.raised_by=u.id JOIN projects p ON i.project_id=p.id
    WHERE i.status='open' ORDER BY CASE i.severity WHEN 'critical' THEN 1 ELSE 2 END LIMIT 5
  `).all();

  res.json({ stats, burnForecasts, recent_logs, urgent_tasks, open_issues });
});

// Client project summary (read-only)
router.get('/:id/client-summary', auth, (req, res) => {
  const project = db.prepare('SELECT p.*, u.name as manager_name FROM projects p LEFT JOIN users u ON p.manager_id=u.id WHERE p.id=?').get(req.params.id);
  if (!project) return res.status(404).json({ error: 'Not found' });
  const budget = db.prepare('SELECT SUM(estimated) as estimated, SUM(actual) as actual FROM budget_categories WHERE project_id=?').get(req.params.id);
  const milestones = db.prepare('SELECT * FROM milestones WHERE project_id=? ORDER BY target_date').all(req.params.id);
  const photos = db.prepare(`SELECT lp.*, sl.date, sl.project_id FROM log_photos lp JOIN site_logs sl ON lp.log_id=sl.id WHERE sl.project_id=? ORDER BY sl.date DESC LIMIT 20`).all(req.params.id);
  const tasks_summary = db.prepare("SELECT status, COUNT(*) as count FROM tasks WHERE project_id=? GROUP BY status").all(req.params.id);
  res.json({ project, budget, milestones, photos, tasks_summary });
});

module.exports = router;
