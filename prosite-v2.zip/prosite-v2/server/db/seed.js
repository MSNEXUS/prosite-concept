const db = require('./schema');
const bcrypt = require('bcryptjs');

console.log('🌱 Seeding ProSite v2 demo data...\n');

db.exec(`
  DELETE FROM expenses; DELETE FROM budget_categories;
  DELETE FROM issues; DELETE FROM milestones;
  DELETE FROM tasks; DELETE FROM material_transactions;
  DELETE FROM materials; DELETE FROM attendance;
  DELETE FROM worker_roster; DELETE FROM log_photos;
  DELETE FROM site_logs; DELETE FROM notifications;
  DELETE FROM projects; DELETE FROM users;
`);

const hash = bcrypt.hashSync('demo1234', 10);

// ── Users ──────────────────────────────────────────────────────────────────
const insertUser = db.prepare(`INSERT INTO users (name, email, password, role, phone, assigned_project_id) VALUES (?,?,?,?,?,?)`);
insertUser.run('Arjun Menon',    'admin@prosite.in',      hash, 'owner',      '9876543210', null);
insertUser.run('Ravi Kumar',     'engineer@prosite.in',   hash, 'engineer',   '9876543211', null);
insertUser.run('Suresh Pillai',  'supervisor@prosite.in', hash, 'supervisor', '9876543212', null);
insertUser.run('Deepa Nair',     'deepa@prosite.in',      hash, 'engineer',   '9876543213', null);
insertUser.run('Thomas Varghese','client@prosite.in',     hash, 'client',     '9876543214', 1);
console.log('✅ Users created (password: demo1234 for all)');

// ── Projects ───────────────────────────────────────────────────────────────
const insertProject = db.prepare(`INSERT INTO projects (name, location, description, start_date, end_date, status, budget_total, progress, manager_id) VALUES (?,?,?,?,?,?,?,?,?)`);
insertProject.run('Greenfield Residency Phase 2', 'Kakkanad, Kochi',  '120-unit residential complex — G+12 floors', '2024-09-01', '2025-08-31', 'active',    4500000,  42, 2);
insertProject.run('TechPark Tower Block B',       'Infopark, Kochi',  'Commercial office tower, 14 floors',         '2024-11-15', '2026-03-31', 'active',    12000000, 18, 2);
insertProject.run('NH Bypass Road Widening',      'Thrissur',         'State highway expansion — 12km stretch',     '2024-06-01', '2024-12-31', 'completed', 2800000,  100,1);
console.log('✅ Projects created');

// ── Worker Roster ──────────────────────────────────────────────────────────
const insertRoster = db.prepare(`INSERT INTO worker_roster (project_id, worker_name, role, daily_wage, phone) VALUES (?,?,?,?,?)`);
const rosterData = [
  [1,'Biju Thomas','Mason',800,'9845001001'],
  [1,'Sajan George','Mason',800,'9845001002'],
  [1,'Manoj Varma','Carpenter',900,'9845001003'],
  [1,'Pradeep Nair','Electrician',1000,'9845001004'],
  [1,'Anwar Hussain','Helper',600,'9845001005'],
  [1,'Rajesh Mohan','Plumber',950,'9845001006'],
  [1,'Vineeth Kumar','Steel Binder',850,'9845001007'],
  [1,'Anil Pillai','Helper',600,'9845001008'],
  [1,'Sreekumar P','Mason',800,'9845001009'],
  [1,'Jose Mathew','Carpenter',900,'9845001010'],
  [2,'Ramesh Babu','Mason',800,'9845002001'],
  [2,'Krishnan C','Helper',600,'9845002002'],
  [2,'Mohan Das','Steel Binder',850,'9845002003'],
];
rosterData.forEach(r => insertRoster.run(...r));
console.log('✅ Worker roster created');

// ── Attendance ─────────────────────────────────────────────────────────────
const insertAtt = db.prepare(`INSERT INTO attendance (project_id, worker_name, role, daily_wage, date, check_in, check_out, status, overtime_hours) VALUES (?,?,?,?,?,?,?,?,?)`);
const attDates = ['2025-05-10','2025-05-09','2025-05-08'];
rosterData.filter(r=>r[0]===1).forEach((w,i) => {
  attDates.forEach(date => {
    const st = i===6?'absent':i===4?'half_day':'present';
    const ot = i===2&&date==='2025-05-10'?2:0;
    insertAtt.run(1,w[1],w[2],w[3],date,st==='absent'?null:'08:15',st==='absent'?null:st==='half_day'?'13:00':'17:30',st,ot);
  });
});
console.log('✅ Attendance created');

// ── Site Logs ──────────────────────────────────────────────────────────────
const insertLog = db.prepare(`INSERT INTO site_logs (project_id, user_id, date, work_done, issues, weather, manpower, is_quick_log) VALUES (?,?,?,?,?,?,?,?)`);
insertLog.run(1,2,'2025-05-10','Completed slab casting for B-block 3rd floor. Formwork removed from 2nd floor. Electrical conduit work 60% done on east wing.','Concrete pump delayed by 2 hours due to traffic on NH bypass. Minor rework on column C14.','Sunny, 34°C',48,0);
insertLog.run(1,2,'2025-05-09','Rebar placement completed for columns C12 to C18. Electrical conduits laid in 2nd floor corridor.','Minor rework needed on column C14 due to alignment issue.','Partly cloudy',52,0);
insertLog.run(1,3,'2025-05-08','Brickwork started on 2nd floor eastern wing. 60% of day\'s target achieved.','Cement stock running low — restocked by EOD.','Humid, 36°C',45,1);
insertLog.run(2,4,'2025-05-10','Pile foundation work ongoing. 24 of 80 piles completed. Dewatering pump installed.','Rig breakdown — 3 hours downtime. Vendor contacted.','Clear',30,0);
console.log('✅ Site logs created');

// ── Materials ──────────────────────────────────────────────────────────────
const insertMat = db.prepare(`INSERT INTO materials (project_id, name, unit, qty_received, qty_used, qty_remaining, min_stock, unit_cost, supplier) VALUES (?,?,?,?,?,?,?,?,?)`);
[
  [1,'Cement (53 Grade)','Bags',2000,1450,550,200,420,'Ramco Cements'],
  [1,'TMT Steel Bars','Tonnes',85,62,23,10,62000,'Vizag Steel'],
  [1,'River Sand','Loads',120,98,22,15,8500,'Local Supplier'],
  [1,'Aggregate 20mm','Loads',90,71,19,10,7200,'Granite Works'],
  [1,'Bricks (Red)','Nos',50000,32000,18000,5000,8,'Kerala Bricks'],
  [1,'Plywood (12mm)','Sheets',300,278,22,30,1800,'Greenply'],
  [2,'Cement (53 Grade)','Bags',800,310,490,100,420,'Ramco Cements'],
  [2,'TMT Steel Bars','Tonnes',40,12,28,8,62000,'Vizag Steel'],
].forEach(m => insertMat.run(...m));
console.log('✅ Materials created');

// ── Milestones ─────────────────────────────────────────────────────────────
const insertMilestone = db.prepare(`INSERT INTO milestones (project_id, title, description, target_date, status, completed_at, payment_amount, client_approved) VALUES (?,?,?,?,?,?,?,?)`);
insertMilestone.run(1,'Foundation & Plinth','Complete foundation work, plinth beam, and anti-termite treatment','2024-11-30','completed','2024-11-28',900000,1);
insertMilestone.run(1,'Ground Floor Slab','Ground floor slab casting and column work up to 1st floor level','2025-01-31','completed','2025-01-29',900000,1);
insertMilestone.run(1,'3rd Floor Structure','Complete structural work up to 3rd floor slab','2025-05-31','in_progress',null,900000,0);
insertMilestone.run(1,'Roof Slab & Waterproofing','Roof slab casting and two-coat waterproofing','2025-08-15','pending',null,900000,0);
insertMilestone.run(1,'Finishing & Handover','Plastering, tiling, electrical, plumbing, painting complete','2025-08-31','pending',null,900000,0);
insertMilestone.run(2,'Pile Foundation','All 80 piles + pile cap','2025-06-30','in_progress',null,2400000,0);
insertMilestone.run(2,'Ground Floor','Ground floor slab + columns','2025-09-30','pending',null,2400000,0);
console.log('✅ Milestones created');

// ── Issues (escalations) ───────────────────────────────────────────────────
const insertIssue = db.prepare(`INSERT INTO issues (project_id, title, description, raised_by, severity, status) VALUES (?,?,?,?,?,?)`);
insertIssue.run(1,'Concrete pump vendor delay','Pump vendor failed to show up on time. Lost 2 hours of productive time on slab day. Need backup vendor.',2,'high','open');
insertIssue.run(2,'Rig breakdown — pile work halted','Piling rig hydraulic failure. Vendor says 2 day repair. Work on hold.',4,'critical','open');
insertIssue.run(1,'Alignment issue column C14','Column C14 is 18mm off from drawing. Needs rework before next slab.',2,'high','resolved');
console.log('✅ Issues created');

// ── Tasks ──────────────────────────────────────────────────────────────────
const insertTask = db.prepare(`INSERT INTO tasks (project_id, title, description, assigned_to, priority, status, due_date) VALUES (?,?,?,?,?,?,?)`);
[
  [1,'Complete 3rd floor slab casting','All columns and beams must be ready. Coordinate with concrete pump vendor.',2,'urgent','in_progress','2025-05-15'],
  [1,'Order next batch of TMT steel','Min 20 tonnes needed for 4th floor work starting next week.',3,'high','pending','2025-05-12'],
  [1,'Electrical conduit 2nd floor','All conduits to be laid before plastering begins.',2,'medium','in_progress','2025-05-20'],
  [1,'Waterproofing terrace','Apply 2 coats of SBR waterproofing on terrace slab.',3,'low','pending','2025-06-01'],
  [1,'Submit PWD inspection report','Prepare all compliance documents for PWD inspection.',2,'high','completed','2025-05-08'],
  [2,'Complete remaining 56 piles','Rig back in service. Target 8 piles/day.',4,'urgent','in_progress','2025-05-25'],
  [2,'Soil test report submission','Submit final soil bearing capacity report to structural engineer.',4,'high','completed','2025-05-05'],
].forEach(t => insertTask.run(...t));
console.log('✅ Tasks created');

// ── Budget ─────────────────────────────────────────────────────────────────
const insertCat = db.prepare(`INSERT INTO budget_categories (project_id, name, estimated, actual) VALUES (?,?,?,?)`);
[
  [1,'Materials',2200000,1840000],[1,'Labour',900000,720000],
  [1,'Equipment Rental',350000,410000],[1,'Site Overheads',150000,98000],
  [1,'Contractor Fees',400000,320000],[1,'Contingency',500000,87000],
  [2,'Materials',5500000,980000],[2,'Labour',2500000,340000],
  [2,'Equipment Rental',1200000,520000],[2,'Contractor Fees',1800000,200000],
].forEach(c => insertCat.run(...c));

const insertExp = db.prepare(`INSERT INTO expenses (category_id, project_id, description, amount, date, payment_status, bill_ref, added_by) VALUES (?,?,?,?,?,?,?,?)`);
[
  [1,1,'Ramco Cement – 500 bags batch 3',210000,'2025-05-08','paid','INV-RC-2847',2],
  [1,1,'Vizag Steel – 15T TMT delivery',930000,'2025-05-06','paid','INV-VS-1042',2],
  [1,1,'River Sand – 20 loads',170000,'2025-05-03','pending','RS-045',3],
  [2,1,'Labour wages – April 2025',360000,'2025-05-01','paid','PAY-APR-25',1],
  [3,1,'Concrete pump rental – May week 1',45000,'2025-05-07','paid','PMP-012',3],
  [3,1,'Tower crane monthly rent',120000,'2025-05-01','paid','CRN-MAY25',2],
].forEach(e => insertExp.run(...e));
console.log('✅ Budget & expenses created');

// ── Notifications ──────────────────────────────────────────────────────────
const insertNotif = db.prepare(`INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)`);
[
  [1,'🚨 Critical Issue Raised','Rig breakdown at TechPark Tower — pile work halted. Raised by Deepa Nair.','alert'],
  [1,'⚠️ Low Stock: Plywood (12mm)','Only 22 sheets remaining at Greenfield Residency. Minimum is 30.','alert'],
  [1,'💸 Budget Overrun: Equipment Rental','Equipment Rental exceeded estimate by ₹60,000 at Greenfield.','warning'],
  [1,'✅ Milestone Approved','Thomas Varghese approved Ground Floor Slab milestone. ₹9L payment due.','info'],
  [2,'📋 Task Due Tomorrow','Order next batch of TMT steel is due on 2025-05-12.','reminder'],
  [5,'🏗️ Progress Update','Your project Greenfield Residency is now 42% complete.','info'],
  [5,'✅ Milestone Completed','Ground Floor Slab milestone completed and approved.','info'],
].forEach(n => insertNotif.run(...n));
console.log('✅ Notifications created');

console.log('\n🎉 ProSite v2 seed complete!\n');
console.log('   👑 Owner:      admin@prosite.in      / demo1234');
console.log('   🔧 Engineer:   engineer@prosite.in   / demo1234');
console.log('   👷 Supervisor: supervisor@prosite.in / demo1234');
console.log('   🤝 Client:     client@prosite.in     / demo1234\n');
