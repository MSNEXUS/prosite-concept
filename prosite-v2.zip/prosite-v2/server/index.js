require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({ origin: ['http://localhost:3000','http://localhost:3001'], credentials: true }));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

require('./db/schema');

app.use('/api/auth',       require('./routes/auth'));
app.use('/api/projects',   require('./routes/projects'));
app.use('/api/logs',       require('./routes/logs'));
app.use('/api/attendance', require('./routes/attendance'));
app.use('/api/roster',     require('./routes/roster'));
app.use('/api/materials',  require('./routes/materials'));
app.use('/api/tasks',      require('./routes/tasks'));
app.use('/api/budget',     require('./routes/budget'));
app.use('/api/admin',      require('./routes/admin'));
app.use('/api/reports',    require('./routes/reports'));
app.use('/api/milestones', require('./routes/milestones'));
app.use('/api/issues',     require('./routes/issues'));

app.get('/api/health', (req, res) => res.json({ status: 'ProSite v2 API ✅', version: '2.0' }));

app.listen(PORT, () => {
  console.log(`\n🏗️  ProSite v2 Server → http://localhost:${PORT}`);
  console.log(`📦  Database: SQLite | 🔑 Auth: JWT | 🎭 Roles: owner/engineer/supervisor/client\n`);
});
