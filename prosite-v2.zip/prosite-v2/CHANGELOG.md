# ProSite v2.0 — Changelog

## What's New vs v1

### 🎨 Design
- Role-based color themes: Owner=Gold, Engineer=Blue, Supervisor=Green, Client=Purple
- Premium card design with gradient accents, glassmorphism, layered shadows
- Smooth hover animations on all interactive elements
- Better typography and spacing throughout

### 👑 Owner Improvements
- **Command Center Dashboard** — all projects at a glance, no clicking into each one
- **Budget Burn Forecasting** — predicts if project will overrun based on current spend rate
- **Open Issues feed** on dashboard — critical issues shown as red alerts
- **Milestone pending approval** alerts on dashboard
- **Smart alert banners** for critical issues, low stock, pending payments

### 🔧 Engineer Improvements
- **Issue Escalation button** on dashboard — raises urgent alert to owner immediately
- **⚡ Quick Log mode** — 30-second log entry, just work + manpower + photo
- **My Tasks view** on dashboard — only tasks assigned to this engineer
- **Full Log vs Quick Log** toggle in site logs

### 👷 Supervisor Improvements
- **Saved Worker Roster** — add workers once, load them every day with one button
- **Wage Calculator** — set daily wage per worker, auto-calculates earned amount
- **Overtime tracking** — mark OT hours, auto-adds to wage calculation
- **Wage Breakdown modal** — detailed per-worker cost for the day
- Roster management tab — add/remove/edit workers

### 🤝 Client Role (NEW)
- Separate login with purple theme
- **My Project** view — read-only, clean interface
- **Photo Timeline** — chronological gallery of all site photos
- **Milestone tracker** — see status of each milestone
- **Approve milestone button** — client approves + triggers payment notification
- **Budget overview** — simplified money summary (budget, spent, remaining)
- **Payment schedule** — see locked/released payments per milestone
- Coming soon teasers: Report download, Message manager, WhatsApp updates

### 🚧 Phase 2 Buttons (NEW)
- All Phase 2 features now have buttons in the topbar
- Clicking shows a popup with:
  1. "Under Development" badge
  2. Visual demo preview of what the feature will look like
  3. "Notify Me When Ready" button
- Features covered: GPS Check-in, WhatsApp Integration, AI Analytics, AWS S3, PDF Reports, Biometric

### 🗄️ Database
- New `worker_roster` table — saved workers per project
- New `milestones` table — project milestones with payment amounts
- New `issues` table — escalated issues with severity levels
- `attendance` table — added `daily_wage`, `overtime_hours` fields
- `users` table — added `assigned_project_id` for client role
- `site_logs` table — added `is_quick_log` flag

### 🔌 New API Routes
- `GET/POST/PUT/DELETE /api/roster` — worker roster management
- `GET /api/roster/project/:id/wages/:date` — wage calculation
- `GET/POST/PUT /api/milestones` — milestone management
- `PUT /api/milestones/:id/complete` — mark milestone done
- `PUT /api/milestones/:id/approve` — client approves milestone
- `GET/POST /api/issues` — issue escalation
- `PUT /api/issues/:id/resolve` — resolve issue
- `GET /api/projects/:id/client-summary` — client read-only summary
- Enhanced `/api/projects/meta/dashboard` — now includes burn forecasts, open issues

## Run Instructions (same as before)

```
# Terminal 1 — Backend
cd server
del prosite.db     (Windows) / rm prosite.db (Mac)
node db/seed.js
node index.js

# Terminal 2 — Frontend
cd client
npx react-scripts start
```

## Demo Logins
| Role | Email | Password |
|------|-------|----------|
| 👑 Owner | admin@prosite.in | demo1234 |
| 🔧 Engineer | engineer@prosite.in | demo1234 |
| 👷 Supervisor | supervisor@prosite.in | demo1234 |
| 🤝 Client | client@prosite.in | demo1234 |
