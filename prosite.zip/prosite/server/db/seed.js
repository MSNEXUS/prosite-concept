const db = require('./schema');
const bcrypt = require('bcryptjs');

console.log('🌱 Seeding ProSite demo data...\n');

// Clear existing data
db.exec(`
  DELETE FROM expenses; DELETE FROM budget_categories;
  DELETE FROM tasks; DELETE FROM material_transactions;
  DELETE FROM materials; DELETE FROM attendance;
  DELETE FROM log_photos; DELETE FROM site_logs;
  DELETE FROM projects; DELETE FROM users;
  DELETE FROM notifications;
`);

// ── Users ──────────────────────────────────────────────────────────────────
const hash = bcrypt.hashSync('demo1234', 10);
const users = [
  { name: 'Arjun Menon',     email: 'admin@prosite.in',      role: 'owner',      phone: '9876543210' },
  { name: 'Ravi Kumar',      email: 'engineer@prosite.in',   role: 'engineer',   phone: '9876543211' },
  { name: 'Suresh Pillai',   email: 'supervisor@prosite.in', role: 'supervisor', phone: '9876543212' },
  { name: 'Deepa Nair',      email: 'deepa@prosite.in',      role: 'engineer',   phone: '9876543213' },
];
const insertUser = db.prepare(`INSERT INTO users (name, email, password, role, phone) VALUES (?,?,?,?,?)`);
users.forEach(u => insertUser.run(u.name, u.email, hash, u.role, u.phone));
console.log('✅ Users created (password: demo1234 for all)');

// ── Projects ───────────────────────────────────────────────────────────────
const projects = [
  { name: 'Greenfield Residency Phase 2', location: 'Kakkanad, Kochi', description: '120-unit residential complex', start_date: '2024-09-01', end_date: '2025-08-31', status: 'active', budget_total: 4500000, progress: 42, manager_id: 1 },
  { name: 'TechPark Tower Block B',       location: 'Infopark, Kochi', description: 'Commercial office tower, 14 floors', start_date: '2024-11-15', end_date: '2026-03-31', status: 'active', budget_total: 12000000, progress: 18, manager_id: 2 },
  { name: 'NH Bypass Road Widening',      location: 'Thrissur',        description: 'State highway expansion project', start_date: '2024-06-01', end_date: '2024-12-31', status: 'completed', budget_total: 2800000, progress: 100, manager_id: 1 },
];
const insertProject = db.prepare(`INSERT INTO projects (name, location, description, start_date, end_date, status, budget_total, progress, manager_id) VALUES (?,?,?,?,?,?,?,?,?)`);
projects.forEach(p => insertProject.run(p.name, p.location, p.description, p.start_date, p.end_date, p.status, p.budget_total, p.progress, p.manager_id));
console.log('✅ Projects created');

// ── Site Logs ──────────────────────────────────────────────────────────────
const logs = [
  { project_id: 1, user_id: 2, date: '2025-05-10', work_done: 'Completed slab casting for B-block 3rd floor. Formwork removed from 2nd floor.', issues: 'Concrete pump delayed by 2 hours due to traffic.', weather: 'Sunny, 34°C', manpower: 48 },
  { project_id: 1, user_id: 2, date: '2025-05-09', work_done: 'Rebar placement completed for columns C12 to C18. Electrical conduits laid.', issues: 'Minor rework needed on column C14 due to alignment issue.', weather: 'Partly cloudy', manpower: 52 },
  { project_id: 1, user_id: 3, date: '2025-05-08', work_done: 'Brickwork started on 2nd floor eastern wing. 60% of day\'s target achieved.', issues: 'Cement stock running low — restocked by EOD.', weather: 'Humid, 36°C', manpower: 45 },
  { project_id: 2, user_id: 4, date: '2025-05-10', work_done: 'Pile foundation work ongoing. 24 of 80 piles completed.', issues: 'Rig breakdown — 3 hours downtime.', weather: 'Clear', manpower: 30 },
  { project_id: 2, user_id: 4, date: '2025-05-09', work_done: 'Soil excavation for remaining foundation area completed.', issues: 'None', weather: 'Clear', manpower: 35 },
];
const insertLog = db.prepare(`INSERT INTO site_logs (project_id, user_id, date, work_done, issues, weather, manpower) VALUES (?,?,?,?,?,?,?)`);
logs.forEach(l => insertLog.run(l.project_id, l.user_id, l.date, l.work_done, l.issues, l.weather, l.manpower));
console.log('✅ Site logs created');

// ── Attendance ─────────────────────────────────────────────────────────────
const workers = [
  { name: 'Biju Thomas',    role: 'Mason' },
  { name: 'Sajan George',   role: 'Mason' },
  { name: 'Manoj Varma',    role: 'Carpenter' },
  { name: 'Pradeep Nair',   role: 'Electrician' },
  { name: 'Anwar Hussain',  role: 'Helper' },
  { name: 'Rajesh Mohan',   role: 'Plumber' },
  { name: 'Vineeth Kumar',  role: 'Steel Binder' },
  { name: 'Anil Pillai',    role: 'Helper' },
];
const statuses = ['present', 'present', 'present', 'present', 'half_day', 'present', 'absent', 'present'];
const insertAtt = db.prepare(`INSERT INTO attendance (project_id, worker_name, role, date, check_in, check_out, status) VALUES (?,?,?,?,?,?,?)`);
workers.forEach((w, i) => {
  ['2025-05-10', '2025-05-09', '2025-05-08'].forEach(date => {
    const st = statuses[i % statuses.length];
    insertAtt.run(1, w.name, w.role, date, st === 'absent' ? null : '08:15', st === 'absent' ? null : (st === 'half_day' ? '13:00' : '17:30'), st);
  });
});
console.log('✅ Attendance records created');

// ── Materials ──────────────────────────────────────────────────────────────
const materials = [
  { project_id: 1, name: 'Cement (53 Grade)',  unit: 'Bags',   qty_received: 2000, qty_used: 1450, min_stock: 200, unit_cost: 420,    supplier: 'Ramco Cements' },
  { project_id: 1, name: 'TMT Steel Bars',     unit: 'Tonnes', qty_received: 85,   qty_used: 62,   min_stock: 10,  unit_cost: 62000,  supplier: 'Vizag Steel' },
  { project_id: 1, name: 'River Sand',         unit: 'Loads',  qty_received: 120,  qty_used: 98,   min_stock: 15,  unit_cost: 8500,   supplier: 'Local Supplier' },
  { project_id: 1, name: 'Aggregate 20mm',     unit: 'Loads',  qty_received: 90,   qty_used: 71,   min_stock: 10,  unit_cost: 7200,   supplier: 'Granite Works' },
  { project_id: 1, name: 'Bricks (Red)',       unit: 'Nos',    qty_received: 50000,qty_used: 32000,min_stock: 5000,unit_cost: 8,      supplier: 'Kerala Bricks' },
  { project_id: 1, name: 'Plywood (12mm)',     unit: 'Sheets', qty_received: 300,  qty_used: 278,  min_stock: 30,  unit_cost: 1800,   supplier: 'Greenply' },
  { project_id: 2, name: 'Cement (53 Grade)',  unit: 'Bags',   qty_received: 800,  qty_used: 310,  min_stock: 100, unit_cost: 420,    supplier: 'Ramco Cements' },
  { project_id: 2, name: 'TMT Steel Bars',     unit: 'Tonnes', qty_received: 40,   qty_used: 12,   min_stock: 8,   unit_cost: 62000,  supplier: 'Vizag Steel' },
];
const insertMat = db.prepare(`INSERT INTO materials (project_id, name, unit, qty_received, qty_used, qty_remaining, min_stock, unit_cost, supplier) VALUES (?,?,?,?,?,?,?,?,?)`);
materials.forEach(m => insertMat.run(m.project_id, m.name, m.unit, m.qty_received, m.qty_used, m.qty_received - m.qty_used, m.min_stock, m.unit_cost, m.supplier));
console.log('✅ Materials created');

// ── Tasks ──────────────────────────────────────────────────────────────────
const tasks = [
  { project_id: 1, title: 'Complete 3rd floor slab casting', description: 'All columns and beams must be ready. Coordinate with concrete pump vendor.', assigned_to: 2, priority: 'urgent', status: 'in_progress', due_date: '2025-05-15' },
  { project_id: 1, title: 'Order next batch of TMT steel',   description: 'Min 20 tonnes needed for 4th floor work starting next week.',                assigned_to: 3, priority: 'high',   status: 'pending',     due_date: '2025-05-12' },
  { project_id: 1, title: 'Electrical conduit 2nd floor',    description: 'All conduits to be laid before plastering begins.',                           assigned_to: 2, priority: 'medium', status: 'in_progress', due_date: '2025-05-20' },
  { project_id: 1, title: 'Waterproofing terrace',           description: 'Apply 2 coats of SBR waterproofing on terrace slab.',                         assigned_to: 3, priority: 'low',    status: 'pending',     due_date: '2025-06-01' },
  { project_id: 1, title: 'Submit inspection report',        description: 'PWD inspection scheduled. Prepare all compliance documents.',                  assigned_to: 2, priority: 'high',   status: 'completed',   due_date: '2025-05-08' },
  { project_id: 2, title: 'Complete remaining 56 piles',     description: 'Rig back in service. Target 8 piles/day.',                                    assigned_to: 4, priority: 'urgent', status: 'in_progress', due_date: '2025-05-25' },
  { project_id: 2, title: 'Soil test report submission',     description: 'Submit final soil bearing capacity report to structural engineer.',            assigned_to: 4, priority: 'high',   status: 'completed',   due_date: '2025-05-05' },
];
const insertTask = db.prepare(`INSERT INTO tasks (project_id, title, description, assigned_to, priority, status, due_date) VALUES (?,?,?,?,?,?,?)`);
tasks.forEach(t => insertTask.run(t.project_id, t.title, t.description, t.assigned_to, t.priority, t.status, t.due_date));
console.log('✅ Tasks created');

// ── Budget ─────────────────────────────────────────────────────────────────
const categories = [
  { project_id: 1, name: 'Materials',        estimated: 2200000, actual: 1840000 },
  { project_id: 1, name: 'Labour',           estimated: 900000,  actual: 720000  },
  { project_id: 1, name: 'Equipment Rental', estimated: 350000,  actual: 410000  },
  { project_id: 1, name: 'Site Overheads',   estimated: 150000,  actual: 98000   },
  { project_id: 1, name: 'Contractor Fees',  estimated: 400000,  actual: 320000  },
  { project_id: 1, name: 'Contingency',      estimated: 500000,  actual: 87000   },
  { project_id: 2, name: 'Materials',        estimated: 5500000, actual: 980000  },
  { project_id: 2, name: 'Labour',           estimated: 2500000, actual: 340000  },
  { project_id: 2, name: 'Equipment Rental', estimated: 1200000, actual: 520000  },
  { project_id: 2, name: 'Contractor Fees',  estimated: 1800000, actual: 200000  },
];
const insertCat = db.prepare(`INSERT INTO budget_categories (project_id, name, estimated, actual) VALUES (?,?,?,?)`);
categories.forEach(c => insertCat.run(c.project_id, c.name, c.estimated, c.actual));

const expenses = [
  { category_id: 1, project_id: 1, description: 'Ramco Cement – 500 bags batch 3',  amount: 210000, date: '2025-05-08', payment_status: 'paid',    bill_ref: 'INV-RC-2847', added_by: 2 },
  { category_id: 1, project_id: 1, description: 'Vizag Steel – 15T TMT delivery',    amount: 930000, date: '2025-05-06', payment_status: 'paid',    bill_ref: 'INV-VS-1042', added_by: 2 },
  { category_id: 1, project_id: 1, description: 'River Sand – 20 loads',             amount: 170000, date: '2025-05-03', payment_status: 'pending', bill_ref: 'RS-045',      added_by: 3 },
  { category_id: 2, project_id: 1, description: 'Labour wages – April 2025',         amount: 360000, date: '2025-05-01', payment_status: 'paid',    bill_ref: 'PAY-APR-25',  added_by: 1 },
  { category_id: 3, project_id: 1, description: 'Concrete pump rental – May week 1', amount: 45000,  date: '2025-05-07', payment_status: 'paid',    bill_ref: 'PMP-012',     added_by: 3 },
  { category_id: 3, project_id: 1, description: 'Tower crane monthly rent',          amount: 120000, date: '2025-05-01', payment_status: 'paid',    bill_ref: 'CRN-MAY25',   added_by: 2 },
];
const insertExp = db.prepare(`INSERT INTO expenses (category_id, project_id, description, amount, date, payment_status, bill_ref, added_by) VALUES (?,?,?,?,?,?,?,?)`);
expenses.forEach(e => insertExp.run(e.category_id, e.project_id, e.description, e.amount, e.date, e.payment_status, e.bill_ref, e.added_by));
console.log('✅ Budget & expenses created');

// ── Notifications ──────────────────────────────────────────────────────────
const notifs = [
  { user_id: 1, title: 'Low Stock Alert', message: 'Plywood (12mm) at Project Greenfield is below minimum stock level (22 sheets remaining, min: 30).', type: 'alert' },
  { user_id: 1, title: 'Budget Overrun',  message: 'Equipment Rental for Greenfield Residency has exceeded estimated budget by ₹60,000.', type: 'warning' },
  { user_id: 2, title: 'Task Due Soon',   message: '"Order next batch of TMT steel" is due in 2 days.', type: 'reminder' },
  { user_id: 2, title: 'Inspection Passed', message: 'PWD Inspection report submitted successfully. Approval received.', type: 'info' },
  { user_id: 1, title: 'Attendance Submitted', message: 'Today\'s attendance for Greenfield site logged — 48 workers present.', type: 'info' },
];
const insertNotif = db.prepare(`INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)`);
notifs.forEach(n => insertNotif.run(n.user_id, n.title, n.message, n.type));
console.log('✅ Notifications created');

console.log('\n🎉 Seed complete! Login credentials:');
console.log('   👑 Owner:      admin@prosite.in      / demo1234');
console.log('   🔧 Engineer:   engineer@prosite.in   / demo1234');
console.log('   👷 Supervisor: supervisor@prosite.in / demo1234\n');
