const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, '../prosite.db'));

db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;

  -- Users / Auth
  CREATE TABLE IF NOT EXISTS users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    email       TEXT UNIQUE NOT NULL,
    password    TEXT NOT NULL,
    role        TEXT NOT NULL DEFAULT 'supervisor',  -- owner | engineer | supervisor | worker
    phone       TEXT,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Projects
  CREATE TABLE IF NOT EXISTS projects (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    location      TEXT,
    description   TEXT,
    start_date    DATE,
    end_date      DATE,
    status        TEXT DEFAULT 'active',  -- active | completed | on_hold
    budget_total  REAL DEFAULT 0,
    progress      INTEGER DEFAULT 0,
    manager_id    INTEGER REFERENCES users(id),
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Daily Site Logs
  CREATE TABLE IF NOT EXISTS site_logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER REFERENCES projects(id),
    user_id     INTEGER REFERENCES users(id),
    date        DATE DEFAULT CURRENT_DATE,
    work_done   TEXT,
    issues      TEXT,
    weather     TEXT,
    manpower    INTEGER DEFAULT 0,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Log Photos
  CREATE TABLE IF NOT EXISTS log_photos (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    log_id    INTEGER REFERENCES site_logs(id) ON DELETE CASCADE,
    filename  TEXT NOT NULL,
    caption   TEXT,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Worker Attendance
  CREATE TABLE IF NOT EXISTS attendance (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER REFERENCES projects(id),
    worker_name TEXT NOT NULL,
    role        TEXT,
    date        DATE DEFAULT CURRENT_DATE,
    check_in    TIME,
    check_out   TIME,
    status      TEXT DEFAULT 'present',  -- present | absent | half_day
    notes       TEXT
  );

  -- Materials
  CREATE TABLE IF NOT EXISTS materials (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id    INTEGER REFERENCES projects(id),
    name          TEXT NOT NULL,
    unit          TEXT,
    qty_received  REAL DEFAULT 0,
    qty_used      REAL DEFAULT 0,
    qty_remaining REAL DEFAULT 0,
    min_stock     REAL DEFAULT 0,
    unit_cost     REAL DEFAULT 0,
    supplier      TEXT,
    last_updated  DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Material Transactions
  CREATE TABLE IF NOT EXISTS material_transactions (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    material_id  INTEGER REFERENCES materials(id),
    type         TEXT,  -- received | used | adjustment
    quantity     REAL,
    notes        TEXT,
    date         DATE DEFAULT CURRENT_DATE,
    recorded_by  INTEGER REFERENCES users(id)
  );

  -- Tasks
  CREATE TABLE IF NOT EXISTS tasks (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id   INTEGER REFERENCES projects(id),
    title        TEXT NOT NULL,
    description  TEXT,
    assigned_to  INTEGER REFERENCES users(id),
    priority     TEXT DEFAULT 'medium',  -- low | medium | high | urgent
    status       TEXT DEFAULT 'pending', -- pending | in_progress | completed | blocked
    due_date     DATE,
    completed_at DATETIME,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Budget Categories
  CREATE TABLE IF NOT EXISTS budget_categories (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id   INTEGER REFERENCES projects(id),
    name         TEXT NOT NULL,
    estimated    REAL DEFAULT 0,
    actual       REAL DEFAULT 0,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Budget Expenses
  CREATE TABLE IF NOT EXISTS expenses (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id  INTEGER REFERENCES budget_categories(id),
    project_id   INTEGER REFERENCES projects(id),
    description  TEXT,
    amount       REAL NOT NULL,
    date         DATE DEFAULT CURRENT_DATE,
    payment_status TEXT DEFAULT 'pending', -- pending | paid | overdue
    bill_ref     TEXT,
    added_by     INTEGER REFERENCES users(id),
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Notifications
  CREATE TABLE IF NOT EXISTS notifications (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER REFERENCES users(id),
    title       TEXT NOT NULL,
    message     TEXT,
    type        TEXT,  -- alert | reminder | info | warning
    read        INTEGER DEFAULT 0,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

module.exports = db;
