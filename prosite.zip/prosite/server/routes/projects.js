const router = require('express').Router();
const db = require('../db/schema');
const auth = require('../middleware/auth');

// Get all projects
router.get('/', auth, (req, res) => {
  const projects = db.prepare(`
    SELECT p.*, u.name as manager_name,
      (SELECT COUNT(*) FROM tasks WHERE project_id = p.id AND status != 'completed') as open_tasks,
      (SELECT COUNT(*) FROM tasks WHERE project_id = p.id AND status = 'completed') as completed_tasks,
      (SELECT SUM(actual) FROM budget_categories WHERE project_id = p.id) as spent
    FROM projects p LEFT JOIN users u ON p.manager_id = u.id
    ORDER BY p.created_at DESC
  `).all();
  res.json(projects);
});

// Get single project
router.get('/:id', auth, (req, res) => {
  const project = db.prepare(`
    SELECT p.*, u.name as manager_name
    FROM projects p LEFT JOIN users u ON p.manager_id = u.id
    WHERE p.id = ?
  `).get(req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  res.json(project);
});

// Create project
router.post('/', auth, (req, res) => {
  const { name, location, description, start_date, end_date, budget_total, manager_id } = req.body;
  const result = db.prepare(`
    INSERT INTO projects (name, location, description, start_date, end_date, budget_total, manager_id)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(name, location, description, start_date, end_date, budget_total || 0, manager_id || req.user.id);
  res.json({ id: result.lastInsertRowid, message: 'Project created' });
});

// Update project
router.put('/:id', auth, (req, res) => {
  const { name, location, description, start_date, end_date, budget_total, status, progress, manager_id } = req.body;
  db.prepare(`
    UPDATE projects SET name=?, location=?, description=?, start_date=?, end_date=?,
    budget_total=?, status=?, progress=?, manager_id=? WHERE id=?
  `).run(name, location, description, start_date, end_date, budget_total, status, progress, manager_id, req.params.id);
  res.json({ message: 'Project updated' });
});

// Delete project
router.delete('/:id', auth, (req, res) => {
  db.prepare('DELETE FROM projects WHERE id = ?').run(req.params.id);
  res.json({ message: 'Project deleted' });
});

// Dashboard summary (all projects stats)
router.get('/meta/dashboard', auth, (req, res) => {
  const stats = {
    total_projects: db.prepare("SELECT COUNT(*) as c FROM projects").get().c,
    active_projects: db.prepare("SELECT COUNT(*) as c FROM projects WHERE status='active'").get().c,
    completed_projects: db.prepare("SELECT COUNT(*) as c FROM projects WHERE status='completed'").get().c,
    open_tasks: db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status != 'completed'").get().c,
    overdue_tasks: db.prepare("SELECT COUNT(*) as c FROM tasks WHERE status != 'completed' AND due_date < date('now')").get().c,
    total_workers_today: db.prepare("SELECT COUNT(*) as c FROM attendance WHERE date = date('now') AND status = 'present'").get().c,
    low_stock_alerts: db.prepare("SELECT COUNT(*) as c FROM materials WHERE qty_remaining <= min_stock").get().c,
    total_budget: db.prepare("SELECT SUM(budget_total) as s FROM projects WHERE status='active'").get().s || 0,
    total_spent: db.prepare("SELECT SUM(actual) as s FROM budget_categories").get().s || 0,
  };
  const recent_logs = db.prepare(`
    SELECT sl.*, p.name as project_name, u.name as logged_by
    FROM site_logs sl JOIN projects p ON sl.project_id = p.id JOIN users u ON sl.user_id = u.id
    ORDER BY sl.created_at DESC LIMIT 5
  `).all();
  const urgent_tasks = db.prepare(`
    SELECT t.*, p.name as project_name, u.name as assigned_name
    FROM tasks t JOIN projects p ON t.project_id = p.id LEFT JOIN users u ON t.assigned_to = u.id
    WHERE t.status != 'completed' AND t.priority IN ('urgent','high')
    ORDER BY t.due_date ASC LIMIT 5
  `).all();
  res.json({ stats, recent_logs, urgent_tasks });
});

module.exports = router;
