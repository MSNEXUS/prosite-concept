const router = require('express').Router();
const db = require('../db/schema');
const auth = require('../middleware/auth');
const bcrypt = require('bcryptjs');

// Only owner can access admin
const ownerOnly = (req, res, next) => {
  if (req.user.role !== 'owner') return res.status(403).json({ error: 'Owner access required' });
  next();
};

router.get('/users', auth, ownerOnly, (req, res) => {
  const users = db.prepare('SELECT id, name, email, role, phone, created_at FROM users ORDER BY created_at DESC').all();
  res.json(users);
});

router.post('/users', auth, ownerOnly, (req, res) => {
  const { name, email, password, role, phone } = req.body;
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) return res.status(400).json({ error: 'Email already exists' });
  const hash = bcrypt.hashSync(password, 10);
  const result = db.prepare('INSERT INTO users (name, email, password, role, phone) VALUES (?,?,?,?,?)').run(name, email, hash, role, phone);
  res.json({ id: result.lastInsertRowid, message: 'User created' });
});

router.put('/users/:id', auth, ownerOnly, (req, res) => {
  const { name, role, phone } = req.body;
  db.prepare('UPDATE users SET name=?, role=?, phone=? WHERE id=?').run(name, role, phone, req.params.id);
  res.json({ message: 'User updated' });
});

router.put('/users/:id/reset-password', auth, ownerOnly, (req, res) => {
  const { password } = req.body;
  db.prepare('UPDATE users SET password=? WHERE id=?').run(bcrypt.hashSync(password, 10), req.params.id);
  res.json({ message: 'Password reset' });
});

router.delete('/users/:id', auth, ownerOnly, (req, res) => {
  if (Number(req.params.id) === req.user.id) return res.status(400).json({ error: 'Cannot delete yourself' });
  db.prepare('DELETE FROM users WHERE id = ?').run(req.params.id);
  res.json({ message: 'User deleted' });
});

router.get('/notifications', auth, (req, res) => {
  const notifs = db.prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').all(req.user.id);
  res.json(notifs);
});

router.put('/notifications/:id/read', auth, (req, res) => {
  db.prepare('UPDATE notifications SET read=1 WHERE id=?').run(req.params.id);
  res.json({ message: 'Marked read' });
});

router.put('/notifications/read-all', auth, (req, res) => {
  db.prepare('UPDATE notifications SET read=1 WHERE user_id=?').run(req.user.id);
  res.json({ message: 'All read' });
});

module.exports = router;
