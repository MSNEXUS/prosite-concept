require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({ origin: 'http://localhost:3000', credentials: true }));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Initialize DB
require('./db/schema');

// Routes
app.use('/api/auth',       require('./routes/auth'));
app.use('/api/projects',   require('./routes/projects'));
app.use('/api/logs',       require('./routes/logs'));
app.use('/api/attendance', require('./routes/attendance'));
app.use('/api/materials',  require('./routes/materials'));
app.use('/api/tasks',      require('./routes/tasks'));
app.use('/api/budget',     require('./routes/budget'));
app.use('/api/admin',      require('./routes/admin'));
app.use('/api/reports',    require('./routes/reports'));

app.get('/api/health', (req, res) => res.json({ status: 'ProSite API running ✅' }));

app.listen(PORT, () => {
  console.log(`\n🏗️  ProSite Server running at http://localhost:${PORT}`);
  console.log(`📦  Database: SQLite (prosite.db)`);
  console.log(`🔑  Auth: JWT\n`);
});
