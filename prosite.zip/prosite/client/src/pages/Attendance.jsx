import { useState, useEffect } from 'react';
import api from '../api';
import toast from 'react-hot-toast';

const ROLES = ['Mason', 'Carpenter', 'Electrician', 'Plumber', 'Steel Binder', 'Helper', 'Supervisor', 'Driver', 'Welder', 'Painter'];
const STATUS_STYLE = {
  present:  { bg: '#DCFCE7', color: '#15803D', label: 'Present' },
  absent:   { bg: '#FEE2E2', color: '#B91C1C', label: 'Absent' },
  half_day: { bg: '#FEF9C3', color: '#854D0E', label: 'Half Day' },
};

export default function Attendance() {
  const [projects, setProjects] = useState([]);
  const [selProject, setSelProject] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [records, setRecords] = useState([]);
  const [summary, setSummary] = useState({ present: 0, absent: 0, half_day: 0, total: 0 });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [newWorker, setNewWorker] = useState({ worker_name: '', role: 'Mason' });

  useEffect(() => { api.get('/projects').then(r => { setProjects(r.data); if (r.data.length) setSelProject(r.data[0].id); }); }, []);

  useEffect(() => {
    if (!selProject) return;
    setLoading(true);
    Promise.all([
      api.get(`/attendance/project/${selProject}?date=${date}`),
      api.get(`/attendance/project/${selProject}/summary?date=${date}`),
    ]).then(([rec, sum]) => { setRecords(rec.data); setSummary(sum.data); }).finally(() => setLoading(false));
  }, [selProject, date]);

  const updateStatus = (idx, status) => {
    setRecords(prev => prev.map((r, i) => i === idx ? { ...r, status } : r));
  };
  const updateTime = (idx, field, val) => {
    setRecords(prev => prev.map((r, i) => i === idx ? { ...r, [field]: val } : r));
  };

  const addWorker = () => {
    if (!newWorker.worker_name.trim()) return;
    setRecords(prev => [...prev, { ...newWorker, status: 'present', check_in: '08:00', check_out: '17:30', notes: '' }]);
    setNewWorker({ worker_name: '', role: 'Mason' });
  };

  const saveAll = async () => {
    setSaving(true);
    try {
      await api.post('/attendance/bulk', { project_id: selProject, date, records });
      toast.success('Attendance saved!');
      const sum = await api.get(`/attendance/project/${selProject}/summary?date=${date}`);
      setSummary(sum.data);
    } catch { toast.error('Failed to save'); } finally { setSaving(false); }
  };

  const removeWorker = (idx) => setRecords(prev => prev.filter((_, i) => i !== idx));

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <div className="page-title">Worker Attendance</div>
          <div className="page-subtitle">Daily check-in/check-out tracking</div>
        </div>
        <button className="btn btn-primary" onClick={saveAll} disabled={saving}>{saving ? 'Saving…' : '💾 Save Attendance'}</button>
      </div>

      {/* Controls */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 24, flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--text2)' }}>Project:</label>
          <select className="form-control" style={{ width: 260 }} value={selProject} onChange={e => setSelProject(e.target.value)}>
            {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--text2)' }}>Date:</label>
          <input type="date" className="form-control" style={{ width: 160 }} value={date} onChange={e => setDate(e.target.value)} />
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-4" style={{ marginBottom: 24 }}>
        {[['👥', 'Total', summary.total, '#E4E6EF', 'var(--text)'],
          ['✅', 'Present', summary.present, '#DCFCE7', 'var(--success)'],
          ['❌', 'Absent', summary.absent, '#FEE2E2', 'var(--danger)'],
          ['🕐', 'Half Day', summary.half_day, '#FEF9C3', 'var(--warning)']].map(([icon, label, val, bg, color]) => (
          <div key={label} style={{ background: bg, borderRadius: 'var(--radius)', padding: '18px 20px', display: 'flex', alignItems: 'center', gap: 14 }}>
            <span style={{ fontSize: 26 }}>{icon}</span>
            <div><div style={{ fontSize: 26, fontWeight: 800, color, lineHeight: 1 }}>{val}</div><div style={{ fontSize: 12, color: 'var(--text2)' }}>{label}</div></div>
          </div>
        ))}
      </div>

      {/* Add worker */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div style={{ fontWeight: 600, marginBottom: 12 }}>➕ Add Worker</div>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <input className="form-control" style={{ flex: 1, minWidth: 200 }} placeholder="Worker name" value={newWorker.worker_name} onChange={e => setNewWorker({ ...newWorker, worker_name: e.target.value })} onKeyDown={e => e.key === 'Enter' && addWorker()} />
          <select className="form-control" style={{ width: 160 }} value={newWorker.role} onChange={e => setNewWorker({ ...newWorker, role: e.target.value })}>
            {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
          <button className="btn btn-primary" onClick={addWorker}>Add</button>
        </div>
      </div>

      {/* Attendance table */}
      {loading ? <div className="spinner"><div className="spin" /></div> : (
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          {records.length === 0 ? (
            <div className="empty-state" style={{ padding: 48 }}><div className="icon">👷</div><h3>No workers added yet</h3><p>Add workers above to start marking attendance</p></div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Worker</th><th>Role</th><th>Status</th><th>Check In</th><th>Check Out</th><th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {records.map((r, idx) => (
                    <tr key={idx}>
                      <td style={{ fontWeight: 600 }}>{r.worker_name}</td>
                      <td><span className="badge badge-gray">{r.role}</span></td>
                      <td>
                        <div style={{ display: 'flex', gap: 6 }}>
                          {Object.entries(STATUS_STYLE).map(([s, style]) => (
                            <button key={s} onClick={() => updateStatus(idx, s)} className="btn btn-sm"
                              style={{ background: r.status === s ? style.bg : 'var(--surface2)', color: r.status === s ? style.color : 'var(--text2)', border: r.status === s ? `1.5px solid ${style.color}` : '1.5px solid transparent', fontWeight: r.status === s ? 700 : 400, fontSize: 12 }}>
                              {style.label}
                            </button>
                          ))}
                        </div>
                      </td>
                      <td><input type="time" style={{ border: '1.5px solid var(--border)', borderRadius: 6, padding: '4px 8px', fontSize: 13 }} value={r.check_in || ''} onChange={e => updateTime(idx, 'check_in', e.target.value)} disabled={r.status === 'absent'} /></td>
                      <td><input type="time" style={{ border: '1.5px solid var(--border)', borderRadius: 6, padding: '4px 8px', fontSize: 13 }} value={r.check_out || ''} onChange={e => updateTime(idx, 'check_out', e.target.value)} disabled={r.status === 'absent'} /></td>
                      <td><button className="btn btn-danger btn-sm btn-icon" onClick={() => removeWorker(idx)}>🗑️</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
