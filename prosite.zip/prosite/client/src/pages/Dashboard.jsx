import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import api from '../api';

const COLORS = ['#FF6B2B', '#3B82F6', '#22C55E', '#F59E0B', '#8B5CF6'];

function StatCard({ icon, label, value, bg, sub }) {
  return (
    <div className="stat-card">
      <div className="stat-icon" style={{ background: bg }}>{icon}</div>
      <div>
        <div className="stat-value">{value}</div>
        <div className="stat-label">{label}</div>
        {sub && <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2 }}>{sub}</div>}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([
      api.get('/projects/meta/dashboard'),
      api.get('/projects'),
    ]).then(([d, p]) => {
      setData(d.data);
      setProjects(p.data);
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="spinner"><div className="spin" /></div>;
  if (!data) return null;

  const { stats, recent_logs, urgent_tasks } = data;
  const budgetData = projects.slice(0, 5).map(p => ({
    name: p.name.split(' ').slice(0, 2).join(' '),
    Budget: Math.round((p.budget_total || 0) / 100000),
    Spent: Math.round((p.spent || 0) / 100000),
  }));
  const taskStatusData = [
    { name: 'In Progress', value: projects.reduce((a, p) => a + (p.open_tasks || 0), 0) },
    { name: 'Completed', value: projects.reduce((a, p) => a + (p.completed_tasks || 0), 0) },
  ].filter(d => d.value > 0);

  const priorityColor = { urgent: 'var(--danger)', high: 'var(--warning)', medium: 'var(--info)', low: 'var(--success)' };

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <div className="page-title">Good {new Date().getHours() < 12 ? 'Morning' : 'Afternoon'} 👋</div>
          <div className="page-subtitle">Here's what's happening across your sites today</div>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-4" style={{ marginBottom: 28 }}>
        <StatCard icon="🏗️" label="Active Projects"  value={stats.active_projects}   bg="#FFF0EA" sub={`${stats.total_projects} total`} />
        <StatCard icon="✅" label="Open Tasks"       value={stats.open_tasks}        bg="#DBEAFE" sub={stats.overdue_tasks > 0 ? `⚠️ ${stats.overdue_tasks} overdue` : 'All on track'} />
        <StatCard icon="👷" label="Workers Today"    value={stats.total_workers_today} bg="#DCFCE7" sub="Present on site" />
        <StatCard icon="🚨" label="Low Stock Alerts" value={stats.low_stock_alerts}   bg="#FEE2E2" sub="Materials below min" />
      </div>

      {/* Budget overview */}
      <div className="grid grid-2" style={{ marginBottom: 28 }}>
        <div style={{ background: 'var(--surface)', borderRadius: 'var(--radius)', padding: 24, boxShadow: 'var(--shadow)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontWeight: 600, fontSize: 15 }}>Total Budget vs Spent</span>
            <span style={{ fontSize: 12, color: 'var(--text2)' }}>₹ in Lakhs</span>
          </div>
          <div style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <span style={{ fontSize: 13, color: 'var(--text2)' }}>Total Budget</span>
              <strong>₹{(stats.total_budget / 100000).toFixed(1)}L</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <span style={{ fontSize: 13, color: 'var(--text2)' }}>Amount Spent</span>
              <strong style={{ color: 'var(--brand)' }}>₹{(stats.total_spent / 100000).toFixed(1)}L</strong>
            </div>
            <div className="progress-bar" style={{ marginTop: 12 }}>
              <div className="progress-fill" style={{ width: `${Math.min((stats.total_spent / stats.total_budget) * 100, 100)}%`, background: 'var(--brand)' }} />
            </div>
            <div style={{ fontSize: 11, color: 'var(--text2)', marginTop: 6 }}>
              {((stats.total_spent / stats.total_budget) * 100).toFixed(1)}% of total budget used
            </div>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={budgetData} barSize={16}>
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip formatter={(v) => `₹${v}L`} />
              <Bar dataKey="Budget" fill="#E4E6EF" radius={4} />
              <Bar dataKey="Spent" fill="#FF6B2B" radius={4} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div style={{ background: 'var(--surface)', borderRadius: 'var(--radius)', padding: 24, boxShadow: 'var(--shadow)' }}>
          <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 20 }}>Task Overview</div>
          {taskStatusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={taskStatusData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                  {taskStatusData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : <div className="empty-state"><div>No task data yet</div></div>}

          {/* Active projects progress */}
          <div style={{ marginTop: 16 }}>
            {projects.filter(p => p.status === 'active').slice(0, 3).map(p => (
              <div key={p.id} style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, fontSize: 13 }}>
                  <span style={{ color: 'var(--text)' }}>{p.name.length > 28 ? p.name.slice(0, 28) + '…' : p.name}</span>
                  <span style={{ fontWeight: 600, color: 'var(--brand)' }}>{p.progress}%</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: `${p.progress}%`, background: p.progress >= 80 ? 'var(--success)' : p.progress >= 40 ? 'var(--brand)' : 'var(--info)' }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid grid-2">
        {/* Recent logs */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">📋 Recent Site Logs</span>
          </div>
          {recent_logs.length === 0 ? (
            <div className="empty-state"><div>No logs yet</div></div>
          ) : recent_logs.map(log => (
            <div key={log.id} style={{ padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontWeight: 600, fontSize: 13 }}>{log.project_name}</span>
                <span style={{ fontSize: 12, color: 'var(--text2)' }}>{log.date}</span>
              </div>
              <div style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 1.5 }}>{log.work_done?.slice(0, 90)}{log.work_done?.length > 90 ? '…' : ''}</div>
              <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 4 }}>by {log.logged_by} · {log.manpower} workers</div>
            </div>
          ))}
        </div>

        {/* Urgent tasks */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">🔥 Urgent & High Priority Tasks</span>
            <button className="btn btn-sm btn-secondary" onClick={() => navigate('/tasks')}>View All</button>
          </div>
          {urgent_tasks.length === 0 ? (
            <div className="empty-state"><div>No urgent tasks 🎉</div></div>
          ) : urgent_tasks.map(task => (
            <div key={task.id} style={{ padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{task.title}</div>
                  <div style={{ fontSize: 12, color: 'var(--text2)', marginTop: 2 }}>{task.project_name}</div>
                  {task.assigned_name && <div style={{ fontSize: 12, color: 'var(--text3)' }}>→ {task.assigned_name}</div>}
                </div>
                <div style={{ textAlign: 'right', flexShrink: 0 }}>
                  <span className="badge" style={{ background: priorityColor[task.priority] + '22', color: priorityColor[task.priority], fontSize: 11 }}>{task.priority}</span>
                  {task.due_date && <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 4 }}>Due {task.due_date}</div>}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
