import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      toast.success('Welcome back!');
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const demoLogin = (role) => {
    const creds = {
      owner:      { email: 'admin@prosite.in',      password: 'demo1234' },
      engineer:   { email: 'engineer@prosite.in',   password: 'demo1234' },
      supervisor: { email: 'supervisor@prosite.in', password: 'demo1234' },
    };
    setEmail(creds[role].email);
    setPassword(creds[role].password);
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', background: 'var(--bg)' }}>
      {/* Left panel */}
      <div style={{ flex: 1, background: 'var(--text)', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '60px', color: '#fff' }}>
        <div style={{ maxWidth: 420 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 48 }}>
            <div style={{ width: 44, height: 44, background: 'var(--brand)', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>🏗️</div>
            <span style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: 24 }}>ProSite</span>
          </div>
          <h1 style={{ fontSize: 38, fontFamily: 'Syne', fontWeight: 800, lineHeight: 1.2, marginBottom: 16 }}>
            Construction<br />Management<br /><span style={{ color: 'var(--brand)' }}>Made Simple.</span>
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.55)', fontSize: 15, lineHeight: 1.8 }}>
            Track your sites, workers, materials, and budget — all in one place. Built for Indian construction companies.
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 40 }}>
            {[['📋', 'Daily Site Logs'], ['👷', 'Attendance Tracking'], ['📦', 'Material Alerts'], ['💰', 'Budget Control']].map(([icon, label]) => (
              <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 10, color: 'rgba(255,255,255,0.7)', fontSize: 14 }}>
                <span style={{ fontSize: 20 }}>{icon}</span> {label}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel */}
      <div style={{ width: 480, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px' }}>
        <div style={{ width: '100%', maxWidth: 380 }}>
          <h2 style={{ fontSize: 26, fontWeight: 700, marginBottom: 6 }}>Sign in</h2>
          <p style={{ color: 'var(--text2)', marginBottom: 32 }}>Enter your credentials to continue</p>

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <input className="form-control" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@prosite.in" required />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input className="form-control" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required />
            </div>
            <button type="submit" className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '13px', fontSize: 15, marginTop: 8 }} disabled={loading}>
              {loading ? 'Signing in...' : 'Sign In →'}
            </button>
          </form>

          {/* Demo buttons */}
          <div style={{ marginTop: 32, padding: 20, background: 'var(--bg)', borderRadius: 'var(--radius)', border: '1px solid var(--border)' }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text2)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 12 }}>🎯 Demo Access</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[['owner', '👑 Owner (Full Access)'], ['engineer', '🔧 Site Engineer'], ['supervisor', '👷 Supervisor']].map(([role, label]) => (
                <button key={role} onClick={() => demoLogin(role)} className="btn btn-secondary" style={{ justifyContent: 'flex-start', fontSize: 13 }}>
                  {label}
                </button>
              ))}
            </div>
            <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 10 }}>Click a role to fill credentials, then Sign In</div>
          </div>
        </div>
      </div>
    </div>
  );
}
