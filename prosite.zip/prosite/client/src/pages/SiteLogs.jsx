import { useState, useEffect, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import api from '../api';
import toast from 'react-hot-toast';

function PhotoUploader({ logId, onDone }) {
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const onDrop = useCallback(accepted => setFiles(prev => [...prev, ...accepted]), []);
  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop, accept: { 'image/*': [] }, maxFiles: 10 });

  const upload = async () => {
    if (!files.length) return;
    setUploading(true);
    const fd = new FormData();
    files.forEach(f => fd.append('photos', f));
    try {
      await api.post(`/logs/${logId}/photos`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success(`${files.length} photo(s) uploaded`);
      setFiles([]);
      onDone();
    } catch { toast.error('Upload failed'); } finally { setUploading(false); }
  };

  return (
    <div>
      <div {...getRootProps()} style={{ border: '2px dashed var(--border)', borderRadius: 10, padding: 24, textAlign: 'center', cursor: 'pointer', background: isDragActive ? 'var(--brand-light)' : 'var(--bg)', transition: 'all 0.15s', marginBottom: 12 }}>
        <input {...getInputProps()} />
        <div style={{ fontSize: 32 }}>📷</div>
        <div style={{ marginTop: 8, fontSize: 14, color: 'var(--text2)' }}>{isDragActive ? 'Drop photos here' : 'Drag & drop photos or click to browse'}</div>
        <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 4 }}>JPG, PNG, WebP up to 10MB each</div>
      </div>
      {files.length > 0 && (
        <div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
            {files.map((f, i) => (
              <div key={i} style={{ position: 'relative' }}>
                <img src={URL.createObjectURL(f)} alt="" style={{ width: 80, height: 80, objectFit: 'cover', borderRadius: 8, border: '2px solid var(--border)' }} />
                <button onClick={() => setFiles(files.filter((_, j) => j !== i))} style={{ position: 'absolute', top: -6, right: -6, background: 'var(--danger)', color: '#fff', border: 'none', borderRadius: '50%', width: 20, height: 20, cursor: 'pointer', fontSize: 10 }}>✕</button>
              </div>
            ))}
          </div>
          <button className="btn btn-primary btn-sm" onClick={upload} disabled={uploading}>{uploading ? 'Uploading...' : `Upload ${files.length} Photo(s)`}</button>
        </div>
      )}
    </div>
  );
}

export default function SiteLogs() {
  const [projects, setProjects] = useState([]);
  const [logs, setLogs] = useState([]);
  const [selProject, setSelProject] = useState('');
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [expandedLog, setExpandedLog] = useState(null);
  const [logDetail, setLogDetail] = useState(null);
  const [form, setForm] = useState({ project_id: '', date: new Date().toISOString().split('T')[0], work_done: '', issues: '', weather: '', manpower: '' });

  useEffect(() => { api.get('/projects').then(r => { setProjects(r.data); if (r.data.length) setSelProject(r.data[0].id); }); }, []);

  useEffect(() => {
    if (!selProject) return;
    setLoading(true);
    api.get(`/logs/project/${selProject}`).then(r => setLogs(r.data)).finally(() => setLoading(false));
  }, [selProject]);

  const openLog = async (id) => {
    if (expandedLog === id) { setExpandedLog(null); setLogDetail(null); return; }
    setExpandedLog(id);
    const r = await api.get(`/logs/${id}`);
    setLogDetail(r.data);
  };

  const save = async (e) => {
    e.preventDefault();
    try {
      await api.post('/logs', { ...form, project_id: selProject });
      toast.success('Site log created!');
      setShowModal(false);
      setForm({ project_id: '', date: new Date().toISOString().split('T')[0], work_done: '', issues: '', weather: '', manpower: '' });
      api.get(`/logs/project/${selProject}`).then(r => setLogs(r.data));
    } catch { toast.error('Failed to save log'); }
  };

  const deleteLog = async (id) => {
    if (!window.confirm('Delete this log?')) return;
    await api.delete(`/logs/${id}`);
    setLogs(logs.filter(l => l.id !== id));
    toast.success('Log deleted');
  };

  const weatherOptions = ['Sunny', 'Cloudy', 'Partly Cloudy', 'Rainy', 'Humid', 'Windy'];

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <div className="page-title">Daily Site Logs</div>
          <div className="page-subtitle">Photo-backed daily records replacing WhatsApp & paper diaries</div>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ Add Log</button>
      </div>

      {/* Project selector */}
      <div style={{ marginBottom: 24, display: 'flex', gap: 12, alignItems: 'center' }}>
        <label style={{ fontWeight: 500, color: 'var(--text2)', fontSize: 13 }}>Project:</label>
        <select className="form-control" style={{ width: 300 }} value={selProject} onChange={e => setSelProject(e.target.value)}>
          {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </div>

      {loading ? <div className="spinner"><div className="spin" /></div> : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {logs.length === 0 && <div className="empty-state"><div className="icon">📋</div><h3>No logs yet</h3><p>Add your first site log for today</p></div>}
          {logs.map(log => (
            <div key={log.id} className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer' }} onClick={() => openLog(log.id)}>
                <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
                  <div style={{ background: 'var(--brand-light)', borderRadius: 10, padding: '8px 14px', textAlign: 'center' }}>
                    <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--brand)', lineHeight: 1 }}>{new Date(log.date).getDate()}</div>
                    <div style={{ fontSize: 11, color: 'var(--brand)', textTransform: 'uppercase' }}>{new Date(log.date).toLocaleString('en', { month: 'short' })}</div>
                  </div>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{log.work_done?.slice(0, 80)}{log.work_done?.length > 80 ? '…' : ''}</div>
                    <div style={{ fontSize: 12, color: 'var(--text2)', marginTop: 3 }}>
                      by {log.logged_by} · {log.manpower} workers · {log.weather} · {log.photo_count} 📷
                    </div>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  {log.issues && log.issues !== 'None' && log.issues !== 'none' && <span className="badge badge-warning">⚠️ Issues</span>}
                  <span style={{ color: 'var(--text3)', fontSize: 18 }}>{expandedLog === log.id ? '▲' : '▼'}</span>
                </div>
              </div>

              {expandedLog === log.id && logDetail && logDetail.id === log.id && (
                <div style={{ padding: '0 20px 20px', borderTop: '1px solid var(--border)' }}>
                  <div className="grid grid-2" style={{ marginTop: 16, gap: 16 }}>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 8, color: 'var(--text2)' }}>WORK DONE</div>
                      <p style={{ fontSize: 14, lineHeight: 1.7 }}>{logDetail.work_done}</p>
                      {logDetail.issues && (
                        <div style={{ marginTop: 16, padding: 12, background: '#FEF9C3', borderRadius: 8, borderLeft: '3px solid var(--warning)' }}>
                          <div style={{ fontWeight: 600, fontSize: 12, color: 'var(--warning)', marginBottom: 4 }}>⚠️ ISSUES REPORTED</div>
                          <p style={{ fontSize: 13 }}>{logDetail.issues}</p>
                        </div>
                      )}
                    </div>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 8, color: 'var(--text2)' }}>PHOTOS ({logDetail.photos?.length || 0})</div>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
                        {logDetail.photos?.map(p => (
                          <img key={p.id} src={`http://localhost:5000/uploads/${p.filename}`} alt={p.caption || 'Site photo'} style={{ width: 90, height: 90, objectFit: 'cover', borderRadius: 8, border: '2px solid var(--border)', cursor: 'pointer' }} onClick={() => window.open(`http://localhost:5000/uploads/${p.filename}`, '_blank')} />
                        ))}
                      </div>
                      <div style={{ fontWeight: 600, fontSize: 12, color: 'var(--text2)', marginBottom: 8 }}>UPLOAD MORE PHOTOS</div>
                      <PhotoUploader logId={log.id} onDone={() => openLog(log.id)} />
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
                    <button className="btn btn-danger btn-sm" onClick={() => deleteLog(log.id)}>🗑️ Delete Log</button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal">
            <div className="modal-header"><span className="modal-title">New Site Log</span><button className="btn btn-sm btn-secondary" onClick={() => setShowModal(false)}>✕</button></div>
            <form onSubmit={save}>
              <div className="form-group">
                <label className="form-label">Project</label>
                <select className="form-control" value={selProject} onChange={e => setSelProject(e.target.value)}>
                  {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div className="grid grid-2">
                <div className="form-group"><label className="form-label">Date</label><input type="date" className="form-control" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} /></div>
                <div className="form-group"><label className="form-label">Manpower (workers)</label><input type="number" className="form-control" value={form.manpower} onChange={e => setForm({ ...form, manpower: e.target.value })} placeholder="e.g. 42" /></div>
              </div>
              <div className="form-group">
                <label className="form-label">Weather</label>
                <select className="form-control" value={form.weather} onChange={e => setForm({ ...form, weather: e.target.value })}>
                  <option value="">Select weather</option>
                  {weatherOptions.map(w => <option key={w} value={w}>{w}</option>)}
                </select>
              </div>
              <div className="form-group"><label className="form-label">Work Done Today *</label><textarea className="form-control" rows={4} value={form.work_done} onChange={e => setForm({ ...form, work_done: e.target.value })} placeholder="Describe work completed today..." required /></div>
              <div className="form-group"><label className="form-label">Issues / Problems</label><textarea className="form-control" rows={2} value={form.issues} onChange={e => setForm({ ...form, issues: e.target.value })} placeholder="Any issues, delays, or problems faced..." /></div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Save Log</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
