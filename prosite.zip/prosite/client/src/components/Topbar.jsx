import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import api from '../api';

const PAGE_TITLES = {
  '/': 'Dashboard', '/projects': 'Projects', '/logs': 'Site Logs',
  '/attendance': 'Attendance', '/materials': 'Materials',
  '/tasks': 'Tasks', '/budget': 'Budget', '/admin': 'Admin Panel',
};

export default function Topbar() {
  const location = useLocation();
  const [notifs, setNotifs] = useState([]);
  const [showNotifs, setShowNotifs] = useState(false);

  useEffect(() => {
    api.get('/admin/notifications').then(r => setNotifs(r.data)).catch(() => {});
  }, []);

  const unread = notifs.filter(n => !n.read).length;
  const title = PAGE_TITLES[location.pathname] || 'ProSite';

  const markRead = async (id) => {
    await api.put(`/admin/notifications/${id}/read`);
    setNotifs(prev => prev.map(n => n.id === id ? { ...n, read: 1 } : n));
  };

  const markAllRead = async () => {
    await api.put('/admin/notifications/read-all');
    setNotifs(prev => prev.map(n => ({ ...n, read: 1 })));
    setShowNotifs(false);
  };

  const typeColor = { alert: 'var(--danger)', warning: 'var(--warning)', info: 'var(--info)', reminder: 'var(--brand)' };

  return (
    <header style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border)', padding: '0 32px', height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 50 }}>
      <h2 style={{ fontSize: 20, fontWeight: 700 }}>{title}</h2>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ fontSize: 13, color: 'var(--text2)' }}>
          {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
        </div>
        {/* Notification Bell */}
        <div style={{ position: 'relative' }}>
          <button onClick={() => setShowNotifs(!showNotifs)} className="btn btn-secondary btn-icon" style={{ fontSize: 18, position: 'relative' }}>
            🔔
            {unread > 0 && (
              <span style={{ position: 'absolute', top: -4, right: -4, background: 'var(--danger)', color: '#fff', borderRadius: '50%', width: 18, height: 18, fontSize: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700 }}>{unread}</span>
            )}
          </button>
          {showNotifs && (
            <div style={{ position: 'absolute', right: 0, top: '110%', width: 360, background: 'var(--surface)', borderRadius: 'var(--radius)', boxShadow: 'var(--shadow-md)', border: '1px solid var(--border)', zIndex: 200 }}>
              <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span style={{ fontWeight: 600 }}>Notifications</span>
                {unread > 0 && <button onClick={markAllRead} className="btn btn-sm btn-secondary">Mark all read</button>}
              </div>
              <div style={{ maxHeight: 400, overflowY: 'auto' }}>
                {notifs.length === 0 ? (
                  <div style={{ padding: 24, textAlign: 'center', color: 'var(--text2)' }}>No notifications</div>
                ) : notifs.slice(0, 15).map(n => (
                  <div key={n.id} onClick={() => markRead(n.id)} style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', background: n.read ? 'transparent' : 'var(--brand-light)', cursor: 'pointer', transition: 'background 0.15s' }}>
                    <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                      <span style={{ fontSize: 16, marginTop: 1 }}>{n.type === 'alert' ? '🚨' : n.type === 'warning' ? '⚠️' : n.type === 'reminder' ? '⏰' : 'ℹ️'}</span>
                      <div>
                        <div style={{ fontWeight: 600, fontSize: 13, color: typeColor[n.type] || 'var(--text)' }}>{n.title}</div>
                        <div style={{ fontSize: 12, color: 'var(--text2)', marginTop: 2 }}>{n.message}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
