import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const NAV = [
  { to: '/',           icon: '📊', label: 'Dashboard'   },
  { to: '/projects',   icon: '🏗️', label: 'Projects'    },
  { to: '/logs',       icon: '📋', label: 'Site Logs'   },
  { to: '/attendance', icon: '👷', label: 'Attendance'  },
  { to: '/materials',  icon: '📦', label: 'Materials'   },
  { to: '/tasks',      icon: '✅', label: 'Tasks'       },
  { to: '/budget',     icon: '💰', label: 'Budget'      },
];

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    toast.success('Logged out');
    navigate('/login');
  };

  return (
    <aside style={{
      width: 'var(--sidebar-w)', position: 'fixed', top: 0, left: 0, height: '100vh',
      background: 'var(--text)', display: 'flex', flexDirection: 'column',
      zIndex: 100, overflowY: 'auto'
    }}>
      {/* Logo */}
      <div style={{ padding: '24px 20px 20px', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 36, height: 36, background: 'var(--brand)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>🏗️</div>
          <div>
            <div style={{ color: '#fff', fontFamily: 'Syne', fontWeight: 800, fontSize: 18, letterSpacing: '-0.5px' }}>ProSite</div>
            <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11 }}>Site Management</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ padding: '16px 12px', flex: 1 }}>
        {NAV.map(n => (
          <NavLink key={n.to} to={n.to} end={n.to === '/'}
            style={({ isActive }) => ({
              display: 'flex', alignItems: 'center', gap: 12, padding: '11px 12px',
              borderRadius: 10, marginBottom: 4, fontSize: 14, fontWeight: 500,
              color: isActive ? '#fff' : 'rgba(255,255,255,0.55)',
              background: isActive ? 'var(--brand)' : 'transparent',
              transition: 'all 0.15s'
            })}
          >
            <span style={{ fontSize: 18 }}>{n.icon}</span>
            {n.label}
          </NavLink>
        ))}

        {user?.role === 'owner' && (
          <NavLink to="/admin"
            style={({ isActive }) => ({
              display: 'flex', alignItems: 'center', gap: 12, padding: '11px 12px',
              borderRadius: 10, marginBottom: 4, fontSize: 14, fontWeight: 500,
              color: isActive ? '#fff' : 'rgba(255,255,255,0.55)',
              background: isActive ? 'var(--brand)' : 'transparent',
              transition: 'all 0.15s'
            })}
          >
            <span style={{ fontSize: 18 }}>⚙️</span> Admin Panel
          </NavLink>
        )}
      </nav>

      {/* User */}
      <div style={{ padding: '16px 12px', borderTop: '1px solid rgba(255,255,255,0.08)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.06)' }}>
          <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'var(--brand)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 14, flexShrink: 0 }}>
            {user?.name?.charAt(0)}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ color: '#fff', fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{user?.name}</div>
            <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11, textTransform: 'capitalize' }}>{user?.role}</div>
          </div>
          <button onClick={handleLogout} title="Logout" style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.4)', fontSize: 16, padding: 4 }}>↩</button>
        </div>
      </div>
    </aside>
  );
}
