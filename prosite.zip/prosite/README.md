# 🏗️ ProSite – Construction Site Management Platform

A full-stack localhost app: React frontend + Node.js backend + SQLite database.

---

## ⚙️ WHAT YOU NEED TO INSTALL (One-Time Setup)

### 1. Node.js (THE most important one)
- Download: https://nodejs.org → click **"LTS"** (the green button)
- Install it like a normal Windows program — keep clicking Next
- **Install location:** Let it default to `C:\Program Files\nodejs\` — do NOT change this
- ✅ This also installs `npm` (Node Package Manager) automatically

### 2. Git (needed to manage project files)
- Download: https://git-scm.com/download/win
- Install with all default settings — just keep clicking Next
- **Install location:** Default is `C:\Program Files\Git\` — leave it as is

### That's it. You do NOT need Python, Java, or anything else.

---

## ✅ HOW TO VERIFY INSTALLS WORKED

Open Cursor → open the Terminal (View → Terminal or press Ctrl + `)

Type these one at a time and press Enter:
```
node --version
```
You should see something like: `v20.11.0`

```
npm --version
```
You should see something like: `10.2.4`

If you see a version number = ✅ installed correctly.
If you see "not recognized" = Node.js didn't install properly, reinstall it.

---

## 🚀 HOW TO RUN PROSITE

### Step 1 – Open the project in Cursor
- Open Cursor
- File → Open Folder → select the `prosite` folder

### Step 2 – Open Terminal in Cursor
- Press `Ctrl + `` ` (backtick key, top-left of keyboard)
- A terminal panel opens at the bottom

### Step 3 – Install all dependencies (only needed ONCE)
```bash
npm install
cd client && npm install && cd ..
cd server && npm install && cd ..
```

### Step 4 – Seed the database with demo data (only needed ONCE)
```bash
cd server
node db/seed.js
cd ..
```
You'll see: 🎉 Seed complete! with login credentials printed.

### Step 5 – Start the app
Open TWO terminals in Cursor (click the + icon in the terminal panel)

**Terminal 1 – Start the backend:**
```bash
cd server
node index.js
```
You'll see: 🏗️ ProSite Server running at http://localhost:5000

**Terminal 2 – Start the frontend:**
```bash
cd client
npm start
```
This will automatically open http://localhost:3000 in your browser.

---

## 🔑 DEMO LOGIN CREDENTIALS

| Role | Email | Password |
|------|-------|----------|
| 👑 Owner (full access) | admin@prosite.in | demo1234 |
| 🔧 Site Engineer | engineer@prosite.in | demo1234 |
| 👷 Supervisor | supervisor@prosite.in | demo1234 |

---

## 📁 WHERE FILES ARE STORED

| What | Where |
|------|-------|
| Database | `server/prosite.db` (auto-created) |
| Uploaded photos | `server/uploads/` |
| Frontend build | `client/src/` |

---

## 🛠️ TROUBLESHOOTING

**"npm is not recognized"**
→ Node.js didn't install correctly. Reinstall from nodejs.org and restart Cursor.

**Port 5000 already in use**
→ Open Task Manager → find any Node.js process → End Task → try again.

**Port 3000 already in use**
→ The terminal will ask "Would you like to run on 3001?" → press Y + Enter.

**Photos not showing**
→ Make sure the backend (Terminal 1) is running. Photos are served from localhost:5000.

**"Cannot find module 'better-sqlite3'"**
→ You skipped Step 3. Run `cd server && npm install` in the terminal.

---

## 🗂️ PROJECT STRUCTURE

```
prosite/
├── client/                  ← React app (frontend)
│   ├── public/index.html
│   └── src/
│       ├── App.jsx          ← Routes
│       ├── api.js           ← Axios config
│       ├── index.css        ← Global styles
│       ├── context/
│       │   └── AuthContext.jsx
│       ├── components/
│       │   ├── Sidebar.jsx
│       │   └── Topbar.jsx
│       └── pages/
│           ├── Login.jsx
│           ├── Dashboard.jsx
│           ├── Projects.jsx
│           ├── ProjectDetail.jsx
│           ├── SiteLogs.jsx
│           ├── Attendance.jsx
│           ├── Materials.jsx
│           ├── Tasks.jsx
│           ├── Budget.jsx
│           └── Admin.jsx
│
├── server/                  ← Node.js + Express (backend)
│   ├── index.js             ← Main server file
│   ├── .env                 ← Config (port, JWT secret)
│   ├── prosite.db           ← SQLite database (auto-created)
│   ├── uploads/             ← Site photos stored here
│   ├── middleware/
│   │   └── auth.js          ← JWT verification
│   ├── db/
│   │   ├── schema.js        ← All database tables
│   │   └── seed.js          ← Demo data for pitching
│   └── routes/
│       ├── auth.js
│       ├── projects.js
│       ├── logs.js
│       ├── attendance.js
│       ├── materials.js
│       ├── tasks.js
│       ├── budget.js
│       ├── admin.js
│       └── reports.js
│
└── package.json             ← Root scripts
```

---

## 🔮 PHASE 2 READY (when you have resources)

The codebase is architected so these can be added without rewriting anything:

| Feature | What to swap/add |
|---------|-----------------|
| AWS S3 photo storage | Replace `multer` local storage with `multer-s3` |
| PostgreSQL (production DB) | Replace `better-sqlite3` with `pg` driver |
| WhatsApp API | Add `whatsapp-web.js` or Twilio route |
| PDF Reports | Add `pdfmake` or `puppeteer` to reports route |
| GPS Check-in | Add geolocation to attendance frontend |
| Data Analytics | Add AI/ML microservice and connect to existing API |

---

Built for ProSite · Localhost MVP · Ready to pitch 🚀
